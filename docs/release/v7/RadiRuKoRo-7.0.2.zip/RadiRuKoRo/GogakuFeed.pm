# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoRo::GogakuFeed;

use utf8;
use strict;

use Tie::IxHash;
use URI::Escape qw(uri_escape_utf8);
use POSIX qw(strftime);

use Slim::Utils::Log;
use Slim::Utils::DateTime;
use Slim::Utils::Prefs;
use Slim::Utils::Strings;

use Plugins::RadiRuKo::Utils qw(
	fetchXml
);

use Data::Dumper;

my $log = logger('plugin.radiruko');

sub _createProgramCallback {
	my $listdataflv_xml_url = shift;
	my $duration = shift;
	my $icon = shift || 'html/images/radio.png';

	return sub {
		my ($client, $callback, $args) = @_;
		my $xmlCb = sub {
			my $xml = shift;
			my $misic = $xml->{music};
			if (ref($misic) ne 'ARRAY'){
				$misic = [$misic]; # 1つだけの場合
			}
			my @items;
			for (@$misic){
				my $title = sprintf('%s - %s', $_->{title}, $_->{hdate});
				push @items, +{
					title => $title,
					icon  => 'html/images/radio.png',
					url   => sprintf(
						'radiruod://nhks-vh.akamaihd.net/i/gogaku-stream/mp4/%s/master.m3u8#simulradio=1;duration=%s;title=%s;icon=%s;',
						$_->{file}, $duration, uri_escape_utf8($title), uri_escape_utf8($icon)
					),
					type  => 'audio'
				};
			}
			$callback->(\@items);
		};

		fetchXml($listdataflv_xml_url, $xmlCb, cacheExpire=>'10 min');
	};

}

sub createFeed {
	my ($client, $callback, $args) = @_;

	fetchXml(
		'http://t-yoshi.github.io/RadiRuKo-Plugin/feed/gogaku.opml',
		sub {
			my $xml = shift;
			my @items;
			for (@{$xml->{body}->{outline}}){
				push @items, {
					title => $_->{text},
					icon  => $_->{icon} || 'html/images/radio.png',
					url => _createProgramCallback($_->{URL}, $_->{duration}, $_->{icon}),
				};
			}
			$callback->(\@items);
		}, cacheExpire=>'120 min'
	);

}

1;