# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKoFmpp::Plugin;

use strict;

use Slim::Utils::Misc;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Strings;
use Slim::Formats;
#use Data::Dumper;

use base qw(Slim::Plugin::Base);

sub getDisplayName { 'PLUGIN_RADIRUKO_FMPP_NAME' }

sub initPlugin {
	my $class = shift;

	my $minBasicVersion = $class->_pluginDataFor('_minBasicVersion');
	my $basicFound = eval {
		require Plugins::RadiRuKo::Utils;		
		Plugins::RadiRuKo::Utils::checkBasicVersion($minBasicVersion);
	};
	if ($@ || !$basicFound){
		logError("Please install BasicPlugin >= $minBasicVersion");
		return;
	}

	my $log = logger("plugin.radiruko");
	eval { require IO::Socket::SSL; 1; } || do {
		#SSLがインストールされていない
		$log->error('FAIL RadiRuKoFmpp; IO::Socket::SSL is not installed');
		return;
	};

	$log->info('Register protocol: fmpp');
	Slim::Player::ProtocolHandlers->registerHandler(
#		'fmpp', q(Plugins::RadiRuKoFmpp::FmppClient)
		'fmpp', q(Plugins::RadiRuKoFmpp::FmppProtocolHandler)
	);

#	$Slim::Formats::tagClasses{'oggopus'} = 'Plugins::RadiRuKoFmpp::OggOpus';

	return $class->SUPER::initPlugin();
}

sub getFunctions(){ return {}; }

1;
