package Plugins::RadiRuKoFmpp::FmppClient;

use strict;

use IO::Socket::SSL qw/SSL_VERIFY_NONE/;
use base q(IO::Socket::SSL);

use Errno q(EWOULDBLOCK);
use Time::HiRes q(usleep);
use Slim::Utils::Log;
use Slim::Utils::PerlRunTime;
use Slim::Formats::RemoteMetadata;
use Slim::Music::Info;

use Protocol::WebSocket::URL;
use Protocol::WebSocket::Frame;
use Protocol::WebSocket::Handshake::Client;
use Data::Dumper;

use Plugins::RadiRuKo::FFMpegHandler;

my $log = logger("plugin.radiruko");

sub stationId {
    return $1 if ($_[0] =~ m|fmpp://([a-z\d]+)(/?#.*)?$|);
    return;
}

sub new {
	my $class = shift;
    my $args  = shift;

	my $station = stationId($args->{url}) or do {
        $log->error('Invalid URL: ' . $args->{url});
        return;
    };

    my $origin = 'wss://fmplapla.com/socket';

    my $hs = Protocol::WebSocket::Handshake::Client->new(
		url=>Protocol::WebSocket::URL->new->parse($origin)
    );

    my $self = $class->SUPER::new(
        PeerHost => $hs->{url}->{host},
		PeerPort => $hs->{url}->{port},
		SSL_verify_mode => SSL_VERIFY_NONE,
    ) or do {
        $log->error('Failed open: '.$hs->{url}->{host}.':'.$hs->{url}->{port}.
			" [$!] ".IO::Socket::SSL::errstr());
        return;
    };

    ${*$self}{_fc_frame} = _build_frame();
    ${*$self}{_fc_count} = 0;
    ${*$self}{_fc_eof} = 0;

    $self->_open($hs, $station);
    return $self;
}

sub _open {
	my ($self, $hs, $station) = @_;

    #print Dumper($hs);

	unless ($self->connected){
        $log->error("SSL Socket failed: $!");
        return;
    }
    $log->debug('Connected: ' . $hs->{url}->to_string) if $log->is_debug;

	$self->SUPER::syswrite($hs->to_string);

	$self->SUPER::sysread(my $rawBuffer, 8192);
	#print("RawR:\t$rawBuffer");
    unless ($hs->parse($rawBuffer)){
        $log->error('Parse failed: ' . $hs->error);
        $self->SUPER::close();
        return;
    }

	$self->printf('{"method":"start","station":"%s","burst":5}', $station);
	$self->blocking(0);
}

sub printf {
    my $self = shift;
    my $fmt = shift;
    my $buf = sprintf($fmt, @_);
    $log->debug('Send: ' . $buf) if $log->is_debug;
    my $frame = _build_frame(masked=>1, buffer=>$buf);
    $self->SUPER::syswrite($frame->to_bytes);
}

sub sysread {
	my $self = $_[0];
    my $maxLen = $_[2] || 65536;  
    my $offset = $_[3] || 0;

    unless (${*$self}{_fc_eof}){
        my $r = $self->SUPER::sysread(my $rawBuffer, $maxLen);
        if (defined $r){
            if ($r > 0){
                ${*$self}{_fc_frame}->append($rawBuffer);
                $self->printf(
                    '{"method":"continue","count":%d}',
                    ${*$self}{_fc_count}++);
            } else {
                ${*$self}{_fc_eof} = 1;
            }
        }
    }

    my $total = 0;
    while ($total < $maxLen/2 and 
            my $buf = ${*$self}{_fc_frame}->next_bytes){
        my $len = length($buf);
        substr($_[1], $offset + $total, $len, $buf);
        $total += $len;        
    }

    return $total if ($total > 0);

    #eof
    return 0 if (${*$self}{_fc_eof});

    $! = EWOULDBLOCK;
    return undef;
}

sub close {
    my $self = shift;
    if ($self->opened){
        my $frame = _build_frame(type => 'close');
        $self->SUPER::syswrite($frame->to_bytes);
    }
    $self->SUPER::close();
}

sub _build_frame {
    return Protocol::WebSocket::Frame->new(version=>undef, @_);
}

sub getMetadataFor {
	my $class = shift;
	my $meta = Plugins::RadiRuKo::FFMpegHandler->getMetadataFor(@_);
	return +{
		%$meta,
		bitrate => '96kbps',
	};
}


sub isRemote { 1 }
sub contentType { 'audio/ogg;codecs=opus' }
sub getStreamBitrate { 96_000 }
sub getFormatForURL { 'fmpp' }
#sub formatOverride { 'opus' }

1;
