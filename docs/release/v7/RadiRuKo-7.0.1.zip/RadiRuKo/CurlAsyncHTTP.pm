# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::CurlAsyncHTTP;
#
# PerlにSSL関連のモジュールがインストールされていない場合は、
# SimpleAsyncHTTPの代わりにcurlコマンド経由とする。
#
# https://radiko.jp/ への接続に必要。
#
use strict;

use HTTP::Request;
use HTTP::Response;
use HTTP::Headers;
use IPC::Open2;
use Errno qw(EWOULDBLOCK);
#use Data::Dumper;
use Slim::Utils::Misc;
use Slim::Utils::Timers;
use Slim::Utils::Network;
use Slim::Networking::IO::Select;

use base qw(Slim::Utils::Accessor);

use Plugins::RadiRuKo::Utils;

my $log = Slim::Utils::Log::logger("plugin.radiruko");

my $curl;

sub init {
	$curl = Slim::Utils::Misc::findbin('curl_bin') ||
			Slim::Utils::Misc::findbin('curl') || do {
		$log->error('[curl] not found.');
		return;
	};	

	if (open(my $fh, '-|', $curl, '-V')){
		read($fh, my $buf, 1024);
		close($fh);
		return 1 if ($buf =~ /^Protocols:.*\bhttps\b/mi);
	}
	$log->error('[curl] https not supported.');
	return;
}

__PACKAGE__->mk_accessor( rw => qw(
	cb ecb _params type url error code mess headers contentRef
));

sub new {
	my ($class, $cb, $ecb, $params) = @_;
	my $self = $class->SUPER::new();
	$self->cb($cb);
	$self->ecb($ecb);
	$self->_params($params || {});
	return $self;
}

# Examples:
# $http->post("www.somewhere.net", 'conent goes here');
# $http->post("www.somewhere.net", 'Content-Type' => 'application/x-foo', 'Other-Header' => 'Other Value', 'conent goes here');

sub get { shift->_request(GET => @_) }

sub post { shift->_request(POST => @_) }


sub _requestToCurlCommand {
	my ($self, $request) = @_;

	my $params = $self->_params;
	my $timeout = $params->{Timeout} || $params->{timeout} || 10;

	my @cmds = (
		$curl, '-s','--http1.0',
		'-X', $request->method(),
		'--max-time', $timeout,
		#LinuxバイナリをFreeBSDで動かすには --no-keepaliveが必要。
		'--no-keepalive',
		#レスポンスヘッダーをstdoutに出力する
		'-D', '-',
	);

	#環境によってはCA証明書エラーが起き得る。
	push @cmds, '-k' if $request->uri() =~ /^https:/;

	#POSTデータをstdinから読み込む
	push @cmds, '--data-binary', '@-' if $request->method() eq 'POST';

	for my $name ($request->header_field_names()){
		for my $val ($request->header($name)){
			push @cmds, '-H', "$name: $val";
		}
	}

	push @cmds, '--url', $request->uri();

	return @cmds;
}

sub _execCurl {
	my ($self, $request) = @_;

	my @cmds = $self->_requestToCurlCommand($request);

	$log->debug("open2: @cmds") if $log->is_debug;

	my ($rfd, $wfd);
	unless (open2($rfd, $wfd, @cmds)){
		return $self->_onError(501, "curl execute error: [@cmds]");
	}

	if ($request->method() eq 'POST'){
		Slim::Utils::Network::blocking($wfd, 0);
		${*$wfd}{passthrough} = [$self, $request->content_ref];
		Slim::Networking::IO::Select::addWrite($wfd, \&_onWrite);
	} else {
		close($wfd);
	}

	my $rbuffer = '';
	${*$rfd}{passthrough} = [$self, \$rbuffer];
	Slim::Utils::Network::blocking($rfd, 0);
	Slim::Networking::IO::Select::addRead($rfd, \&_onRead);
}

sub _onWrite {
	my ($wfd, $self, $refBuf) = @_;
	my $ret = syswrite($wfd, $$refBuf);

	$log->debug("ret: $ret");
	substr($$refBuf, 0, $ret, '');

	unless ($$refBuf){
		$log->debug("write finished..");
		_closeHandle($wfd);
	}
}

sub _MAX_RBUF_LEN() { 256*1024 }

sub _onRead {
	my ($rfd, $self, $refBuf) = @_;

	my $ret = sysread($rfd, $$refBuf, _MAX_RBUF_LEN, length $$refBuf);
	$log->debug("$ret") if $log->is_debug;

	if (length($$refBuf) > _MAX_RBUF_LEN){
		_closeHandle($rfd);
		return $self->_onError(501, 'ENOSPC');
	}

	unless ($ret) {
		$log->debug("EOF");
		_closeHandle($rfd);
		my $res = HTTP::Response->parse($$refBuf);
		if ($res->is_error){
			$self->_onError($res->code, $res->message);
		} else {
			$self->_onSuccess($res);
		}
	}
}

sub _onSuccess {
	my ($self, $res) = @_;
	$self->code($res->code);
	$self->mess($res->message);
	$self->headers($res->headers);
	$self->contentRef($res->content_ref);
	$self->cb->($self);
}

sub content {
	my ($self) = @_;
	return ${$self->contentRef};
}

sub _onError {
	my ($self, $code, $error) = @_;
	$log->debug("$code: $error");
	$self->code($code);
	$self->error($error);
	$self->ecb->($self, $error);
}

sub _request {
	my $self = shift;
	my $type = shift;
	my $url  = shift;

	$self->type($type);
	$self->url($url);

	my $request = HTTP::Request->new($type, $url);

	$request->content(pop @_) if (@_ % 2);
	$request->header(@_) if (@_);

	$self->_execCurl($request);
	return;
}

sub _closeHandle {
	my ($fd) = @_;

	Slim::Networking::IO::Select::removeRead($fd);
	Slim::Networking::IO::Select::removeWrite($fd);
	delete ${*$fd}{passthrough};
	close($fd);
}


1;

