# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::Utils;

use strict;

use XML::Simple;
use JSON::XS::VersionOneAndTwo;

use Slim::Utils::Log;
use Slim::Utils::Cache;
use Slim::Utils::Strings;
use Slim::Utils::Timers;
use Slim::Utils::Versions;
use Slim::Utils::Prefs;
use Slim::Utils::Unicode;
use Slim::Control::Request;
use Slim::Networking::SimpleAsyncHTTP;
use Date::Parse;
use Time::Zone;
use Time::Local;
use POSIX qw(strftime);

use Exporter 'import';
our @EXPORT_OK = qw(
	fetchXml fetchJson getCache stripTag jptime 
	$PatRadikoId radikoId
	notifyNewMeta notifyNewMetaAt 
	abbreviate stripTagAndAbbreviate
	parseDateTime jpShortDateTimeF
	enabledPremiumPlugin 
);

#use Data::Dumper;

my $log = Slim::Utils::Log::logger("plugin.radiruko");
my $cache = Slim::Utils::Cache->new('cache.radiruko.6.0');

sub getCache () {
	return $cache;
}

#読込中のurl
my %loadingUrls; 


sub _fetchUrl {
	my $parser = shift; # string -> hash
	my $url = shift;
	my $cb  = shift;
	my $ecb = shift if (!defined $_[0] or ref $_[0] eq 'CODE');
	$ecb ||= sub {
		my ($errorMsg, $url, $params) = @_;
		$log->error("$url: $errorMsg");
	};
	
	$log->error('Invalid Args: (' . join(',', @_) . ')') if (@_ % 2);

	my $cacheKey = 'radiruko:' . $url;

	my $params = {
		#hashのキャッシュ保存期間
		cacheExpire => '60 min',
		#パースエラー時の保存期間 (エラーなのに何回も接続しにいくのを防ぐ)
		errorCacheExpire => '90 sec',

		#SimpleAsyncHTTPのparams
		timeout => 10,
		cache   =>  1,

		@_,
	};

	my $hash = $cache->get($cacheKey);
	if (defined $hash){		
		$log->debug("cached: $url");
		if ($hash->{_failed}){
			$ecb->($hash->{_failed}, $url, $params); 
		} else {
			$hash->{_isCache} = 1;
			$cb->($hash, $url, $params); 
		}
		return;
	}

	my $putCache = sub {
		my ($hash, $expire) = @_;
		$log->debug("putCache: $url expire='$expire'");
		$cache->set($cacheKey, $hash, $expire); 
	};

	my $onSuccess = sub {
		my $hash = shift;
		$putCache->($hash, $params->{cacheExpire});
		$cb->($hash, $url, $params);
	};

	my $onError = sub {
		my $errMsg = shift;
		my $hash = +{ _failed => $errMsg };
 		$putCache->($hash, $params->{errorCacheExpire});
		$ecb->($hash, $url, $params);
	};

	if ($loadingUrls{$url}){
		$log->warn("$url: loading another thread. nothing do");
		return;
	}

	$loadingUrls{$url} = 1;

	Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my $http = shift;

			my $hash = eval { $parser->($http->content) };
			delete $loadingUrls{$url};

			if (defined $hash){
				$onSuccess->($hash);
			} else {
				$onError->($@ or 'parse error');
			}
		}, sub {
			my ($http, $err) = @_;
			delete $loadingUrls{$url};
			$onError->($err);
		}, $params
	)->get($url, 'User-Agent'=>'Mozilla/5.0 like Gecko');
}

#
# 非同期でXML|JSONを取得しハッシュに変換する。
#
# 引数:
#	url: 接続先
#   callback: 非同期で結果を返す  ->($hash, $url, $params)
#   [errorCallback]: エラーが起きたとき  ->($errorMsg, $url, $params)
#   [key=>value,..]: キャッシュ設定とSimpleAsyncHTTPにわたす引数
#
# $hashの追加キー:
#     _isCache: キャッシュを返すとき

sub fetchXml {
	_fetchUrl(sub {
		XMLin($_[0], ForceArray=>0, ForceContent=>1, KeyAttr=>[]);
	}, @_);
}

sub fetchJson {
	_fetchUrl(\&from_json, @_);
}


our $PatRadikoId = '[A-Z\d]+[\-_]?[A-Z\d]+';


sub radikoId {
	my $url = shift;
	return $1 if $url =~ m{^radikop?://($PatRadikoId)$};
	return $1 if $url =~ m{#radikop?=($PatRadikoId)$};
	return;
}

sub jptime {
	my $t = shift || time();
	return gmtime($t + tz_offset('JST'));
}

#
# 日時の文字列をエポック秒に変換する
#   ex. '2004-04-01T12:00+09:00' -> 1080788400
#
sub parseDateTime {
	my $dateTime = shift;

	#radiko形式 '20160910151500' -> '20160910T151500'
	$dateTime =~ s/^(20\d{6})(\d{4,}.*)$/$1T$2/;

	my @tm = strptime($dateTime, 'JST');
	return timegm(@tm) - $tm[6] if scalar @tm;	 
}

# ex '8/31 12:34'
sub jpShortDateTimeF {
	my @tm = jptime(shift);

	my $serverPrefs = preferences('server');
	my $dateFormat = $serverPrefs->get('shortdateFormat');
	my $timeFormat = $serverPrefs->get('timeFormat');
	$dateFormat =~ s=\W*%[yY][^%]*==; #年は省略
	$dateFormat =~ s=(?<!\|)%m([\.\-/]%d)=|%m$1=; #月の0を除く 08 -> 8
	#$log->info("$dateFormat $timeFormat");

	my $date = strftime("$dateFormat $timeFormat", @tm);
	$date =~ s/\|0*//g; #see DateTime.pm
	return Slim::Utils::Unicode::utf8decode_locale($date);
}


# すぐにメタの変更を通知する。
sub notifyNewMeta {
	my $client = shift;
	Slim::Control::Request::notifyFromArray($client, ['newmetadata']);
}

#
# 指定時刻にメタの変更を通知する。
#　(複数の引数があるときは現在時刻に近い方)
#
# ex. notifyNewMetaAt($client, '2016-09-01T12:00+09:00', '2016-09-01 12:03 JST', ...)
#
sub notifyNewMetaAt {
	my $client = shift;
	my $now = time();
	
	# +Nsec|epoch-time|date-string  -> epoch
	my $f = sub {
		# +で始まるならN秒後に更新
		return $now + $1 if /^\+(\d+)/;
		# 20で始まるなら日時の文字列。それ以外はエポック時。
		return /^20\d+/ ? parseDateTime($_) : $_;
	};

	my @times = sort map { $f->() } @_; 

	#過去 or 10分以上先なら無視
	my ($t) = grep { 
		$_ > $now and ($_ - $now) <= 600
	} @times or return;

	my $tdiff = $t - $now;
	$log->debug(strftime('set: %Y-%m-%d %H:%M:%S', localtime $t) . " after=${tdiff}secs") if $log->is_debug;

	#前回の指定をキャンセル
	Slim::Utils::Timers::killTimers($client, \&notifyNewMeta);
	Slim::Utils::Timers::setTimer($client, $t, \&notifyNewMeta);
	return $t;
}

#
# 文字列を後略する。
#
sub abbreviate {
	my $s = shift or return '';
	my $maxWidth = shift || 200; #半角換算の文字幅

	my $len = 0;
	for my $c (split //, $s) {
		$maxWidth-- if $c =~ /[^\p{InBasicLatin}]/;
		last if $maxWidth-- < 0;
		++$len;
	}

	return $s if ($maxWidth > 0);

	return substr($s, 0, $len) . '...';
}

#
# HTMLタグを除去する。
#
sub stripTag {
	my $s = shift or return '';

	$s =~ s/<.*?>/ /g;
	$s =~ s/\s+/ /g;
	return $s;
}

sub stripTagAndAbbreviate {
	my $s = shift or return '';
	my $maxWidth = shift;
	return abbreviate(stripTag($s), $maxWidth);
}


#基本プラグインのバージョンをチェックする。
sub checkBasicVersion {
	my $minVer = shift;
	require Plugins::RadiRuKo::Plugin;
	my $basicVersion = Plugins::RadiRuKo::Plugin->_pluginDataFor('version');
	#$log->debug("basic=$basicVersion, min=$minVer");
	return Slim::Utils::Versions->checkVersion($basicVersion, $minVer, '100101');
}

#コマンド引数をエスケープする
sub escapeCommands {
	my $escape = sub {
		s/([\$\"\`])/\\$1/g; 
		return /^[\w\+\-\/\.]+$/ ? $_ : "\"$_\"";	
	};
	@_ = map { $escape->() } @_;
	return wantarray ? @_ : join(' ', @_);
}

sub enabledPremiumPlugin {
	return !!Slim::Utils::PluginManager->isEnabled('Plugins::RadiRuKoPr::Plugin');
}

sub clearCache () {
	$cache->clear();
}

1;
