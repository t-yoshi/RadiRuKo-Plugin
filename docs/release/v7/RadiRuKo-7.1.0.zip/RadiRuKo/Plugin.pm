# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKo::Plugin;

use strict;
use File::Spec;

use Slim::Utils::Misc;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::OSDetect;
use Slim::Utils::Timers;

use base qw(Slim::Plugin::OPMLBased);


# create log categogy before loading other modules
my $log = Slim::Utils::Log->addLogCategory( {
	category     => 'plugin.radiruko',
	defaultLevel => 'INFO',
	description  => getDisplayName(),
});

use Plugins::RadiRuKo::FFMpegHandler;
use Plugins::RadiRuKo::RadikoHandler;
use Plugins::RadiRuKo::RadiruHandler;

my $prefs = preferences('plugin.radiruko');

use Plugins::RadiRuKo::SimulradioMeta;
use Plugins::RadiRuKo::Feed;

use Plugins::RadiRuKo::Settings;

sub getDisplayName {
	return 'PLUGIN_RADIRUKO_NAME';
}

#
# ffmpegがインストールされていればリンク作成
#
sub _check_if_ffmpeg_installed {
	my $class = shift;

	return if (Slim::Utils::Misc::findbin('ffmpeg_bin'));

	my $ffpath = Slim::Utils::Misc::findbin('ffmpeg4') ||
					Slim::Utils::Misc::findbin('ffmpeg3') ||
					Slim::Utils::Misc::findbin('ffmpeg');
	unless ($ffpath){
		$log->error('Please install: ffmpeg');
		return;
	}
	#Bin/ffmpeg_binへのリンク作成
	my $baseDir = $class->_pluginDataFor('basedir');
	my $linkPath = File::Spec->catdir($baseDir, 'Bin', 'ffmpeg_bin');
	eval { symlink($ffpath, $linkPath); 1 };
}

sub initPlugin {
	my $class = shift;
	my $version = $class->_pluginDataFor('version');
	$log->info('Initialising.. RadiRuKo-Plugin v' . $version);

	$class->SUPER::initPlugin(
		tag    => 'RadiRuKo',
		menu   => 'radios',
		weight => 1.01, # ラジオの先頭にメニュー表示
	);

	$class->_check_if_ffmpeg_installed();

	Plugins::RadiRuKo::FFMpegHandler::init();
	Plugins::RadiRuKo::RadikoHandler::init();
	Plugins::RadiRuKo::RadiruHandler::init();	

	Plugins::RadiRuKo::SimulradioMeta::registerMetaProvider();

	Plugins::RadiRuKo::Settings->new();

	return 1;
}

sub feed {
	my $class = shift;
	my $client = shift;
	return \&Plugins::RadiRuKo::Feed::createFeed;
}

sub playerMenu { 'RADIO' }

sub getFunctions(){ return {}; }

1;
