# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::FFMpegHandler;
#
# URL protocol handler
#     
#  ffmpeg: or ffmpegaac:
#
# ffmpeg:http://xxxx/stream.m3u8  HTTP Live Streaming
# ffmpeg:rtmpe://xxxx/ 
# ffmpeg:rtsp://xxxx/
# ffmpeg:mmst://xxxx/
#
use strict;
use File::Spec;
use Slim::Utils::Misc;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::PerlRunTime;
use Data::Dumper;
use Slim::Formats::RemoteMetadata;
use Slim::Control::Request;
use Plugins::RadiRuKo::Utils qw(notifyNewMeta notifyNewMetaAt);

use base q(Slim::Player::Pipeline);

my $log = logger('plugin.radiruko');

sub init {
	$log->info('Register protocol: ffmpeg ffmpegaac');
	Slim::Player::ProtocolHandlers->registerHandler('ffmpeg', __PACKAGE__);
	Slim::Player::ProtocolHandlers->registerHandler('ffmpegaac', __PACKAGE__);
}

sub new {
	my $class = shift;
	my $args  = shift;

	my $transcoder = $args->{transcoder};
	my $url        = $args->{url};
	my $client     = $args->{client};

	#{FFOPTIONS}を置換する。 Hash または Array
	$args->{ffoptions} ||= []; 

	$log->debug("url: $url");

	$url =~ s=#.*$==;
	$url =~ s=^ffmpeg(aac)?:((https?|rtsp|mms[th])://.+)=$2=;

	if ($url =~ /^rtsp:/){
		push @{$args->{ffoptions}}, ('-rtsp_transport', 'tcp');
	}

	my $cmd = Slim::Player::TranscodingHelper::tokenizeConvertCommand2(
		$transcoder, $url, $url, 1, undef
	);

	_subFFOptions($cmd, $args->{ffoptions});

	$log->debug("Command: $cmd");

	my $self = $class->SUPER::new(undef, $cmd, 0);

	my $format = $transcoder->{streamformat};
	${*$self}{contentType} = $format;

	#TODO: 48khz-PCMも可能だが、SqueezePlay(WinPC)で頻々にバッファが発生する。
	#if ($format eq 'pcm'){ 
	#  my $song  = $args->{song};         ## Slim::Player::Song
	#  my $track = $song->currentTrack(); ## Slim::Schema::RemoteTrack
	#  $track->samplerate(44100);
	#  $track->samplesize(16);
	#}

	return $self;
}

#コマンド内の {FFOPTIONS}を置換する
sub _subFFOptions {
	my $args = $_[1];
	$args = [%$args] if (ref $args eq 'HASH');
	my $escaped = Plugins::RadiRuKo::Utils::escapeCommands(@$args);
	$_[0] =~ s/{FFOPTIONS}/$escaped/;
}


#abstract:
# getMetadataForAsync($client, $url, $callback);
#

#
#Note: SBTouchは10分毎に呼び出す。
#      制御アプリは数秒毎に呼び出すこともある。
#
sub getMetadataFor {
	my ($class, $client, $url, $forceCurrent) = @_;

	my $now = time();

	my $defaultMeta = {
		title => $url,
		icon  => 'html/images/radio.png',
		type  => $client->string('RADIO'),
		_default => 1,
	};

	return $defaultMeta unless ($client->isPlaying() || $client->isPaused());

	if ($class->can('getMetadataForAsync')){
		my $song = $client->playingSong;
		my $meta = $song->pluginData('ffMeta') || {};
		
		#callbackがまだ呼ばれてない
		return $meta if ($meta->{_default});

		if ($meta->{_url} eq $url && $meta->{_expire} > $now){
			unless ($meta->{_notifyReserved}){				
				$meta->{_notifyReserved} = notifyNewMetaAt($client, $meta->{_expire});
			}
			return $meta;
		}

		my $callback = sub {
			my $meta = shift;
			$log->debug(Dumper($meta)) if $log->is_debug;
			$meta->{_url} = $url;
			if (!defined($meta->{_expire}) || $meta->{_expire} < $now){
				$meta->{_expire} = $now + 3*60;
			}

			$song->pluginData(ffMeta => $meta);
			
			notifyNewMeta($client);			
		};

		$song->pluginData(ffMeta => $defaultMeta);
		$class->getMetadataForAsync($client, $url, $callback);
		return $defaultMeta;
	}

	my $provider = Slim::Formats::RemoteMetadata->getProviderFor($url);
	if ($provider) {
		my $meta = eval { $provider->($client, $url); };
		if ($@) {
			my $name = Slim::Utils::PerlRunTime::realNameForCodeRef($provider);
			$log->error("Metadata provider $name failed: $@");
		}
		return $meta if (ref $meta eq 'HASH' and keys %{$meta});
	}

	return $defaultMeta;
}

sub canHandleTranscode {
	my ($self, $song) = @_;  
	return 1;
}

sub getStreamBitrate {
	my ($self, $maxRate) = @_;  
	return Slim::Player::Song::guessBitrateFromFormat(${*$self}{'contentType'}, $maxRate);
}

sub contentType {
	my $self = shift;
	return ${*$self}{'contentType'};
}

# XXX - I think that we scan the track twice, once from the playlist and then again when playing
sub scanUrl {
	my ($class, $url, $args) = @_;  
	Slim::Utils::Scanner::Remote->scanURL($url, $args);
}

sub canDirectStream { 0; }

sub isRemote { 1; } 

sub isAudioURL {  1; }

1;
