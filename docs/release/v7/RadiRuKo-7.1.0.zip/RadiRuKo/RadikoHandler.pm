# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadikoHandler;
			
# RADIKO URL protocol handler

use strict;

use Slim::Utils::Log;


use Plugins::RadiRuKo::Utils qw(radikoId);
use Plugins::RadiRuKo::RadikoAuth;
use Plugins::RadiRuKo::RadikoMeta;

use base q(Plugins::RadiRuKo::FFMpegHandler);

my $log = logger('plugin.radiruko');

sub init {
	# register protocol handler
	$log->info("Register protocol: radiko");
	Slim::Player::ProtocolHandlers->registerHandler("radiko",  __PACKAGE__);
}

# new is called by openRemoteStream() for URLs with "radiko:" protocol prefix

sub new {
	my $class = shift;
	my $args  = shift;
	my $song  = $args->{song};
	my $streamUrl = $song->streamUrl() || return;
	
	my $stId = radikoId($streamUrl);
	my $cf = $streamUrl =~ /^radikop:/ ? 'c' : 'f';
	my $token = $song->pluginData('authtoken');

	$args->{url} = "http://${cf}-radiko.smartstream.ne.jp/${stId}/_definst_/simul-stream.stream/playlist.m3u8";
	push(@{$args->{ffoptions}},
		'-user_agent', 'Mozilla/5.0',
		'-timeout', 15_000000, #microseconds 
		'-headers', "X-Radiko-AuthToken: $token",
	);

	return $class->SUPER::new($args);
}

sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $client = $song->master();
	my $url    = $song->track()->url;

	unless (radikoId($url)){
		$errorCb->('Invalid URL: ' . $url);
		return;
	}

	Plugins::RadiRuKo::RadikoAuth->new(
		sub {
			my ($token, $area) = @_;
			$log->debug("Authtoken=$token, AreaId=$area") if $log->is_debug;		
			$song->pluginData(authtoken => $token);
			$successCb->();
		}, sub {
			my ($error) = @_;
			$log->error("$error: $url");
			$errorCb->($error);
		}
	)->execute();
}

sub getMetadataForAsync {
	my ($class, $client, $url, $callback) = @_;

	my $stId = radikoId($url);
	return unless ($stId);

	my $type = $url =~ /radikop:/ ? 'Premium' : '';
	Plugins::RadiRuKo::RadikoMeta::metaProviderAsync(
		$client, $callback, $stId, $type
	);
}

1;
