package Plugins::RadiRuKoFmpp::OggOpus;

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License, 
# version 2.

use strict;
use base qw(Slim::Formats);

use IO::File;
use Slim::Utils::Log;
use Slim::Utils::Misc;
#use utf8;
use Data::Dumper;

my $log = logger('plugin.radiruko');


sub getTag {
	my $class = shift;
	my $file  = shift || return {};

	my $fh = IO::File->new($file, 'r') or return {};
	$fh->binmode();
	$fh->read(my $buf, 1024);

	return {} unless ($buf =~ /^OggS.*(OpusHead.*)OpusTags/s);
	
	my $tags = {};

	_parseOpusHeader($tags, $1);

	$fh->seek($+[0], 0);

	eval {
		my $vendor_length = _readLEU32($fh);
		my $vendor_string = _readUTF8($fh, $vendor_length);
		#$log->info("-->$vendor_string");
		#return;
		my $user_comment_list_length = _readLEU32($fh);

		while ($user_comment_list_length-- > 0){
			my $len = _readLEU32($fh);
			my $comment = _readUTF8($fh, $len);
			#$log->info("$comment");
			if ($comment =~ /^([a-z]+)=(.+)/i){
				$tags->{ uc($1) } = $2;
			}
		}
	};
	$log->error("$@") if ($@);
	$fh->close();

	$log->debug(Dumper($tags)) if $log->is_debug;

	return $tags;
}


sub _parseOpusHeader {
	my ($tags, $header) = @_;

	my $version = _u8(substr($header, 8, 1));
	my $channel_count = _u8(substr($header, 9, 1));
	my $sample_rate = _leu32(substr($header, 12, 4));
	#my $gain = _leu16(substr($header, 16, 2));

	$tags->{CHANNELS} = $channel_count;
	$tags->{RATE} = $sample_rate;
}


sub _u8 { unpack('C', $_[0]) }
sub _leu16 { unpack('v', $_[0]) }
sub _leu32 { unpack('V', $_[0]) }

sub _readLEU32 {
	my ($fh) = @_;
	die 'fail: read 4 bytes' if ($fh->read(my $buf, 4) != 4);
	return _leu32($buf);
}

sub _readUTF8 {
	my ($fh, $bytes) = @_;
	die "fail: read $bytes bytes" if ($fh->read(my $buf, $bytes) != $bytes);
	return $buf;	
}


1;