# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoFmpp::FmppProtocolHandler;

use strict;
use File::Spec;
use Slim::Utils::Misc;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::PerlRunTime;
#use Data::Dumper;
use Slim::Formats::RemoteMetadata;
use Slim::Control::Request;
use Plugins::RadiRuKo::Utils;
use Plugins::RadiRuKo::Utils;
use Plugins::RadiRuKo::FFMpegHandler;
use Plugins::RadiRuKoFmpp::FmppClient;

use base q(Slim::Player::Pipeline);

my $log = logger('plugin.radiruko');


sub new {
	my $class = shift;
	my $args  = shift;

	my $transcoder = $args->{transcoder};
	my $url        = $args->{url};
	my $client     = $args->{client};

	$log->debug("url: $url");

	my $cmd = Slim::Player::TranscodingHelper::tokenizeConvertCommand2(
		$transcoder, $url, $url, 1, undef
	);

	my $format = $transcoder->{streamformat};
	#48KHzを変えたくない
	if ($format eq 'pcm'){ 
		my $song  = $args->{song};         ## Slim::Player::Song
		my $track = $song->currentTrack(); ## Slim::Schema::RemoteTrack
		$track->samplerate(48000);
		$track->samplesize(16);
		#$cmd =~ s| --rate 44100 | |;
		$cmd =~ s| 44100 | 48000 |;
	}

	$log->debug("Command: $cmd");

	my $source = Plugins::RadiRuKoFmpp::FmppClient->new($args) or return;

	my $self = $class->SUPER::new($source, $cmd, 0);

	${*$self}{contentType} = $format;

	return $self;
}

sub getMetadataFor {
	my $class = shift;
	my $meta = Plugins::RadiRuKo::FFMpegHandler->getMetadataFor(@_);
	return +{
		%$meta,
		bitrate => '96kbps',
	};
}

sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $client = $song->master();
	my $url    = $song->track()->url;
	
    if (Plugins::RadiRuKoFmpp::FmppClient::stationId($url)){
	    $successCb->();
    } else {
        my $err = "Invalid URL: $url";
        $log->error($err);
        $errorCb->($err);
    }
}

sub canHandleTranscode { 1 }

sub getStreamBitrate { 
	my ($self, $maxRate) = @_;  
	return Slim::Player::Song::guessBitrateFromFormat($self->contentType(), $maxRate);
}

sub contentType { 
	my $self = shift;
	return ${*$self}{contentType} 
}

sub canDirectStream { 0 }
sub isRemote { 1 } 
sub isAudioURL { 1 }

1;
