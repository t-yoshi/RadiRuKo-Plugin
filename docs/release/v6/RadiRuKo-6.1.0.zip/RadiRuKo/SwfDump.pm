# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

package Plugins::RadiRuKo::SwfDump;

use strict;
use Compress::Raw::Zlib;
use IO::File;
use POSIX;
#use Data::Dumper;

sub _u8 { unpack('C', shift); }
sub _leu16 { unpack('v', shift); }
sub _leu32 { unpack('V', shift); }
sub _MIN { return $_[0]>$_[1] ? $_[1] : $_[0]; }


sub new {
  my ($class) = @_;

  return bless({
    _error => undef,
    _tags  => [],
  }, $class);
}

sub open {
  my ($self, $swf_file) = @_;

  if (eval { $swf_file->isa('IO::Handle') }){
    $self->{_swf_fh} = $swf_file;
  } else { 
    $self->{_swf_fh}= IO::File->new($swf_file, 'r');
  }
  if (!$self->{_swf_fh}){
    $self->{_error} = "swf open error.. [$swf_file]";
    return;
  }
  $self->{_swf_fh}->binmode(); 
  
  my $sig;
  $self->{_swf_fh}->seek(0, SEEK_SET);
  $self->{_swf_fh}->read($sig, 3, 0);
  $self->{_swf_fh}->seek(0, SEEK_SET);

  if ($sig !~ /^[FC]WS$/) { 
    $self->{_error} = "invalid swf file.. [$sig]";
    return;
  }
  if ($sig =~ /^CWS$/ && !$self->_cws2fws()){
    $self->{_error} = "cws2fws: zlib inflate error.";
    return;
  }
  return $self->_swf_read_header() &&  
         $self->_swf_parse_block();
}

sub _cws2fws {
  my ($self) = @_;
  
  my $tmp_fh = IO::File->new_tmpfile();

  my $header;
  $self->{_swf_fh}->read($header, 8);
  $header =~ s/^C/F/;
  $tmp_fh->write($header);

  my $inf = Compress::Raw::Zlib::Inflate->new();

  my $status;
  while (!$self->{_swf_fh}->eof()){
    my ($ibuf, $obuf);
    my $len = $self->{_swf_fh}->read($ibuf, 4096);
    $status = $inf->inflate($ibuf, $obuf);
    $tmp_fh->write($obuf);
  }
  $self->{_swf_fh} = $tmp_fh;
  return $status == Z_STREAM_END;
}

sub _swf_read_header {
  my ($self) = @_;
  $self->{_swf_fh}->seek(8, SEEK_SET);
  
  my $buf;
  $self->{_swf_fh}->read($buf, 1);

  #print _u8($buf) . "x  \n";
  #print unpack('C', $buf) ." len=" . length($buf) . "\n";

  my $rectbits = _u8($buf) >> 3;
  my $total_bytes = int(ceil((5 + $rectbits * 4) / 8.0));

  #print "rectbits=$rectbits, total_bytes=$total_bytes\n";

  $self->{_swf_fh}->read($buf, $total_bytes-1); 

  #frame
  $self->{_swf_fh}->read($buf, 4); 
} 

sub _swf_parse_block {
  my ($self) = @_;
  my $fh = $self->{_swf_fh};

  while (!$fh->eof()){
    my $buf;
    $fh->read($buf, 2);

    my $b = _leu16($buf);
    my $typeId = $b >> 6;
    my $block_len = $b & 0x3f;
    if ($block_len == 0x3f){
      $fh->read($buf, 4);
      $block_len = _leu32($buf);
    }
    my $block_start = $fh->tell();
    my $dataId = -1;
    if ($typeId == 87){
      $fh->read($buf, 2);
      $dataId = _leu16($buf); 
      $fh->read($buf, 4);
      my $__reserved = _leu32($buf);
      $fh->seek($block_len - 6, SEEK_CUR);
    } else {
      $fh->seek($block_len, SEEK_CUR);
    }

    my $tag = {
      type_id=>$typeId, block_start=>$block_start, 
      block_len=>$block_len, data_id=>$dataId
    };
    push(@{$self->{_tags}}, $tag);
    last if ($typeId == 0);
  }
 
  if (!@{$self->{_tags}}){
    $self->{_error} = '_swf_parse_block: self->{_tags} is empty!';
  }
  return @{$self->{_tags}};
  #print Data::Dumper->Dump($self->{_tags});
}

sub _copyObject {
  my ($self, $start, $length, $outfile) = @_;

  $self->{_swf_fh}->seek($start, SEEK_SET);
  my $ofh = IO::File->new($outfile, 'w');
  if (!$ofh){
    $self->{_error} = "_copyObject: Can't open file for writing [$outfile]";
    return;
  }
  $ofh->binmode();

  #print "start=$start, length=$length\n";

  while (!$self->{_swf_fh}->eof() && $length > 0){
    my $buf;
    my $ret = $self->{_swf_fh}->read($buf, _MIN($length, 8192));
    $length -= $ret;
    $ofh->write($buf);
  }
  $ofh->close();
  if ($length != 0){
    $self->{_error} = "_copyObject: unexpected _EOF_ error.";
    return;
  }
  return 1;
}

sub writeBinary {
  my ($self, $id, $outfile) = @_;

  my ($tag) = grep(
    $_->{type_id}==87 && $_->{data_id}==$id,
    @{$self->{_tags}}
  );
  if (!$tag){
    $self->{_error} = "id=$id not found.";
    return;
  }
  return $self->_copyObject(
     $tag->{block_start}+6, $tag->{block_len}-6, $outfile
  );
}

sub error { 
  return shift->{_error}; 
}

1;
__END__

sub _test_ {
  #"http://radiko.jp/player/swf/player_3.0.0.01.swf"
  my $d = __PACKAGE__->new();
  $d->open("player_3.0.0.01.swf") &&
  $d->writeBinary(14, "pl_cacheAuthKey.png");

fail:
  print $d->{_error};
}

#_test_();

