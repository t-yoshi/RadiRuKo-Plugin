# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruHandler;
#
# RADIRU URL protocol handler
#
#  radiru://Station[-Area]
#
#  Station:
#    R1, R2, FM
#  Area:
#    Sendai, Tokyo, Nagoya, Osaka
#
#  See: http://www.nhk.or.jp/radio/config/config_web.xml
#
use strict;
use List::Util qw(first);
use Tie::IxHash;
use Data::Dumper;

use URI;
use Slim::Utils::Misc;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Timers;

use Plugins::RadiRuKo::Utils qw(fetchXml);
use Plugins::RadiRuKo::RadiruMeta;

my $log = logger('plugin.radiruko');
my $prefs = preferences('plugin.radiruko');

use base q(Plugins::RadiRuKo::FFMpegHandler);

#{
#	tokyo=> {
#		areajp=>'東京', apikey=>'001', areakey=>'130',
#		nowonair=>'http://api.nhk.or.jp/r2/pg/now/4/130/netradio.json',
#		stream_url=> {
#			r1hls=>'https://.../xx.m3u8',
#			r2hls=>'https://',
#			fmhls=>'https://',
#		}
#	},
#	osaka=>{...

our $config = {};
tie(%$config, 'Tie::IxHash'); #key順序維持

sub _initConfig {
	my $configUrl = 'http://www.nhk.or.jp/radio/config/config_web.xml';

	my $onParse = sub {
		my ($xml) = @_;

		my @datas = @{ $xml->{stream_url}{data} or [] };
		my @areas = map { $_->{area}{content} } @datas;

		for my $area (@areas){
			my $data = first {
				$_->{area}{content} eq $area
			} @datas;
			my $prop = $config->{$area} = {};

			for my $k (qw(area areajp apikey areakey)){
				$prop->{$k} = $data->{$k}{content};
			}

			my $noa = $xml->{url_program_noa}{content};
			my $areakey = $prop->{areakey};
			$noa =~ s/\{area\}/$areakey/;
			$prop->{nowonair} = URI->new_abs($noa, $configUrl)->as_string;

			my $stream_url = $prop->{stream_url} = {};
			for my $ch (qw(r1hls r2hls fmhls)){
				$stream_url->{$ch} = $data->{$ch}{content};
			}
		}

		$log->debug(Dumper($config)) if $log->is_debug;
	};

	fetchXml($configUrl, $onParse, cacheExpire=>'30 days');
}

sub init {
	# register protocol handler
	$log->info("Register protocol: radiru");
	Slim::Player::ProtocolHandlers->registerHandler("radiru",  __PACKAGE__);

	_initConfig();
}

# new is called by openRemoteStream() for URLs with "radiru:" protocol prefix
sub new {
	my $class = shift;
	my $args  = shift;
	#my $client = $args->{client};
	my $song = $args->{song};
	my $stream_url = $song->pluginData('stream_url') || return;

	$args->{url} = $stream_url;

	return $class->SUPER::new($args);
}

# radiru://R1-Tokyo  -> ('R1', 'Tokyo')
sub parseRadiruUrl {
	my $u = shift;
	my ($c, $a) = $u =~ m{(R1|R2|FM)(?:-([A-Z][a-z]+))?$} or return;
	$a ||= 'Tokyo';
	return ($c, $a);
}

sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $client = $song->master();
	my $url = $song->track()->url;

	my ($channel, $area) = parseRadiruUrl($url) or do {
		my $error = "Invalid URL: $url";
		$log->error($error);
		return $errorCb->($error);
	};

	my $u = $config->{ lc($area) }{stream_url}{ lc($channel . 'hls') };
	if ($u){
		$song->pluginData({stream_url=>$u});
		$successCb->();
	} else {
		my $error = "Missing stream_url: $url";
		$log->error($error);
		$errorCb->($error);
	} 
}

sub getMetadataForAsync {
	my ($class, $client, $url, $callback) = @_;

	Plugins::RadiRuKo::RadiruMeta::metaProviderAsync(
		$client, $url, $callback
	);
}

1;
