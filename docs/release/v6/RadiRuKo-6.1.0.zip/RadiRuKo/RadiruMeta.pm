# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruMeta;

use strict;
use utf8;
use POSIX;
use List::Util qw(first);
use Slim::Utils::Log;
use Slim::Utils::Strings;
use Slim::Utils::Prefs;
use Plugins::RadiRuKo::Utils qw(
	jptime abbreviate fetchJson  
	notifyNewMetaAt parseDateTime
);

my $log = Slim::Utils::Log::logger("plugin.radiruko");
my $prefs = preferences('plugin.radiruko');


# URL:
#  radiru://Station[-Area]
#
#  Station:
#    R1, R2, FM
#  Area:
#    Sendai, Tokyo, Nagoya, Osaka, ...
#

sub new {
	my ($class, $url) = @_;

	my ($channel, $area) =
			Plugins::RadiRuKo::RadiruHandler::parseRadiruUrl($url) or return;

	my $props = $Plugins::RadiRuKo::RadiruHandler::config->{lc($area)};
	my $chName = Slim::Utils::Strings::string("PLUGIN_RADIRUKO_NHK_${channel}");
	$chName .= $props->{areajp} or ' ' . ucfirst($area);

	return bless {
		channel => $channel,
		area => $area,
		icon => "plugins/RadiRuKo/html/images/NHK_${channel}.gif",
		chName => $chName,
		jsUrl => $props->{nowonair},
	}, $class;
}

sub defaultMeta {
	my $self = shift;
	return {
		title    => $self->{chName},
		artist   => ' ',
		album    => ' ',
		type     => "(Radiru/hls)",
		bitrate  => '48kbps',
		cover    => $self->{icon},
		icon     => $self->{icon},
	};
}

sub fetchProgramJson {
	my $self = shift;
	fetchJson($self->{jsUrl}, @_);
}


sub metaProviderAsync {
	my ($client, $url, $callback) = @_;

	my $self = __PACKAGE__->new($url) or return;
	my $meta = $self->defaultMeta();
	
	my $onParse = sub {
		my $js = shift;
		
		my $ch = {R1=>'n1',R2=>'n2',FM=>'n3'}->{ $self->{channel} };
		my @programs = values %{$js->{nowonair_list}->{ $ch }};

		my $now = time();
		#放送中
		my $prog = first {
			$now >= parseDateTime($_->{start_time}) && parseDateTime($_->{end_time}) > $now
		} @programs or goto finish;

		my $logo = $prog->{images}{logo_l}{url} || $prog->{images}{thumbnail_m}{url};

		$meta->{title} .= ' ' . $prog->{title};
		$meta->{artist} = $prog->{act} || $prog->{subtitle} || $meta->{artist};
		$meta->{album} = abbreviate($prog->{content}) || $meta->{album};
		$meta->{cover} = $logo || $meta->{cover};

		#次の番組開始時間にメタ更新を通知する
		my $following = $js->{nowonair_list}{ $ch }{following};		
		$meta->{_expire} = parseDateTime($following->{start_time});
		if ($meta->{_expire} <= $now){
			$meta->{_expire} = parseDateTime($following->{end_time});
		}

		finish:
		$callback->($meta);
	};

 	$self->fetchProgramJson(
		$onParse, sub {
			$callback->($meta); # error
		}, cacheExpire=>'4 min'
	);

}


1;
