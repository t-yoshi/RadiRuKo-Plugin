# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::AuthRadiko;

use strict;
use HTTP::Request;
use IO::File;
use MIME::Base64;
use Digest::MD5 qw(md5_hex);
use Slim::Utils::Log;
use Slim::Utils::Misc;
use Slim::Utils::Prefs;
use Slim::Networking::Async::HTTP;
use Slim::Networking::SimpleAsyncHTTP;
use Plugins::RadiRuKo::Utils qw(getCache);
use Plugins::RadiRuKo::SwfDump;

my $log = Slim::Utils::Log::logger("plugin.radiruko");

my $swfUrl = 'http://radiko.jp/apps/js/flash/myplayer-release.swf';
my $swfKeyId   = 12;
my $appVersion = '4.0.0';

my $UA = 'Mozilla/5.0 like Gecko';
my $CRLF = "\x0A\x0D";

#HTTPS
my $asyncHttpsClient;

my $prefs = preferences('plugin.radiruko');

#
#  一部のNASではSSL関連のモジュールがインストールされていないので、
# SimpleAsyncHTTPでhttpsを扱えないことがある。
# その場合は自前のcurlコマンドでhttpsにアクセスする。
#
my $_initialized;

sub _initialize {
	$_initialized = 1;

	$prefs->cookie_rdk_uid(md5_hex(int(rand (10000)) . time()));

	if (Slim::Networking::Async::HTTP->hasSSL()){
		# Win, Mac, 大多数のLinux
		$asyncHttpsClient = q(Slim::Networking::SimpleAsyncHTTP);
	} else {
		# 一部のNAS
		require Plugins::RadiRuKo::CurlAsyncHTTP;
		return unless (Plugins::RadiRuKo::CurlAsyncHTTP::init());
		$asyncHttpsClient = q(Plugins::RadiRuKo::CurlAsyncHTTP);
	}
	$log->info("HttpsClient is $asyncHttpsClient");
}

#
# 非同期でradiko認証を行う。
# 成功した場合、結果を10分間キャッシュする。
#
# コールバック:
# cb  ->(authToken, areaId)
# ecb ->(errMsg)
#
sub new {
	my $class = shift;
	my $cb   = shift;
	my $ecb  = shift || sub { $log->error($_[0]); };

	_initialize() unless ($_initialized);

	my $cookie_radiko_session = $prefs->get('cookie_radiko_session');
	my $cacheKeyPrefix = 'radiruko:AuthRadiko-';
	if ($cookie_radiko_session) {
		$cacheKeyPrefix .= $cookie_radiko_session . '-';
		$log->debug("Premium: radiko_session=$cookie_radiko_session") if $log->is_debug;
	}

	my $basedir = Plugins::RadiRuKo::Plugin->_pluginDataFor('basedir');

	return bless {
		cb => $cb,
		ecb => $ecb,

		keypath => File::Spec->catfile($basedir, "_radikokey_app${appVersion}.png"),
		cookie_rdk_uid => $prefs->get('cookie_rdk_uid'),
		cookie_radiko_session => $cookie_radiko_session,
		cacheKeyPrefix => $cacheKeyPrefix,

		#SimpleAsyncHTTPのエラーハンドラ
		httpClientErrorCb => sub {
			my ($http, $err) = @_;
			$ecb->($err);
		},
	}, $class;
}

sub _fetchKey {
	my ($self) = @_;

	my $onOk = sub {
		my $http = shift;
		my $tmpFh = IO::File->new_tmpfile();
		$tmpFh->binmode();
		my $rcontent = $http->contentRef;
		$log->debug("player.swf length=" . length($$rcontent) ." sig=" . substr($$rcontent, 0, 3)) if $log->is_debug;

		$tmpFh->write($$rcontent);
		$tmpFh->seek(0, SEEK_SET);

		my $swfdump = Plugins::RadiRuKo::SwfDump->new();
		my $ret = $swfdump->open($tmpFh) &&
				$swfdump->writeBinary($swfKeyId, $self->{keypath});
		$tmpFh->close();

		unless ($ret){
			$self->{ecb}->('swfdump error: ' . $swfdump->error());
			return;
		}

		$self->_auth1();
	};

	Slim::Networking::SimpleAsyncHTTP->new(
		$onOk, $self->{httpClientErrorCb}
	)->get($swfUrl, 'User-Agent' => $UA);
}

sub _defaultRequestHeader {
	my $self = shift;
	my $cookie = 'rdk_uid=' . $self->{cookie_rdk_uid};

	if ($self->{cookie_radiko_session}) {
		$cookie .= '; radiko_session=' . $self->{cookie_radiko_session};
	}

	return (
		'User-Agent' => $UA,
		'pragma' => 'no-cache',
		'Cookie' => $cookie,
		'Referer' => $swfUrl,

		'X-Radiko-App' => 'pc_ts',
		'X-Radiko-App-Version' => $appVersion,
		'X-Radiko-User' => 'test-stream',
		'X-Radiko-Device' => 'pc',
		'X-Requested-With' => 'ShockwaveFlash/23.0',
	);
}

sub _auth1 {
	my ($self) = @_;

	$log->debug("auth1: Start");

	$asyncHttpsClient->new(
		sub {
			my $http = shift;
			my $headers = $http->headers;
			$log->debug("auth1: OK");

			$self->{authToken} = $headers->header("x-radiko-authtoken");
			$self->{keyoffset} = int($headers->header("x-radiko-keyoffset"));
			$self->{keylength} = int($headers->header("x-radiko-keylength"));

			$self->_auth2();
		}, $self->{httpClientErrorCb}
	)->post(
		'https://radiko.jp/v2/api/auth1_fms',
		$self->_defaultRequestHeader(),
		$CRLF
	);
}

sub _partialkey {
	my ($self) = @_;

	my $fh = IO::File->new($self->{keypath}, 'r') or do {
		$self->{ecb}->('_partialkey: keyfile open error.');
		return;
	};

	$fh->binmode();
	$fh->seek($self->{keyoffset}, 0);
	$fh->read(my $buf, $self->{keylength});

	return MIME::Base64::encode_base64($buf, '');
}

sub _auth2 {
	my ($self) = @_;

	$log->debug("auth2: Start");

	my $partKey = $self->_partialkey() or return;

	$asyncHttpsClient->new(
		sub {
			my $http = shift;
			$log->debug("auth2: OK");

			if (${$http->contentRef} =~ /(JP\d+)/){
				my $authToken = $self->{authToken};
				my $areaId = $1;

				# エリアIDは無期限
				$self->_storeCache(areaId => $areaId, 'never'),

				# 成功した場合、トークンを10分間Cacheする。
				$self->_storeCache(authToken => $authToken, '10 min'),

				$self->{cb}->($authToken, $areaId);
			} else {
				$self->{ecb}->('fail auth2: Bad areaId');
			}
		}, $self->{httpClientErrorCb}
	)->post(
		'https://radiko.jp/v2/api/auth2_fms',
		$self->_defaultRequestHeader(),
		'X-Radiko-Authtoken'  => $self->{authToken},
		'X-Radiko-Partialkey' => $partKey,
		$CRLF
	);
}

# 実行する。
# mode:
#	'force' キャッシュを破棄
#	'cache' areaIdがキャッシュされていれば返す
#
sub execute {
	my $self = shift;
	my $mode = shift || '';

	#Cache
	my $areaId = $self->_fromCache('areaId');
	my $authToken = $self->_fromCache('authToken');

	if ($mode eq 'cache' && $areaId){
		$self->{cb}->($authToken, $areaId);
		return;
	}

	if ($mode ne 'force' && $areaId && $authToken){
		$self->{cb}->($authToken, $areaId);
		return;
	}

	unless ($asyncHttpsClient){
		$self->{ecb}->('curl not installed.');
		return;
	}

	unless (-r $self->{keypath}){
		$self->_fetchKey();
	} else {
		$self->_auth1();
	}
}


sub _storeCache {
	my ($self, $key, $value, $expire) = @_;
	getCache()->set($self->{cacheKeyPrefix} . $key, $value, $expire);
}

sub _fromCache {
	my ($self, $key) = @_;
	return getCache()->get($self->{cacheKeyPrefix} . $key);
}

1;