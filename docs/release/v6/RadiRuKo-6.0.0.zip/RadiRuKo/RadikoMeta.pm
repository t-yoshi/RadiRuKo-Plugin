# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadikoMeta;

use strict;
use utf8;
use POSIX;
use List::Util qw(first);
use Slim::Utils::Log;
use Slim::Utils::Strings;
use Slim::Music::Info;
use Plugins::RadiRuKo::Utils qw(
	jptime stripTagAndAbbreviate 
	radikoId fetchXml notifyNewMetaAt parseDateTime
);

my $log = Slim::Utils::Log::logger("plugin.radiruko");

# 
# 番組表のXMLを取得する。
#  id: stationId || areaId || 'ALL'
#  [time]: 過去の番組表(エポック時間)
#  @_: fetchXmlの引数
#
sub fetchProgramXml {
	my $id = shift;
	my $now = time();
	my $time = ref($_[0]) ne 'CODE' ? shift : undef;
	$time ||= $now;

	#朝５時更新
	my $date = strftime('%Y%m%d', jptime($time - 5*60*60));
	my $expire = ($now - $time > 24*60*60) ? '7 days':'1 hour';

	my $u = ($id =~ /^(JP\d+|ALL)$/) ?
		"http://radiko.jp/v3/program/date/$date/$id.xml" :        #JP13
		"http://radiko.jp/v3/program/station/date/$date/$id.xml"; #FMJ
	
	fetchXml($u, @_, cacheExpire=>$expire);
}

#いま放送中のprog
sub _findProg {
	my $xml  = shift;
	my $time = shift || time();
	return first {
		$time >= parseDateTime($_->{ft}) && parseDateTime($_->{to}) > $time
	} @{$xml->{stations}{station}{progs}{prog}};
}

sub defaultMeta {
	my ($title, $type) = @_;
	$type = " $type" if $type;

	return {
		title    => $title,
		album    => ' ',
		icon     => 'plugins/RadiRuKo/html/images/icon.gif',
		bitrate  => '48kbps',
		type     => "AAC (radiko$type)",
	};
}

#
# client: 
# callback: getMetadataForAsyncのcallback
# stId: ex. 'TFM'
# [type]: '', 'Premium', 'Time Free' 
# [time]: 指定日時の番組
#
sub metaProviderAsync {
	my ($client, $callback, $stId, $type, $time) = @_;

	fetchProgramXml($stId, $time, sub {
		my $xml = shift;

		my $prog = _findProg($xml, $time) or do {
			$log->error(jptime($time) . " not found.");		
			return;
		};
	
		# 番組info内に画像があれば使う。
		my $info = $prog->{info}{content} || '';
		my ($image) = $info =~ m{\bhttp://[-_.a-zA-Z0-9;/?:@&=+\$,%]+\.(?:gif|jpe?g|png)\b}g;

		my $meta = defaultMeta($stId, $type);

		$meta->{title} = $xml->{stations}{station}{name}{content} 
			. ' - ' . stripTagAndAbbreviate($prog->{title}{content});
		$meta->{artist} = stripTagAndAbbreviate($prog->{pfm}{content});
		$meta->{album} = stripTagAndAbbreviate($prog->{desc}{content}) || $meta->{album};
		$meta->{cover} = $image || "http://radiko.jp/station/logo/$stId/logo_large.png";	
		$meta->{_expire} = parseDateTime($prog->{to}) unless $time;

		$callback->($meta);
	});
}


1;
