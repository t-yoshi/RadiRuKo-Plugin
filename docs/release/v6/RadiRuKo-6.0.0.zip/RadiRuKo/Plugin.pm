# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKo::Plugin;

use strict;
use File::Spec;

use Slim::Utils::Misc;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::OSDetect;
use Slim::Utils::Timers;

use base qw(Slim::Plugin::OPMLBased);


# create log categogy before loading other modules
my $log = Slim::Utils::Log->addLogCategory( {
	category     => 'plugin.radiruko',
	defaultLevel => 'INFO',
	description  => getDisplayName(),
});

use Plugins::RadiRuKo::FFMpegHandler;
use Plugins::RadiRuKo::RadikoHandler;
use Plugins::RadiRuKo::RadiruHandler;

my $prefs = preferences('plugin.radiruko');

use Plugins::RadiRuKo::SimulradioMeta;
use Plugins::RadiRuKo::Feed;

use Plugins::RadiRuKo::Settings;

sub getDisplayName {
	return 'PLUGIN_RADIRUKO_NAME';
}

#
# 実行ファイル検索パスに追加
#	Mac: Bin/_darwin
#	FreeBSD: Bin/i386-linux
#   その他: ffmpegがインストールされていればリンク作成
#
sub _addPluginFindBinPath {
	my $class = shift;

	return if (Slim::Utils::Misc::findbin('ffmpeg_bin'));

	my $binDir;	
	if (Slim::Utils::OSDetect::isMac()){ 
		$binDir = '_darwin';
	} else {
		#FreeBSD
		my $osDetails = Slim::Utils::OSDetect::details();
		if ($osDetails->{osArch} =~ /(i\d86|amd64|x86_64)-freebsd/i){
			$binDir = 'i386-linux';
		}
	}

	my $baseDir = $class->_pluginDataFor('basedir');
	if ($binDir){		
		my $binPath = File::Spec->catdir($baseDir, 'Bin', $binDir);
		Slim::Utils::Misc::addFindBinPaths($binPath);		
	} else {
		my $ffpath = Slim::Utils::Misc::findbin('ffmpeg3') ||
					Slim::Utils::Misc::findbin('ffmpeg') || do {
				$log->error('Please install: ffmpeg');
				return;
			};
		#Bin/ffmpeg_binへのリンク作成
		my $linkPath = File::Spec->catdir($baseDir, 'Bin', 'ffmpeg_bin');
		eval { symlink($ffpath, $linkPath); 1 };
	}
}

sub initPlugin {
	my $class = shift;
	my $version = $class->_pluginDataFor('version');
	$log->info('Initialising.. RadiRuKo-Plugin v' . $version);

	$class->SUPER::initPlugin(
		tag    => 'RadiRuKo',
		menu   => 'radios',
		weight => 1.01, # ラジオの先頭にメニュー表示
	);

	$class->_addPluginFindBinPath();

	Plugins::RadiRuKo::FFMpegHandler::init();
	Plugins::RadiRuKo::RadikoHandler::init();
	Plugins::RadiRuKo::RadiruHandler::init();	

	Plugins::RadiRuKo::SimulradioMeta::registerMetaProvider();

	Plugins::RadiRuKo::Settings->new();

	return 1;
}

sub feed {
	my $class = shift;
	my $client = shift;
	return \&Plugins::RadiRuKo::Feed::createFeed;
}

sub playerMenu { 'RADIO' }

sub getFunctions(){ return {}; }

1;
