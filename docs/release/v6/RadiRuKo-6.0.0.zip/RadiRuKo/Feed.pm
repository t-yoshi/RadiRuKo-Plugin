package Plugins::RadiRuKo::Feed;
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
use utf8;
use strict;

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Formats::XML;
use Plugins::RadiRuKo::Utils qw(fetchXml);
use Plugins::RadiRuKo::RadiruHandler;
use Plugins::RadiRuKo::AuthRadiko;
use Data::Dumper;

my $log = logger('plugin.radiruko');
my $prefs = preferences('plugin.radiruko');

my @areaNameJP = (undef, qw(
北海道 青森 岩手 宮城 秋田 山形 福島 茨城 栃木 群馬
埼玉 千葉 東京 神奈川 新潟 富山 石川 福井 山梨 長野
岐阜 静岡 愛知 三重 滋賀 京都 大阪 兵庫 奈良 和歌山
鳥取 島根 岡山 広島 山口 徳島 香川 愛媛 高知 福岡
佐賀 長崎 熊本 大分 宮崎 鹿児島 沖縄
));

sub _radiruRegion {
	my $props = shift; #{area=>tokyo,...
	my $addR2 = shift; #R2を含めるか

	my @items;

	for my $channel (qw(R1 R2 FM)){
		next if ($channel eq 'R2' && !$addR2);

		my $area = ucfirst($props->{area});
		my $areajp = $props->{areajp};
		my $areakey = $props->{areakey};

		my $name = Slim::Utils::Strings::string("PLUGIN_RADIRUKO_NHK_$channel");

		if ($channel eq 'R2' and $area !~ /tokyo/i){
			$area = 'Tokyo';
			$areajp = $areakey = '';
		}

		#ローカル局: R1の後にFMを並べる
		my $sortkey = ($channel eq 'FM') ? '1#': '0#';

		push @items, {
			name  => $name . $areajp,
			url   => "radiru://$channel-$area",
			icon  => "plugins/RadiRuKo/html/images/NHK_$channel.gif",
			type  => 'audio',

			_sortkey => $sortkey . $areakey,
		};
	}
	return @items;
}

sub _radiruItems {
	my ($cb, $ecb) = @_;

	my $config = $Plugins::RadiRuKo::RadiruHandler::config;

	my @areas = keys %$config;
	return $ecb->('config not loaded') unless (@areas);

	my $areaMain = $prefs->get('radiru_area') || 'tokyo';

	my @items = _radiruRegion($config->{$areaMain}, 1);

	my @locals;
	for my $area (grep { $_ ne $areaMain } @areas){
		push @locals, _radiruRegion($config->{$area});
	}

	#R1を先に持ってくる
	@locals = sort { $a->{_sortkey} cmp $b->{_sortkey} } @locals;

	push @items, +{
		title => 'NHKローカル',
		icon  => 'html/images/radio.png',
		items => \@locals,
	};

	$cb->(\@items);
}

sub _radikoItems {
	my ($cb, $ecb) = @_;

	my $onAuth = sub {
		my (undef, $areaId) = @_;
		$areaId =~ /JP(\d+)/;
		my $title = ' (' . $areaNameJP[$1] . 'エリア)';

		fetchXml("http://radiko.jp/v2/station/list/${areaId}.xml", sub {
			my $xml = shift;

			my @items = map {
				+{
					name => Slim::Formats::XML::unescapeAndTrim($_->{name}{content}),
					url  => 'radiko://' . $_->{id}{content},
					icon => $_->{logo_small}{content},
					type => 'audio',
				};
			} grep({ $_->{name}{content} !~ /^NHK/ } @{$xml->{station}});

			$cb->({
				title => $title,
				items => \@items,
			});
		}, $ecb, cacheExpire=>'30 days');
	};

	Plugins::RadiRuKo::AuthRadiko->new(
		$onAuth, sub { $ecb->('(エリア不明)') }
	)->execute('cache');
}

sub _simulRadioItems {
	my ($cb, $ecb) = @_;
	$cb->([{
		name => "コミュニティFM",
		icon => "html/images/radio.png",
		url  => 'http://t-yoshi.github.io/RadiRuKo-Plugin/feed/simulradio60.opml',
		type => 'slim:link',
	}]);
}

#リモコン数字ボタン
sub _markAnchor {
	my $items = shift;
	my @keys = (1 .. 9, 0);
	my $i = 0;
	for my $item (@$items){
		last unless (my $key = $keys[$i]);
		if (1 or $item->{type} eq 'audio'){
			$item->{textkey} = $key;
			$i++;
		}
	}
}

sub _asyncMerge {
	my $callback = shift;
	my @generators = @_;

	my %results = map { $_, undef } @generators;

	my $onMerge = sub {
		my $mergedFeed = {
			title => 'らじる&ラジコ ',
			items => [],
		};
		for my $g (@generators){
			my $feed = $results{$g};
			if (ref($feed) eq 'ARRAY') {
				push @{$mergedFeed->{items}}, @$feed; 
			} else {
				$mergedFeed->{title} .= $feed->{title};
				push @{$mergedFeed->{items}}, @{$feed->{items}};
			}
		}
		#_markAnchor($mergedFeed->{items});
		#$log->debug(Dumper($mergedFeed));
		$callback->($mergedFeed);
	};

	for my $g (@generators){
		my $cb = sub {
			$results{$g} = shift || [];
			
			$log->debug(Dumper(\%results)) if $log->is_debug;

			$onMerge->() unless (grep { !defined } values(%results));
		};
		my $ecb = sub {
			my $error = shift;
			$cb->([{ 
				title => "$error",
				items => [],
			}]);
		};
		$g->($cb, $ecb);
	}
}

sub createFeed {
	my ($client, $callback, $args) = @_;

	_asyncMerge(
		$callback,
		
		\&_radikoItems,
		\&_radiruItems,
		\&_simulRadioItems,
	);
}

1;
