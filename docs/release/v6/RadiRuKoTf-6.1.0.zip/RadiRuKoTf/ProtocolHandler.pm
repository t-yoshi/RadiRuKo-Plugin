# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoTf::ProtocolHandler; 
use utf8;
use strict;
use POSIX qw(strftime);
use Slim::Utils::Log;

use Plugins::RadiRuKoTf::Feed;
use Plugins::RadiRuKo::AuthRadiko;
use Plugins::RadiRuKo::RadikoMeta;
use Plugins::RadiRuKo::Utils qw(parseDateTime jptime jpShortDateTimeF);

use base qw(Plugins::RadiRuKo::FFMpegHandler);

my $log = logger('plugin.radiruko');


sub new {
	my $class  = shift;
	my $args   = shift;

	my $client = $args->{client};
	
	my $song = $args->{song};
	my $authToken = $song->pluginData('authToken') || return;
	
	my ($stId, $ft, $to, $ftET, $toET) 
			= @{$song->pluginData('parsedUrl')};

	$args->{ffoptions} = {
		'-user_agent', 'Mozilla/5.0',
		'-timeout', 10_000, #milliseconds
		'-post_data', unpack('H*', "flash=1\r\n"), #ffmpeg binary option
		'-headers', "X-Radiko-AuthToken: $authToken",
	};
	my $seek;
	my $offset = ($song->seekdata() || {})->{timeOffset};
	if ($offset){
		#ex 20161013051000
		$seek = strftime('%Y%m%d%H%M%S', jptime($ftET + $offset));
		$args->{ffoptions}{'-ss'} = "+$offset"; #ffmpeg-seek
		$song->startOffset($offset);
	}
	$args->{url} = _m3u8Url($stId, $ft, $to, $seek);
	$song->duration($toET - $ftET);

	return $class->SUPER::new($args);
}


sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $client = $song->master();
	my $url = $song->track()->url;

	my @parsedUrl = Plugins::RadiRuKoTf::Feed::parseUrl($url) or 
			return $errorCb->("Invalid URL: $url");

	$song->pluginData(parsedUrl=>\@parsedUrl);

	Plugins::RadiRuKo::AuthRadiko->new(
		sub { 
			my ($authToken, $areaId) = @_;
			$song->pluginData(authToken=>$authToken);
			$successCb->();
		}, 
		sub {
			my ($error) = @_;
			$errorCb->($error);
		}
	)->execute();
}

sub canSeek {
	my ($class, $client, $song) = @_;
	return 1;
}

sub getSeekData {
	my ($class, $client, $song, $newtime) = @_;
	#$log->debug($newtime);
	return {
		timeOffset => int($newtime),
	};
}

sub getMetadataForAsync {
	my ($class, $client, $url, $callback) = @_;

	my ($stId, $ft, $to, $ftET, $toET) 
			= Plugins::RadiRuKoTf::Feed::parseUrl($url) or return;

	Plugins::RadiRuKo::RadikoMeta::metaProviderAsync(
		$client, sub {
			my $meta = shift;
			$meta->{title} .= ' (' . jpShortDateTimeF($ftET) . '～)';
			$meta->{duration} = $toET - $ftET;
			$meta->{_expire} = 4102444800; #2100年
			$callback->($meta);
		}, $stId, 'TimeFree', $ftET
	);
}

sub _m3u8Url {
    my ($stId, $ft, $to, $seek) = @_;
    my $u = "https://radiko.jp/v2/api/ts/playlist.m3u8?station_id=${stId}&l=15&ft=${ft}&to=${to}";
	$u .= "&seek=${seek}" if $seek;
	return $u;
}

1;
