# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoTf::Feed;

use utf8;
use strict;

use Tie::IxHash;
use URI::Escape qw(uri_escape_utf8);
use POSIX qw(strftime);

use Slim::Utils::Log;
use Slim::Utils::DateTime;
use Slim::Utils::Prefs;
use Slim::Utils::Strings;

use Plugins::RadiRuKo::RadikoMeta;
use Plugins::RadiRuKo::AuthRadiko;
use Plugins::RadiRuKo::Utils qw(
	$PatRadikoId 
	fetchXml jptime parseDateTime stripTagAndAbbreviate 
	fetchJson jpShortDateTimeF enabledPremiumPlugin);

use Data::Dumper;

my $log = logger('plugin.radiruko');
my $prefs = preferences('plugin.radiruko');

my @Wday = qw(Sun Mon Tue Wed Thu Fri Sat);

#
# URL形式
#
# 完全指定 radikotf://LFR/20171113110000-20171113112000
#   or
# 省略指定 radikotf://LFR/1100(Mon)-1120(Mon)
#  (週単位の番組をお気に入りに登録しやすくする)
#
sub _createUrl {
	my ($self, $stationId, $ftStrTime, $toStrTime) = @_;

	my $ftET = parseDateTime($ftStrTime);

	if ($self->{now} - $ftET > 7*24*60*60){
		$ftStrTime =~ s/[\- \:]//g;
		$toStrTime =~ s/[\- \:]//g;
	} else {
		sub __shortDatefmt {
			my @tm = jptime(shift);
			sprintf('%s(%s)',
				strftime($tm[0] ? '%H%M%S' : '%H%M', @tm),
				$Wday[$tm[6]]
			)
		}
		$ftStrTime = __shortDatefmt($ftET);
		my $toET = parseDateTime($toStrTime);
		$toStrTime = __shortDatefmt($toET);
	}
	return "radikotf://$stationId/$ftStrTime-$toStrTime";
}

#
#戻り値: (stationId, ft, to, ftEpochTime, toEpochTime)
#
sub parseUrl {
	if ($_[0] =~ m|^radikotf://($PatRadikoId)/(\d+)\-(\d+)/?|){
		return ($1, $2, $3, parseDateTime($2), parseDateTime($3));
	}

	my $grDateFmt = sprintf(
		# hhmm[ss](www)
		'(\d{4})(\d{2})?\((%s)\)',
		join('|', @Wday)
	);

	my ($stationId, $ft_hhmm, $ft_ss, $ft_wday, $to_hhmm, $to_ss, $to_wday) = 
		$_[0] =~ m|^radikotf://($PatRadikoId)/$grDateFmt-$grDateFmt/?| or return;
	my $now = time();

	#過去一週間の日付。([Mon,20171113],[Sun,20171112],[Sat,20171111] ...
	my @weekdays = map { 
		my @tm = jptime($now - $_*24*60*60);
		[$Wday[$tm[6]], strftime('%Y%m%d', @tm)]
	} 0..7;

	my ($ft, $to);
	for (@weekdays){
		$to = $_->[1] if (!$to && $_->[0] eq $ft_wday);
		if ($to && $_->[0] eq $to_wday){
			$ft = $_->[1];
			last;
		}
	}

	$ft .= $ft_hhmm . ($ft_ss or '00');
	$to .= $to_hhmm . ($to_ss or '00');

	return ($stationId, $ft, $to, parseDateTime($ft), parseDateTime($to));	
}

#
# 簡略化された時刻と曜日から推測して直近のエポック時間を返す。
# 
# 引数: 開始時刻, 終了時刻, [開始時刻の曜日]
# 戻り値: 開始、終了時刻のエポック時間
# 例:
#  '1100', '1200', 'Wed' -> 直近水曜日の11時から12時
#  '11:00', '12:00:00', undef -> 直近の11時から12時
#
sub _parseLatestTime {
	my ($f, $t, $w) = @_;
	my $now = time();

	#過去一週間の曜日/日付 ([Mon,20171113],[Sun,20171112],[Sat,20171111] ...
	my @latestDays = map { 
		my @tm = jptime($now - $_*24*60*60);
		[$Wday[$tm[6]], strftime('%Y%m%d', @tm)]
	} 0..7;
	
	for (@latestDays){
		next if ($w && $w ne $_->[0]);
		
		my $fet = parseDateTime($_->[1] . "T$f");
		my $tet = parseDateTime($_->[1] . "T$t");

		if ($tet < $fet){ #日付またぎの番組
			$tet += 24*60*60;
		}

		if ($tet > $now){ #まだ終わっていないので先週の番組
			$fet -= 7*24*60*60;
			$tet -= 7*24*60*60;
		}

		return ($fet, $tet);		
	}
	return undef;
}


sub _xmlErrorHandler {
	my $callback = shift;
	my $items = shift || [];
	return sub {
		my ($err, $url) = @_;
		push @$items, { title => "$err: $url" };
		$callback->($items);		
	};
}

#
# *一部NG **全部?
#
sub _createProgramItems {
	my ($self, $stationId, $date) = @_;

	return sub {
		my ($client, $callback, $args) = @_;

		my $onParse = sub {
			my $xml = shift;

			my @progs = grep {
				parseDateTime($_->{to}) < $self->{now};
			} @{$xml->{stations}{station}{progs}{prog}};

			$callback->([map {
				+{
					title => sprintf(
						'%s%s',
						'*' x int($_->{ts_in_ng}{content}),
						$_->{title}{content}
					),
					icon  => 'html/images/radio.png',
					url   => $self->_createUrl($stationId, $_->{ft}, $_->{to}),
					type  => 'audio',
				}
			} @progs]);
		};

		Plugins::RadiRuKo::RadikoMeta::fetchProgramXml(
			$stationId, $date, $onParse, _xmlErrorHandler($callback));
	};
}

sub _fetchStationXml {
	my $self = shift;

	if (1 and $self->{isPremium}) {
		Plugins::RadiRuKoPr::Plugin::fetchAllStationXml(@_, 1);
	} else {
		my $u = 'http://radiko.jp/v3/station/list/' . $self->{areaId} . '.xml';
		fetchXml($u, @_, cacheExpire=>'30 days');
	}	
}

sub _createStationItems {
	my ($self, $date) = @_;
	return sub {
		my ($client, $callback, $args) = @_;

		my $onParse = sub {
			my $xml = shift;
			#$log->info(Dumper($xml));
			my @stations = @{$xml->{station}};			
			
			unless (0){ #現在らじるは無し $prefs->get('enable_radiko_nhk')
				@stations = grep { $_->{name}{content} !~ /^NHK/ } @stations;
			}
			
			$callback->([ map {
				+{
					title => $_->{name}{content},
					icon  => $_->{logo}->[0]->{content},
					url   => $self->_createProgramItems($_->{id}{content}, $date),
				};
			} @stations ]);
		};

		$self->_fetchStationXml($onParse, _xmlErrorHandler($callback));
	};
}

#
# 検索
#

#URIが古くて日本語含みのquery_formが機能しない
sub urlencode {
	tie(my %q, 'Tie::IxHash', @_);
	return join '&', map {
		$_ . '=' . uri_escape_utf8($q{$_});
	} keys %q;
}

sub ROW_LIMIT() { 50 }

sub _fetchSearchJson {
	my $self  = shift;
	my $query = shift;
	my $page  = shift;

	my $uid = preferences('plugin.radiruko')->cookie_rdk_uid();
	my $regionId = $self->{isPremium} ? 'all' : '';
	my $areaId = $self->{areaId};	
	

	my $u = 'http://radiko.jp/v3/api/program/search?' . urlencode(
		key=>$query, filter=>'past', start_day=>'', end_day=>'',
		area_id=>$areaId, region_id=>$regionId,
		cul_area_id=>$areaId, page_idx=>$page, uid=>$uid, 
		app_id=>'pc', row_limit=>ROW_LIMIT);

	$log->debug($u) if ($log->is_debug);

	fetchJson($u, @_);
}

sub _searchTimeFree {
	my ($self, $query, $page, $items, $callback) = @_;

	my $onParse = sub {
		my $hash = shift;
		push @$items, map {
			+{
				title => sprintf('%s (%s - %s)', $_->{title},
							$self->stationName($_->{station_id}),
							jpShortDateTimeF(parseDateTime($_->{start_time}))
						),
				url   => $self->_createUrl($_->{station_id}, $_->{start_time}, $_->{end_time}),
				type  => 'audio',
				_sortKey => $_->{start_time} . '#' . $_->{title},
			}
		} @{$hash->{data}};

		$log->debug("p=$page, r=" . $hash->{meta}{result_count}) if $log->is_debug;

		if ($page < 3 && $hash->{meta}{result_count} > ROW_LIMIT*(1+$page)){
			# 次のページのために再帰
			return $self->_searchTimeFree($query, $page+1, $items, $callback);
		}
		
		#@$items = sort { $b->{_sortKey} cmp $a->{_sortKey} } @$items;
		$callback->($items);			
	};

	$self->_fetchSearchJson($query, $page, 
		$onParse, _xmlErrorHandler($callback, $items)
	);
}

sub stationName {
	my ($self, $stId, $stName) = @_;
	if (defined $stName){ #setter
		$self->{stationNames}{ $stId } = $stName;
	} else { #getter
		return $self->{stationNames}{ $stId } || $stId;		
	}
}

sub new {
	my ($class) = @_;
	my $self = bless {
		areaId => 'JP13',
		isPremium => enabledPremiumPlugin(),
		now => time(),
		stationNames => {}, #stationId=>stationName
	}, $class;

	Plugins::RadiRuKo::AuthRadiko->new(
		sub {
			my ($authToken, $areaId) = @_;
			$self->{areaId} = $areaId;
		}
	)->execute('cache');
	
	fetchXml(
		'http://radiko.jp/v3/station/region/full.xml', 
		sub {
			my $xml = shift;
			my @station = map(@{$_->{station}}, @{$xml->{stations}});
			for (@station){
				$self->stationName(
					$_->{id}{content}, 
					$_->{name}{content}); 					
			}
		}, cacheExpire=>'30 days'
	);

	return $self;
}

sub _weekdayIcon {
	my ($sec,$min,$hour,$mday,$mon,$year,$wday) = jptime($_[0]);
	return "plugins/RadiRuKoTf/html/images/wday$wday.png";
}


#
#  2017/10/01 -> (Stations) -> (Programs)
#
sub createFeed {
	my ($client, $callback, $args) = @_;

	my $feed = __PACKAGE__->new();

	#1週間分 (5時更新)
	my @times = map { $feed->{now} - ($_*24+5)*60*60 } 0..7;
	my @items = map {
		+{
			title => Slim::Utils::DateTime::longDateF($_),
			icon  => _weekdayIcon($_),
			url   => $feed->_createStationItems($_),
		};
	} @times;

	$items[0]{title} = Slim::Utils::Strings::string('PLUGIN_RADIRUKO_TODAY');
	$items[1]{title} = Slim::Utils::Strings::string('PLUGIN_RADIRUKO_YESTERDAY');

	push @items, {
		title => Slim::Utils::Strings::string('SEARCHFOR'),
		icon  => 'html/images/search.png',
		type  => 'search',		
		url   => sub {
			my ($client, $callback, $args) = @_;
			$feed->_searchTimeFree($args->{search}, 0, [], $callback);
		},
	};

	$callback->(\@items);
}



1;