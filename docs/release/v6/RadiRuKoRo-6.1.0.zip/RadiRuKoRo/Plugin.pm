# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoRo::Plugin;

use strict;

use Slim::Formats::RemoteMetadata;
use Slim::Utils::Log;

use base qw(Slim::Plugin::OPMLBased);

my $log;

sub getDisplayName {
	return 'PLUGIN_RADIRUKO_RADIRU_ONDEMAND_NAME';
}

sub initPlugin {
	my $class = shift;

	$class->SUPER::initPlugin(
		tag    => 'RadiRuKoRo',
		menu   => 'radios',
		weight => 1.04, # ラジオの先頭にメニュー表示
	);

	my $minBasicVersion = $class->_pluginDataFor('_minBasicVersion');
	my $basicFound = eval {
		require Plugins::RadiRuKo::Utils;		
		Plugins::RadiRuKo::Utils::checkBasicVersion($minBasicVersion);
	};
	if ($@ || !$basicFound){
		logError("Please install BasicPlugin >= $minBasicVersion");
		return;
	}

	$log = logger("plugin.radiruko");
	$log->debug('Initialising.. RadiRuKoRadiduOndemand-Plugin v' . $class->_pluginDataFor('version'));

	require Plugins::RadiRuKoRo::Feed;
	require Plugins::RadiRuKoRo::ProtocolHandler;

	Slim::Player::ProtocolHandlers->registerHandler(
		'radiruod', q(Plugins::RadiRuKoRo::ProtocolHandler)
	);

	return 1;
}

sub feed {
	my ($class) = @_;	
	return \&Plugins::RadiRuKoRo::Feed::createFeed;
}

sub playerMenu { 'RADIO' }

sub getFunctions(){ return {}; }


1;
