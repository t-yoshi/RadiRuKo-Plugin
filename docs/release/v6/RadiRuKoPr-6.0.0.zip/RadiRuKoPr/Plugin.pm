# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKoPr::Plugin;

use strict;

use Slim::Utils::Misc;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Strings;

use Plugins::RadiRuKoPr::Settings;
use Data::Dumper;

use base qw(Slim::Plugin::OPMLBased);

our @allstation;

my $prefs;
my $log;

sub getDisplayName {
	return 'PLUGIN_RADIRUKO_PREMIUM_NAME';
}

sub initPlugin {
	my $class = shift;

	my $minBasicVersion = $class->_pluginDataFor('_minBasicVersion');
	my $basicFound = eval {
		require Plugins::RadiRuKo::Utils;		
		Plugins::RadiRuKo::Utils::checkBasicVersion($minBasicVersion);
	};
	if ($@ || !$basicFound){
		logError("Please install BasicPlugin >= $minBasicVersion");
		return;
	}

	$prefs = preferences('plugin.radiruko');
	$log = logger("plugin.radiruko");
	
	$log->info("Register protocol: radikop");
	Slim::Player::ProtocolHandlers->registerHandler(
		"radikop", q(Plugins::RadiRuKo::RadikoHandler)
	);

	require Plugins::RadiRuKo::RadikoHandler;	
	Plugins::RadiRuKo::Utils->import(qw(fetchXml fetchJson));

	$class->SUPER::initPlugin(
		tag    => 'RadiRuKoPr',
		menu   => 'radios',
		weight => 1.02, # ラジオの先頭にメニュー表示
	);

	Plugins::RadiRuKoPr::Settings->new();

	return 1;
}

sub _failedFeed {
	return +{
		title => Slim::Utils::Strings::string('PLUGIN_RADIRUKO_PREMIUM_NAME'),
		items => [ {title => shift} ],
	};
}

sub _createFeed {
	my ($client, $callback, $args) = @_;

	my $cb = sub {
		my $xml = shift;

		my @items = map {
			+{
				title => $_->{name}{content},
				url   => 'radikop://' . $_->{id}{content},
				icon  => $_->{logo}->[0]->{content},
				type  => 'audio',
			};
		} @{$xml->{station}};
		#$log->debug(Dumper(\@items));
		
		$callback->({
			title => Slim::Utils::Strings::string('PLUGIN_RADIRUKO_PREMIUM_NAME'),
			items => \@items,
		});
	};

	my $ecb = sub {
		my $err = shift;
		$callback->(_failedFeed($err));
	};

	fetchAllStationXml($cb, $ecb, 1);
}

#成功: ->{station} = [station, ..]
sub fetchAllStationXml {
	my $cb = shift;
	my $ecb = ref($_[0]) eq 'CODE' ? shift : undef;
	my $isFavoSorted = shift || 0; #お気に入りを先頭にするか

	my $onParse = sub {
		my $xml = shift;
		my @station = map(@{$_->{station}}, @{$xml->{stations}});
		@station = grep { $_->{name}{content} !~ /^NHK/ } @station;
		
		if ($isFavoSorted){
			my $i=0;
			#id => priority
			my %sortKey = map { $_, $i++ - 1000 } favoriteStations();
			for (@station){
				my $id = $_->{id}{content};
				$sortKey{$id} ||= $i++;
			}
			@station = sort { $sortKey{$a->{id}{content}} <=> $sortKey{$b->{id}{content}} } @station;
		}
		$cb->({station=>\@station});
	};

	fetchXml(
		'http://radiko.jp/v3/station/region/full.xml', 
		$onParse, $ecb, cacheExpire=>'30 days'
	);
}

#上位に表示させる「お気に入り」 ex.(HBC,TBS)
sub favoriteStations {
	if (@_ > 0){ #set
		my %h; #重複削除
		my @stations = grep { $_ and ! $h{ $_ }++ } @_;
		$prefs->premium_favorite_stations(join(',', @stations));
	} 
	my $s = $prefs->premium_favorite_stations();
	return wantarray ? split(/,/, $s) : $s;
}



sub feed {
	my $class = shift;
	my $client = shift;

	unless ($prefs->get('cookie_radiko_session')){
		return _failedFeed('Require radiko_session');
	}

	return \&_createFeed;
}


sub playerMenu { 'RADIO' }

sub getFunctions(){ return {}; }

1;
