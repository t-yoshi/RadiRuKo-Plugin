# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadikoAuth;

use strict;
use HTTP::Request;
use IO::File;
use MIME::Base64;
use Digest::MD5 qw(md5_hex);
use Slim::Utils::Log;
use Slim::Utils::Misc;
use Slim::Utils::Prefs;
use Slim::Networking::Async::HTTP;
use Slim::Networking::SimpleAsyncHTTP;
use Slim::Networking::Async::HTTP;
use Plugins::RadiRuKo::Utils qw(getCache);
use Exporter 'import';

our @EXPORT_OK = qw/getAsyncHttpsClient UA/;

sub UA       {'Mozilla/5.0 like Gecko'}
sub AUTH_KEY {'bcd151073c03b352e1ef2fd66c32209da9ca0afa'}

#HTTPS Client
my $asyncHttpsClient;

my $prefs = preferences('plugin.radiruko');
my $log   = Slim::Utils::Log::logger('plugin.radiruko');

#
#  一部のNASではSSL関連のモジュールがインストールされていないので、
# SimpleAsyncHTTPでhttpsを扱えないことがある。
# その場合は自前のcurlコマンドでhttpsにアクセスする。
#
sub getAsyncHttpsClient {

    unless ($asyncHttpsClient) {
        $prefs->cookie_rdk_uid(md5_hex(int(rand(10000)) . time()));

        if (Slim::Networking::Async::HTTP->hasSSL()) {
            # Win, Mac, 大多数のLinux
            $asyncHttpsClient = q(Slim::Networking::SimpleAsyncHTTP);

            #古いradiko_sessionが残るのでクリア
            Slim::Networking::Async::HTTP->cookie_jar()->clear('radiko.jp');
        } else {
            # 一部のNAS
            require Plugins::RadiRuKo::CurlAsyncHTTP;
            Plugins::RadiRuKo::CurlAsyncHTTP::init();
            $asyncHttpsClient = q(Plugins::RadiRuKo::CurlAsyncHTTP);
        }
        $log->info("HttpsClient is $asyncHttpsClient");
    }

    return $asyncHttpsClient;
}

#
# 非同期でradiko認証を行う。
# 成功した場合、結果を10分間キャッシュする。
#
# コールバック:
# cb  ->(authToken, areaId)
# ecb ->(errMsg)
#
sub new {
    my $class = shift;
    my $cb    = shift;
    my $ecb   = shift || sub { $log->error($_[0]); };

    my $radiko_session = eval {
        require Plugins::RadiRuKoPr::RadikoLogin;
        Plugins::RadiRuKoPr::RadikoLogin->get_radiko_session();
    };

    my $cacheKeyPrefix = 'radiruko:RadikoAuth-';
    if ($radiko_session) {
        $log->debug("Premium: radiko_session=$radiko_session")
            if $log->is_debug;
        $cacheKeyPrefix .= $radiko_session . '-';
    }

    my $basedir = Plugins::RadiRuKo::Plugin->_pluginDataFor('basedir');

    return bless {
        cb  => $cb,
        ecb => $ecb,

        cookie_rdk_uid => $prefs->get('cookie_rdk_uid'),
        radiko_session => $radiko_session,
        cacheKeyPrefix => $cacheKeyPrefix,

        #SimpleAsyncHTTPのエラーハンドラ
        httpClientErrorCb => sub {
            my ($http, $err) = @_;
            $ecb->($err);
        },
    }, $class;
}

sub _defaultRequestHeader {
    my $self   = shift;
    my $cookie = 'rdk_uid=' . $self->{cookie_rdk_uid};

    return (
        'User-Agent'           => UA,
        'pragma'               => 'no-cache',
        'Cookie'               => $cookie,
        'Referer'              => 'https://radiko.jp/',
        'X-Radiko-App'         => 'pc_html5',
        'X-Radiko-App-Version' => '0.0.1',
        'X-Radiko-User'        => 'dummy_user',
        'X-Radiko-Device'      => 'pc',
    );
}

sub _auth1 {
    my ($self) = @_;

    $log->debug("auth1: Start");

    getAsyncHttpsClient()->new(
        sub {
            my $http    = shift;
            my $headers = $http->headers;
            $log->debug("auth1: OK");

            $self->{authToken} = $headers->header("x-radiko-authtoken");
            $self->{keyoffset} = int($headers->header("x-radiko-keyoffset"));
            $self->{keylength} = int($headers->header("x-radiko-keylength"));

            $self->_auth2();
        },
        $self->{httpClientErrorCb}
    )->get(
        'https://radiko.jp/v2/api/auth1',
        $self->_defaultRequestHeader()
    );
}

sub _partialkey {
    my ($self) = @_;

    my $buf = substr(AUTH_KEY, $self->{keyoffset}, $self->{keylength});
    return MIME::Base64::encode_base64($buf, '');
}

sub _auth2 {
    my ($self) = @_;

    $log->debug("auth2: Start");

    my $partKey = $self->_partialkey() or return;
    my $u       = 'https://radiko.jp/v2/api/auth2';

    if ($self->{radiko_session}) {
        $u .= '?radiko_session=' . $self->{radiko_session};
    }

    getAsyncHttpsClient()->new(
        sub {
            my $http = shift;
            $log->debug("auth2: OK");

            if (${ $http->contentRef } =~ /(JP\d+)/) {
                my $authToken = $self->{authToken};
                my $areaId    = $1;

                # エリアID
                $self->_storeCache(areaId => $areaId, '12 hour'),

                    # 成功した場合、トークンを10分間Cacheする。
                    $self->_storeCache(authToken => $authToken, '10 min'),

                    $self->{cb}->($authToken, $areaId);
            } else {
                $self->{ecb}->('fail auth2: Bad areaId');
            }
        },
        $self->{httpClientErrorCb}
    )->get(
        $u,
        $self->_defaultRequestHeader(),
        'X-Radiko-Authtoken'  => $self->{authToken},
        'X-Radiko-Partialkey' => $partKey
    );
}

# 実行する。
# mode:
#	'force' キャッシュを破棄
#	'cache' areaIdがキャッシュされていれば返す
#
sub execute {
    my $self = shift;
    my $mode = shift || '';

    #Cache
    my $areaId    = $self->_fromCache('areaId');
    my $authToken = $self->_fromCache('authToken');

    if ($mode eq 'cache' && $areaId) {
        $self->{cb}->($authToken, $areaId);
        return;
    }

    if ($mode ne 'force' && $areaId && $authToken) {
        $self->{cb}->($authToken, $areaId);
        return;
    }

    $self->_auth1();
}

sub _storeCache {
    my ($self, $key, $value, $expire) = @_;
    getCache()->set($self->{cacheKeyPrefix} . $key, $value, $expire);
}

sub _fromCache {
    my ($self, $key) = @_;
    return getCache()->get($self->{cacheKeyPrefix} . $key);
}

1;
