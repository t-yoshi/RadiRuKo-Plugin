package Plugins::RadiRuKo::Feed;
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
use utf8;
use strict;

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Formats::XML;
use Slim::Utils::Strings q(string);
use Plugins::RadiRuKo::Utils qw(fetchXml localized dstring);
use Plugins::RadiRuKo::RadiruConfig;
use Plugins::RadiRuKo::RadikoAuth;
use Data::Dumper;

my $log   = logger('plugin.radiruko');
my $prefs = preferences('plugin.radiruko');

sub _radiruRegion {
    my $area  = shift;    #ex: tokyo
    my $addR2 = shift;    #R2を含めるか

    my $data = Plugins::RadiRuKo::RadiruConfig->data('area' => $area);

    #$log->debug(Dumper $data);
    my @items;

    for my $channel (qw(R1 R2 FM)) {
        next if ($channel eq 'R2' && !$addR2);

        my $area    = ucfirst($data->{area});
        my $areajp  = $data->{areajp};
        my $areakey = $data->{areakey};

        if ($channel eq 'R2' and $area !~ /tokyo/i) {
            $area   = 'Tokyo';
            $areajp = $areakey = '';
        }

        #ローカル局: R1の後にFMを並べる
        my $sortkey = ($channel eq 'FM') ? '1#' : '0#';

        push @items, {
            name => dstring(
                "PLUGIN_RADIRUKO_NHK_$channel",
                JA => [$areajp],
                EN => [$area]
            ),
            url  => "radiru://$channel-$area",
            icon => "plugins/RadiRuKo/html/images/NHK_$channel.png",
            type => 'audio',

            _sortkey => $sortkey . $areakey,
        };
    }
    return @items;
}

sub _radiruItems {
    my ($cb, $ecb) = @_;

    my @areas = Plugins::RadiRuKo::RadiruConfig->area();

    return $ecb->('config not loaded') unless (@areas);

    my $mainArea = $prefs->get('radiru_area') || 'tokyo';

    my @items = _radiruRegion($mainArea, 1);

    my @locals;
    for my $area (grep { $_ ne $mainArea } @areas) {
        push @locals, _radiruRegion($area);
    }

    #R1を先に持ってくる
    @locals = sort { $a->{_sortkey} cmp $b->{_sortkey} } @locals;

    push @items,
        +{
        title => string('PLUGIN_RADIRUKO_NHK_LOCAL_STATIONS'),
        icon  => 'html/images/radio.png',
        items => \@locals,
        };

    $cb->(\@items);
}

sub _radikoItems {
    my ($cb, $ecb) = @_;

    my $onAuth = sub {
        my (undef, $areaId) = @_;
        my $title = string("PLUGIN_RADIRUKO_RADIKO_AREA_$areaId");

        $areaId =~ /JP(\d+)/;

        fetchXml(
            "https://radiko.jp/v3/station/list/${areaId}.xml",
            sub {
                my $xml      = shift;
                my @stations = @{ $xml->{station} };

                #radikoでのNHKを表示するか
                unless ($prefs->get('enable_radiko_nhk')) {
                    @stations = grep { $_->{name} !~ /^NHK/ } @stations;
                }

                my @items = map {
                    my $name = localized(JA => $_->{name}, EN => $_->{ascii_name});
                    $name .= '[via radiko]' if $_->{name} =~ /^NHK/;
                    +{
                        name => Slim::Formats::XML::unescapeAndTrim($name),
                        url  => 'radiko://' . $_->{id},
                        icon => $_->{logo}[0]->{content},
                        type => 'audio',
                    };
                } @stations;

                $cb->({
                        title => $title,
                        items => \@items,
                    }
                );
            },
            $ecb,
            expires => '10 days'
        );
    };

    Plugins::RadiRuKo::RadikoAuth->new(
        $onAuth,
        sub {
            $ecb->(string('PLUGIN_RADIRUKO_RADIKO_AREA_UNKNOWN'));
        }
    )->execute('cache');
}

sub _simulRadioItems {
    my ($cb, $ecb) = @_;
    $cb->([ {
                name => string('PLUGIN_RADIRUKO_COMMUNITY_STATIONS'),
                icon => "html/images/radio.png",
                url  => 'https://t-yoshi.github.io/RadiRuKo-Plugin/feed/simulradio-8.opml',
                type => 'link',
            }
        ]
    );
}

#1-9,0のリモコン数字ボタン
sub _setTextKey {
    my $items = shift;
    my $key   = 0;
    for (@$items) {
        if ($_->{type} eq 'audio') {
            last if ++$key > 10;
            $_->{textkey} = substr($key, -1);
        }
    }
}

sub _asyncMerge {
    my $callback   = shift;
    my @generators = @_;

    my %results = map { $_, undef } @generators;

    my $onMerge = sub {
        my $mergedFeed = {
            title => string('PLUGIN_RADIRUKO_NAME'),
            items => [],
        };
        for my $g (@generators) {
            my $feed = $results{$g};
            if (ref($feed) eq 'ARRAY') {
                push @{ $mergedFeed->{items} }, @$feed;
            } else {
                $mergedFeed->{title} .= $feed->{title};
                push @{ $mergedFeed->{items} }, @{ $feed->{items} };
            }
        }
        _setTextKey($mergedFeed->{items});

        #$log->debug(Dumper($mergedFeed));
        $callback->($mergedFeed);
    };

    for my $g (@generators) {
        my $cb = sub {
            $results{$g} = shift || [];

            $log->debug(Dumper(\%results)) if $log->is_debug;

            $onMerge->() unless (grep { !defined } values(%results));
        };
        my $ecb = sub {
            my $error = shift;
            $cb->([ {
                        title => "$error",
                        items => [],
                    }
                ]
            );
        };
        $g->($cb, $ecb);
    }
}

sub createFeed {
    my ($client, $callback, $args) = @_;

    _asyncMerge(
        $callback,

        \&_radikoItems,
        \&_radiruItems,
        \&_simulRadioItems,
    );
}

1;
