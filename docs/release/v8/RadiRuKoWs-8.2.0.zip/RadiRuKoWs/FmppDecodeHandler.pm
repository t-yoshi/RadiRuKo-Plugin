# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoWs::FmppDecodeHandler;

use strict;
use Slim::Utils::Misc;
use Slim::Utils::Log;

#use Data::Dumper;
use Slim::Control::Request;
use Plugins::RadiRuKo::FFMpegHandler;
use Plugins::RadiRuKoWs::FmppClient;

use base qw(
    Slim::Player::Pipeline
    Plugins::RadiRuKo::MetadataHandler
);

my $log = logger('plugin.radiruko');

sub new {
    my $class = shift;
    my $args  = shift;

    my $transcoder = $args->{transcoder};
    my $url        = $args->{url};
    my $client     = $args->{client};

    $log->debug("url: $url");

    #48KHzを変えたくない
    my $song  = $args->{song};            ## Slim::Player::Song
    my $track = $song->currentTrack();    ## Slim::Schema::RemoteTrack
    $track->samplerate(48000);
    $track->samplesize(16);

    my $source = Plugins::RadiRuKoWs::FmppClient->new($args) or return;

    my $cmd = _build_command();
    $log->debug("Command: $cmd");

    my $self = $class->SUPER::new($source, $cmd, 0);

    #	${*$self}{contentType} = $format;

    return $self;
}

sub _build_command {

    #	my $opusdec = Slim::Utils::Misc::findbin('opusdec');
    #	if ($opusdec){
    #		return sprintf(
    #			'"%s" --quiet --rate 48000 - -',
    #			$opusdec
    #		);
    #	}

    my $ffpath = Plugins::RadiRuKo::FFMpegHandler->find_ffmpeg();
    if ($ffpath) {
        return sprintf('"%s" -i - -loglevel error -f s16le -ar 48000 -ac 2 -', $ffpath);
    }

    $log->error('Please install opus decoder.');
    return undef;
}

sub getNextTrack {
    my $class = shift;
    return Plugins::RadiRuKoWs::FmppClient->getNextTrack(@_);
}

sub canHandleTranscode {0}

sub getStreamBitrate { 48_000 * 16 * 2 }

sub contentType        {'audio/x-wav'}
sub getFormatForURL () {'wav'}
sub canDirectStream    {0}
sub isRemote           {1}
sub isAudioURL         {1}

1;
