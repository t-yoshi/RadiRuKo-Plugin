# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKoWs::Plugin;

use strict;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::OSDetect;
use Slim::Music::Info;

use base qw(Slim::Plugin::Base);

use Plugins::RadiRuKo::Utils 8.2;

sub getDisplayName {'PLUGIN_RADIRUKO_WS_NAME'}

sub initPlugin {
    my $class = shift;

    my $log = logger('plugin.radiruko');
    $log->info('Register protocol: fmpp, jcba');

    #use Plugins::RadiRuKoWs::BaseWebSocketHandler;
    require Plugins::RadiRuKoWs::FmppClient;
    require Plugins::RadiRuKoWs::FmppDecodeHandler;

    #TODO: 一部アーキのsoxでopusがサポートされていない
    my $handler =
        0 && _isOpusSupported()
        ? q(Plugins::RadiRuKoWs::FmppClient)
        : q(Plugins::RadiRuKoWs::FmppDecodeHandler);
    Slim::Player::ProtocolHandlers->registerHandler(fmpp => $handler);
    Slim::Player::ProtocolHandlers->registerHandler(jcba => $handler);

    $class->SUPER::initPlugin();
}

sub _isOpusSupported() {
    #一部arm-linux(armv5te)でlibopusが原因のノイズが
    #発生するのでffmpegでデコードする
    my $osDetails = Slim::Utils::OSDetect::details();
    return 0 if $osDetails->{binArch} =~ /arm-linux/;

    #opusのサポートは7.9.2以降
    return defined $Slim::Music::Info::types{ops};
}

sub getFunctions() { return {}; }

1;
