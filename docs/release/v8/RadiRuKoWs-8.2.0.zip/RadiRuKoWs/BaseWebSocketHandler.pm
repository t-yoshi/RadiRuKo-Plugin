package Plugins::RadiRuKoWs::BaseWebSocketHandler;

use strict;

use base q(IO::Handle);
use IO::Socket::SSL qw/SSL_VERIFY_NONE/;
use IO::Socket::INET;
use Time::HiRes q(time);
use Slim::Utils::Log;
use Slim::Utils::Network;
use Slim::Utils::Prefs;
use Slim::Utils::Errno;
use Slim::Networking::IO::Select;
use Slim::Networking::Select;
use Protocol::WebSocket::URL;
use Protocol::WebSocket::Frame;
use Protocol::WebSocket::Handshake::Client;
use Data::Dumper;

use constant MAX_CHUNK_SIZE      => 32 * 1024;
use constant MAX_READBUFFER_SIZE => 512 * 1024;

my $log   = logger('plugin.radiruko');
my $prefs = preferences('server');

sub new {
    my $class = shift;
    my $args  = shift;

    if (ref $args->{ws_url} ne 'Protocol::WebSocket::URL') {
        if ($args->{ws_url} !~ m|^wss?://|) {
            $log->error('Invalid Websocket Url: ' . $args->{ws_url});
            return;
        }
        $args->{ws_url} = Protocol::WebSocket::URL->new->parse($args->{ws_url});
    }
    $log->debug('ws_url=' . $args->{ws_url}->to_string);

    my $timeout = $args->{'timeout'} || $prefs->get('remotestreamtimeout');
    my $sock;
    my $err = 'Failed open: ' . $args->{ws_url}->to_string;

    if ($args->{ws_url}->{secure}) {
        $sock = IO::Socket::SSL->new(
            PeerHost        => $args->{ws_url}{host},
            PeerPort        => $args->{ws_url}{port},
            SSL_verify_mode => SSL_VERIFY_NONE,
            Timeout         => $timeout,
            )
            or do {
            $err .= " [$!] " . IO::Socket::SSL::errstr();
            };
    } else {
        $sock = IO::Socket::INET->new(
            PeerAddr => $args->{ws_url}{host},
            PeerPort => $args->{ws_url}{port},
            Timeout  => $timeout,
        );
    }

    unless (defined $sock) {
        $log->error($err);
        return;
    }

    ${*$sock}{_sel} = IO::Select->new($sock);
    Slim::Utils::Network::blocking($sock, 0);

    $class->_ws_handshake($args, $sock, $timeout) || do {
        $sock->close();
        return;
    };

    my $self = $class->SUPER::new();

    ${*$self}{_ws_sock}        = $sock;
    ${*$self}{_ws_frame}       = _build_frame();
    ${*$self}{_ws_read_buffer} = '';
    ${*$self}{_ws_eof}         = 0;

    ${*$sock}{passthrough} = [$self];
    addRead($sock, \&_sock_on_read);

    return $self;
}

sub _ws_on_new_handshake_client {
    my ($class, $args, $hs) = @_;
}

sub _ws_handshake {
    my ($class, $args, $sock, $timeout) = @_;
    my $url = $args->{ws_url};
    my $hs  = Protocol::WebSocket::Handshake::Client->new(url => $url);
    $class->_ws_on_new_handshake_client($args, $hs);

    my $request = $hs->to_string;
    $log->debug("Request: $request");
    $sock->syswrite($request);

    my $expire = $timeout + time;
    my $response;

RECV_RESPONSE:
    while ($expire > (my $now = time) && $response !~ /\r\n\r\n$/) {
        if (${*$sock}{_sel}->can_read($expire - $now)) {
            while (1) {
                my $r = $sock->sysread($response, 1, length($response));
                last               if (!defined $r && $! == EWOULDBLOCK);
                last RECV_RESPONSE if (!defined $r || $r == 0);
            }
        }
    }

    $log->debug("Response: $response");
    unless ($response && $hs->parse($response)) {
        $log->error('switching protocol failed: ' . $hs->error);
        return 0;
    }
    return 1;
}

sub _ws_on_recv_frame {
    my $self = $_[0];
    ${*$self}{_ws_read_buffer} .= $_[1];
}

sub _sock_on_read {
    my ($sock, $self) = @_;

    my $bufLen = length(${*$self}{_ws_read_buffer});
    if ($bufLen >= MAX_READBUFFER_SIZE) {
        $log->error('read_buffer is full.');
        return;
    }

    my $r = $sock->sysread(my $rawBuf, MAX_READBUFFER_SIZE - $bufLen);
    if (defined $r) {
        if ($r > 0) {
            my $buf = ${*$self}{_ws_frame}->append($rawBuf)->next_bytes();
            $self->_ws_on_recv_frame($buf) if defined $buf;
        } else {
            ${*$self}{_ws_eof} = 1;
            removeRead($sock);
        }
    } elsif ($! != EWOULDBLOCK) {
        $log->warn($!);
    }
}

sub _build_frame {
    return Protocol::WebSocket::Frame->new(version => undef, @_);
}

sub opened {
    my $self = shift;
    return defined ${*$self}{_ws_sock};
}

sub sysread {
    my $self   = $_[0];
    my $maxLen = $_[2];
    my $offset = $_[3] || 0;

    return 0 if ${*$self}{_ws_eof};

    my $r_read_buf = \${*$self}{_ws_read_buffer};

    if (length($$r_read_buf) > 0) {
        my $buf = substr($$r_read_buf, 0, $maxLen, '');
        my $len = length($buf);
        substr($_[1], $offset, $len, $buf);
        return $len;
    }

    $! = EWOULDBLOCK;
    return undef;
}

sub ws_write {
    my $self = shift;
    my $sock = ${*$self}{_ws_sock};

    return if ${*$self}{_ws_eof};

    my $frame =
        @_ == 1
        ? _build_frame(masked => 1, buffer => shift)
        : _build_frame(@_);
    my $buf = $frame->to_bytes;

    Slim::Networking::Select::writeNoBlock($sock, \$buf);
}

sub blocking {
    $log->warn('it is only used in non-blocking mode') if $_[1];
}

sub isRemote {1}

sub close {
    my $self = shift;
    my $sock = ${*$self}{_ws_sock};
    if (defined $sock) {
        removeRead($sock);
        removeWrite($sock);

        if (${*$sock}{_sel}->can_write(0)) {
            $log->debug('send close packet.');
            my $frame = _build_frame(type => 'close');
            $sock->syswrite($frame->to_bytes);
        }
        ${*$sock}{_sel}->remove($sock);
        ${*$self}{_ws_sock} = undef;

        $sock->close();
    }
}

sub DESTROY {
    my $self = shift;
    $self->close();
}

1
