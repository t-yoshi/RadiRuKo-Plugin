# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::Utils;

use strict;
use XML::Simple;
use JSON::XS::VersionOneAndTwo;
use Slim::Utils::Log;
use Slim::Utils::Cache;
use Slim::Utils::Strings;
use Slim::Utils::Versions;
use Slim::Utils::Prefs;
use Slim::Utils::Unicode;
use Slim::Networking::SimpleAsyncHTTP;
use Date::Parse;
use Time::Zone;
use Time::Local;
use POSIX qw(strftime);
use Time::HiRes q(time);
use Data::Dumper;

use Exporter 'import';

our @EXPORT_OK = qw(
	RE_RADIKO_AUDIO_URL RE_RADIRU_AUDIO_URL
	RE_RADIKOTF_AUDIO_URL RE_SIMULRADIO_AUDIO_URL
	fetchXml fetchJson getCache jptime 
	parseDateTime jpShortDateTimeF
	enabledPremiumPlugin 
	createMetaData 
);

use constant {
	#(radikoId)
	RE_RADIKO_AUDIO_URL => qr'^radiko(?:p|tf)?://([A-Z\d]+[\-_]?[A-Z\d]+)',
	
	#(radikoId, startTime, endTime)
	RE_RADIKOTF_AUDIO_URL => qr'^radikotf://([A-Z\d]+[\-_]?[A-Z\d]+)/(\d{14})-(\d{14})',

	#(channel, area)
	RE_RADIRU_AUDIO_URL => qr'^radiru://(R1|R2|FM)(?:-([A-Z][a-z]+))?$',

	#
	RE_SIMULRADIO_AUDIO_URL => qr'#simulradio=1;(.*)$',
};



my $log = logger('plugin.radiruko');
my $cache = Slim::Utils::Cache->new('radiruko');

sub getCache () {
	return $cache;
}

sub _canonicalize_expires {
	local $_ = shift;
	return $_ if /^\d+$/;
	return $1*60 if /^(\d+)\s*min(s|utes?)?/;
	return $1*60*60 if /^(\d+)\s*hours?/;
	return $1*86400 if /^(\d+)\s*days?/;
	
	$log->error("invalid expire: $_");
	return 10*60;
}

sub _fetchUrl {
	$log->debug(Dumper @_) if $log->is_debug;

	my $parser = shift;
	my $url = shift;
	my $cb = shift;
	my $ecb = shift if ref($_[0]) eq 'CODE';
	my $params = ref($_[0]) eq 'HASH' ? shift : {@_};

	$ecb ||= sub { $log->error("url=$url, " . $_[0]) };

	$log->debug("url=$url, " . Dumper($params)) if $log->is_debug;

	Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my $http = shift;
			my $hash = eval { $parser->($http->content) };
			if (defined $hash){
				$cb->($hash, $url, $params);
			} else {
				$ecb->($@ or 'parse error');
			}
		}, 
		sub {
			my ($http, $err) = @_;
			$ecb->($err, $url, $params);
		}, 
		+{
			'params'  => $params,
			'cb'      => $cb,
			'ecb'     => $ecb,
			'cache'   => 1,
			'expires' => _canonicalize_expires($params->{'expires'} || '10 min'),
			'Timeout' => $params->{'timeout'} || 10,
		}
	)->get($url, 'User-Agent'=>'Mozilla/5.0');
}

#
# 非同期でXML|JSONを取得しハッシュに変換する。
#
# 引数:
#	url: 接続先
#   callback: 非同期で結果を返す  ->($hash, $url, $params)
#   [errorCallback]: エラーが起きたとき  ->($errorMsg, $url, $params)
#   [key=>value,..]: SimpleAsyncHTTPにわたす引数

sub fetchXml {
	_fetchUrl(sub {
		XMLin($_[0], ForceArray=>0, KeyAttr=>[], SuppressEmpty=>'');
	}, @_);
}

sub fetchJson {
	_fetchUrl(\&from_json, @_);
}


sub jptime {
	my $t = shift || time();
	return gmtime($t + tz_offset('JST'));
}

#
# 日時の文字列をエポック秒に変換する
#   ex. '2004-04-01T12:00+09:00' -> 1080788400
#
sub parseDateTime {
	my $dateTime = shift;

	#radiko形式 '20160910151500' -> '20160910T151500'
	$dateTime =~ s/^(20\d{6})(\d{4,}.*)$/$1T$2/;

	my @tm = strptime($dateTime, 'JST');
	return timegm(@tm) - $tm[6] if scalar @tm;	 
}

# ex '8/31 12:34'
sub jpShortDateTimeF {
	my @tm = jptime(shift);

	my $serverPrefs = preferences('server');
	my $dateFormat = $serverPrefs->get('shortdateFormat');
	my $timeFormat = $serverPrefs->get('timeFormat');
	$dateFormat =~ s=\W*%[yY][^%]*==; #年は省略
	$dateFormat =~ s=(?<!\|)%m([\.\-/]%d)=|%m$1=; #月の0を除く 08 -> 8
	#$log->info("$dateFormat $timeFormat");

	my $date = strftime("$dateFormat $timeFormat", @tm);
	$date =~ s/\|0*//g; #see DateTime.pm
	return Slim::Utils::Unicode::utf8decode_locale($date);
}


sub createMetaData {
	my $client = shift;
	my $url = shift;
	+{
		url   => $url,
		title => $url,
		icon  => 'html/images/radio.png',
		type  => getTypeFromUrl($client, $url),
		@_,
	};
}

#基本プラグインのバージョンをチェックする。
sub checkBasicVersion {
	my $minVer = shift;
	require Plugins::RadiRuKo::Plugin;
	my $basicVersion = Plugins::RadiRuKo::Plugin->_pluginDataFor('version');
	#$log->debug("basic=$basicVersion, min=$minVer");
	return Slim::Utils::Versions->checkVersion($basicVersion, $minVer, '100101');
}

#コマンド引数をエスケープする
sub escapeCommands {
	my $escape = sub {
		s/([\$\"\`])/\\$1/g; 
		return /^[\w\+\-\/\.]+$/ ? $_ : "\"$_\"";	
	};
	@_ = map { $escape->() } @_;
	return wantarray ? @_ : join(' ', @_);
}

sub enabledPremiumPlugin {
	return !!Slim::Utils::PluginManager->isEnabled('Plugins::RadiRuKoPr::Plugin');
}

sub clearCache () {
	$cache->clear();
}


sub getTypeFromUrl {
	my ($client, $url) = @_;
	if ($url =~ /^([a-z]+):/){
		my $token = 'PLUGIN_RADIRUKO_TYPE_' . uc($1);
		return $client->string($token) if Slim::Utils::Strings::stringExists($token);
	}
	if ($url =~ /#simulradio=1/){
		return $client->string('PLUGIN_RADIRUKO_TYPE_SIMULRADIO');
	}
	return $client->string('RADIO');
}


1;
