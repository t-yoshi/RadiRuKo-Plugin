
package Plugins::RadiRuKo::Settings;
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

use strict;
use base qw(Slim::Web::Settings);
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::PluginManager;

use Plugins::RadiRuKo::RadiruConfig;
use Plugins::RadiRuKo::Utils;
use Data::Dumper;

my $log = logger('plugin.radiruko');
my $prefs = preferences('plugin.radiruko');

sub name {
	return Slim::Web::HTTP::CSRF->protectName('PLUGIN_RADIRUKO');
}

sub page {
	return Slim::Web::HTTP::CSRF->protectURI('plugins/RadiRuKo/settings/basic.html');
}

sub handler {
	my ($class, $client, $params) = @_;
	
	# When "apply" is pressed on the settings page, this function gets called.
	# So, double check that the apply button was pressed and if so check that the field was populated.
	# If so, set that value into the prefs variable
	# It's easiest if you use the same name for the HTML field and the prefs field.
	# In this case everything is called helloname and if you look at basic.html 
	# you'll see the field is called helloname.
	if ($params->{'saveSettings'}){ 
		$prefs->set('radiru_area', $params->{radiru_area});
		$prefs->set('enable_radiko_nhk', $params->{enable_radiko_nhk});

		if ($params->{radiruko_clear_cache}){
			Plugins::RadiRuKo::Utils::clearCache();
			$log->info('clearCache');
		}
	}

	# This puts the value on the webpage. 
	# If the page is just being displayed initially, then this puts the current value found in prefs on the page.
	$params->{'radiru_all_areas'} = [Plugins::RadiRuKo::RadiruConfig->area()];
	#$log->debug(Dumper(Plugins::RadiRuKo::RadiruHandler::config));
	$params->{'enable_radiko_nhk'} = $prefs->get('enable_radiko_nhk');

	$params->{'prefs'}->{'radiru_area'} = $prefs->get('radiru_area') || 'tokyo';

	# I have no idea what this does, but it seems important and it's not plugin-specific.
	return $class->SUPER::handler($client, $params);
}

1;

__END__
