# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::FFMpegHandler;
#
# URL protocol handler
#     
#  ffmpegpcm: PCMにデコードする 
#  ffmpegaac: ソースのAACをそのまま出力
#
# (例)
# ffmpegaac:http://xxxx/stream.m3u8#  HTTP Live Streaming
#   (NOTE) .m3u8はプレイリストと認識されて再生できないので#を付けること。
# ffmpegpcm:rtmpe://xxxx/ 
# ffmpegpcm:rtsp://xxxx/
# ffmpegpcm:mmst://xxxx/
#
use strict;
use File::Spec;
use base qw(
	Slim::Player::Pipeline 
	Plugins::RadiRuKo::MetadataHandler
);
use Slim::Utils::Misc;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use File::Temp;
use Errno qw/EINTR/;
use Audio::Scan;
use IO::Select;
use Data::Dumper;

my $log = logger('plugin.radiruko');
my $prefs = preferences('server');


sub new {
	my $class = shift;
	my $args  = shift;

	my $url        = $args->{url};
	my $client     = $args->{client};

	$args->{ffoptions} ||= []; 

	$log->debug("url: $url");

	$url =~ s=#.*$==;

	my $format;
	if ($url =~ m=^ffmpeg(pcm|aac):((https?|rtsp|mms[th])://.+)=) {
		$format = $1;		
		$url = $2;
		$format =~ s/pcm/wav/;
	} else {
		$format = 'aac';
	}

	if ($url =~ /^rtsp:/){
		push @{$args->{ffoptions}}, qw/-rtsp_transport tcp/;
	}

	my $timeout = $args->{'timeout'} || $prefs->get('remotestreamtimeout');
	my @ffargs = (
		@{$args->{ffoptions}},
		'-timeout', $timeout > 0 ? $timeout*1_000_000 : 15_000_000,
		'-user_agent', 'Mozilla/5.0',
		'-re', #等速にしないと、らじる聴き逃しで再接続が発生する
		'-i', $url, qw/-loglevel error/,
	);

	my $contentType;
	if ($format eq 'aac'){
		push @ffargs, qw/-acodec copy -f adts/;
		$contentType = 'audio/aac';		
	} else {
		push @ffargs, qw/-f wav -ac 2/;
		$contentType = 'audio/x-wav';		
	}

	my $ffpath = find_ffmpeg() || return undef;

	my $cmd = sprintf('"%s" -hide_banner %s -', 
		$ffpath, scalar Plugins::RadiRuKo::Utils::escapeCommands(@ffargs)
	);

	$log->debug("Command: $cmd");

	my $self = $class->SUPER::new(undef, $cmd, 0);

	${*$self}{'contentType'} = $contentType;
	#Slim::Music::Info::setContentType($args->{url}, $contentType);

	my $data = $self->_parse_content_header($format);
	if (defined $data->{info}){
		my $song = $args->{song};          ## Slim::Player::Song
		my $track = $song->currentTrack(); ## Slim::Schema::RemoteTrack
		$track->content_type($format);
		$track->samplerate($data->{info}{samplerate}) if $data->{info}{samplerate};
		if ($format eq 'aac'){
			for my $p (qw(bitrate samplerate samplesize channels)) {
				$track->$p($data->{info}{$p}) if defined $data->{info}{$p};
			}
		}
		#大半はVBR
		$track->vbr_scale(1) if $track->bitrate > 0;
	}
	return $self;
}

my $ffpath;

sub find_ffmpeg {
	return Slim::Utils::Misc::findbin('ffmpeg_bin') ||
				Slim::Utils::Misc::findbin('ffmpeg4') ||
				Slim::Utils::Misc::findbin('ffmpeg') || do {
		$log->fatal('Please install ffmpeg');
		undef;
	};
}

sub _parse_content_header {
	my ($self, $format) = @_;
	my $tmp = File::Temp->new(SUFFIX=>$format);
	my $rdr = ${*$self}{'pipeline_reader'};
	my $sel = IO::Select->new($rdr);
	my $MAX_LEN = 8192;
	my $len = 0;

	while ($len < $MAX_LEN) {
		next unless ($sel->can_read(.1));

		my $r = $rdr->sysread(my $buf, $MAX_LEN - $len);
		if ($r == 0 || (!defined($r) && $! != EINTR)){
			$log->error("r=$r err=$!");
			last;
		}
		$len += $r;
		${*$self}{'_init_content'} .= $buf;
		$tmp->write($buf);
	}

	$tmp->seek(0, 0);

	my $data;
	eval {
		$data = Audio::Scan->scan_fh($format => $tmp);
		$log->debug("format=$format, " . Dumper($data)) if $log->is_debug;
	};
	$log->error("$@") if ($@);
	return $data || {};
}

sub sysread {
	my $self = $_[0];
	my $chunksize = $_[2]; 
	my $offset = $_[3] || 0;
	
	my $refContent = \${*$self}{'_init_content'};
	if (length($$refContent) > 0) {
		#$log->debug("remain=".length($$refContent));
		my $buf = substr($$refContent, 0, $chunksize, '');
		substr($_[1], $offset, $chunksize) = $buf;			
		return length($buf);
	}
	return $self->SUPER::sysread($_[1], $chunksize, $offset);	
}


sub getStreamBitrate {
	my ($self, $maxRate) = @_;
	return 64_000 if ($self->contentType =~ /aac/);
	return Slim::Player::Song::guessBitrateFromFormat(${*$self}{'contentType'}, $maxRate);
}

sub contentType {
	my $self = shift;
	return ${*$self}{'contentType'};
}

# XXX - I think that we scan the track twice, once from the playlist and then again when playing
sub scanUrl {
	my ($class, $url, $args) = @_; 
	#$log->debug("$url $args");
	Slim::Utils::Scanner::Remote->scanURL($url, $args);
}

sub canDirectStream { 0 }

sub isRemote { 1 } 

sub isAudioURL { 1 }

sub getFormatForURL { 
	my ($class, $url) = @_;
	return $url =~ /^ffmpegpcm:/ ? 'wav' : 'aac';
}

1;
