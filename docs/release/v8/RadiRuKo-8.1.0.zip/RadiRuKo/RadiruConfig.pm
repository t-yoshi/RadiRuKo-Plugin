# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruConfig;

use strict;
use utf8;
use List::Util qw(first);
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Plugins::RadiRuKo::Utils qw(fetchXml);
use Data::Dumper;
use URI;

use constant CONFIG_URL => 'http://www.nhk.or.jp/radio/config/config_web.xml';


my $log = logger('plugin.radiruko');
my $prefs = preferences('plugin.radiruko');

my $xml;

sub initLoadConfig {
    my $class = shift;
    fetchXml(CONFIG_URL, sub {
        $xml = $_[0];
        #$log->debug(Dumper area());
        #$log->debug(Dumper streamUrl('area', 'tokyo', 'osaka'));
    }, expires=>'30 days');
}

#[area, areajp, ..]で検索して<data>を返す。
sub _findData {
    my $convert = shift;
    my $searchKey = shift;
    my $searchValue = shift;

    unless (defined $xml){
        $log->error('config has not loaded yet.');
        return;
    }

    my @data = @{$xml->{stream_url}{data}};
    return map {$convert->($_)} @data if (wantarray && @_ == 0);

    unless ($searchKey =~ /^(area|areajp|apikey|areakey)$/){
        $log->error("invalid searchKey: $searchKey");
        return;
    }

    unless (defined $searchValue){
        $log->error('searchValue is empty.');
        return;
    }

    $log->debug(Dumper $searchKey, $searchValue);
    
    return $convert->(first { $_->{$searchKey} eq $searchValue } @data);
}

sub area {
    my $class = shift;
    _findData sub { $_[0]->{area} }, @_;
}

sub areaJp {
    my $class = shift;
    _findData sub { $_[0]->{areajp} }, @_;
}

sub data {
    my $class = shift;
    return _findData sub { $_[0] }, @_;   
}

sub url_program_noa {
    my $class = shift;
    my $areakey = shift;
    unless (defined $xml){
        $log->error('config has not loaded yet.');
        return;
    }
    my $noa = $xml->{url_program_noa};
    $noa =~ s/\{area\}/$areakey/;
    return URI->new_abs($noa, CONFIG_URL)->as_string;
}

1;