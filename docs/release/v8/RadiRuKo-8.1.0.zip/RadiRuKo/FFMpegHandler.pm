# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::FFMpegHandler;
#
# URL protocol handler
#     
#  ffmpegpcm: PCMにデコードする 
#  ffmpegaac: ソースのAACをそのまま出力 (48Khz)
#
# (例)
# ffmpegaac:http://xxxx/stream.m3u8#  HTTP Live Streaming
#   (NOTE) .m3u8はプレイリストと認識されて再生できないので#を付けること。
# ffmpegpcm:rtmpe://xxxx/ 
# ffmpegpcm:rtsp://xxxx/
# ffmpegpcm:mmst://xxxx/
#
use strict;
use base qw(
	Slim::Player::Pipeline 
	Plugins::RadiRuKo::MetadataHandler
);
use Slim::Utils::Misc;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Data::Dumper;

my $log = logger('plugin.radiruko');
my $prefs = preferences('server');


sub new {
	my $class = shift;
	my $args  = shift;

	my $url        = $args->{url};
	my $client     = $args->{client};

	$args->{ffoptions} ||= []; 

	$log->debug("url: $url");

	$url =~ s=#.*$==;

	my $format;
	if ($url =~ m=^ffmpeg(pcm|aac):((https?|rtsp|mms[th])://.+)=) {
		$format = $1;		
		$url = $2;
		$format =~ s/pcm/wav/;
	} else {
		$format = 'aac';
	}


	my $timeout = $args->{'timeout'} || $prefs->get('remotestreamtimeout');
	my @ffargs = (
		@{$args->{ffoptions}},
		'-timeout', $timeout > 0 ? $timeout*1_000_000 : 15_000_000,
		'-user_agent', 'Mozilla/5.0',
		qw/-loglevel error/,
		'-re', #等速にしないと、らじる聴き逃しで再接続が発生する 
		'-i', $url, 
	);

	unless (grep { $_ eq '-reconnect_on_http_error' } @{$args->{ffoptions}}){
		push @ffargs, qw/-reconnect_on_http_error 5xx/;
	}
	push @ffargs, qw/-rtsp_transport tcp/ if ($url =~ /^rtsp:/);

	my $contentType;
	if ($format eq 'aac'){
		push @ffargs, qw/-acodec copy -f adts/;
		$contentType = 'audio/aac';		
	} else {
		push @ffargs, qw/-ar 48k -ac 2 -f wav/;
		$contentType = 'audio/x-wav';		
	}

	my $ffpath = find_ffmpeg() || return undef;

	my $cmd = sprintf('"%s" -hide_banner %s -', 
		$ffpath, scalar Plugins::RadiRuKo::Utils::escapeCommands(@ffargs)
	);

	$log->debug("Command: $cmd");

	my $self = $class->SUPER::new(undef, $cmd, 0);

	${*$self}{'contentType'} = $contentType;
	#Slim::Music::Info::setContentType($args->{url}, $contentType);

	my $song = $args->{song};          ## Slim::Player::Song
	my $track = $song->currentTrack(); ## Slim::Schema::RemoteTrack
	$track->samplerate(48_000);
	$track->content_type($format);

	return $self;
}

my $ffpath;

sub find_ffmpeg {
	return Slim::Utils::Misc::findbin('ffmpeg_bin') ||
				Slim::Utils::Misc::findbin('ffmpeg4') ||
				Slim::Utils::Misc::findbin('ffmpeg') || do {
		$log->fatal('Please install ffmpeg');
		undef;
	};
}

sub getStreamBitrate {
	my ($self, $maxRate) = @_;
	return 64_000 if ($self->contentType =~ /aac/);
	return Slim::Player::Song::guessBitrateFromFormat(${*$self}{'contentType'}, $maxRate);
}

sub contentType {
	my $self = shift;
	return ${*$self}{'contentType'};
}

# XXX - I think that we scan the track twice, once from the playlist and then again when playing
sub scanUrl {
	my ($class, $url, $args) = @_; 
	#$log->debug("$url $args");
	Slim::Utils::Scanner::Remote->scanURL($url, $args);
}

sub canDirectStream { 0 }

sub isRemote { 1 } 

sub isAudioURL { 1 }

sub getFormatForURL { 
	my ($class, $url) = @_;
	return $url =~ /^ffmpegpcm:/ ? 'wav' : 'aac';
}

1;
