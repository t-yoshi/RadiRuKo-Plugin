# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruMeta;

use strict;
use utf8;
use POSIX;
use List::Util qw(first);
use Slim::Utils::Log;
use Plugins::RadiRuKo::Utils qw(
	RE_RADIRU_AUDIO_URL
	fetchJson parseDateTime createMetaData 
	dstring
);
use Plugins::RadiRuKo::TextUtil;
use Data::Dumper;
use Plugins::RadiRuKo::RadiruConfig;
use Slim::Utils::Strings;

my $log = logger('plugin.radiruko');


# URL:
#  radiru://Station[-Area]
#
#  Station:
#    R1, R2, FM
#  Area:
#    Sendai, Tokyo, Nagoya, Osaka, ...
#

sub _on_parse {
	my ($js, $url, $params) = @_;
	my %chmap = (R1=>'n1',R2=>'n2',FM=>'n3');

	my $ch = {R1=>'n1',R2=>'n2',FM=>'n3'}->{ $params->{channel} };
	my @programs = values %{$js->{nowonair_list}->{ $ch }};
	
	#$log->debug(Dumper \@programs, $js, $params, $ch, $params->{channel});

	my $now = time();
	#放送中
	my $prog = first {
		$now >= parseDateTime($_->{start_time}) && parseDateTime($_->{end_time}) > $now
	} @programs or return;

	my $logo = $prog->{images}{logo_l}{url} || 
		$prog->{images}{thumbnail_m}{url} ||
		'plugins/RadiRuKo/html/images/NHK_' . $params->{channel} . '.png';

	#次の番組開始時間にメタ更新を通知する
	my $following = $js->{nowonair_list}{ $ch }{following};		
	my $expires = parseDateTime($following->{start_time});
	if ($expires <= $now){
		$expires = parseDateTime($following->{end_time});
	}

	$params->{updateMetadata}->(
		title => $params->{chName} . ' ' . $prog->{title},
		artist => $prog->{act} || $prog->{subtitle},
		album  => _abbreviate($prog->{content}),
		cover  => $logo,
		expires => $expires,
	);
}

sub _provider {
	my ($client, $url) = @_;

	my ($channel, $area) = $url =~ RE_RADIRU_AUDIO_URL;
	$area ||= 'tokyo';

	my $async = sub {
		my ($client, $url, $updateMetadata) = @_;
		my $data = Plugins::RadiRuKo::RadiruConfig->data(area=>lc($area)) or return;
		$log->debug(Dumper $data) if $log->is_debug;

		my $jsNoa = Plugins::RadiRuKo::RadiruConfig->url_program_noa($data->{areakey});

		fetchJson($jsNoa, 
			\&_on_parse,  
			expires =>'4 min', 			
			channel => $channel,
			chName  => dstring("PLUGIN_RADIRUKO_NHK_${channel}", 
							JA=>[$data->{areajp}], EN=>[ucfirst($data->{area})]
						),
			updateMetadata => $updateMetadata,
		);
	};

	createMetaData($client, $url, 
		title => dstring("PLUGIN_RADIRUKO_NHK_${channel}"),
		async => $async,
	);
}

sub _abbreviate {
	Plugins::RadiRuKo::TextUtil->new($_[0])
		->z2h
		->abbreviate($_[1])
		->text;
}

Slim::Formats::RemoteMetadata->registerProvider(
	match => RE_RADIRU_AUDIO_URL,
	func  => \&_provider,
);

1;