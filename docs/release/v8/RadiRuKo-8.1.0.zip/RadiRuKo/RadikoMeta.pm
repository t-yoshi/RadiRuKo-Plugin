# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadikoMeta;

use strict;
use utf8;
use POSIX;
use List::Util qw(first);
use Time::HiRes q(time);
use Slim::Utils::Log;
use Slim::Music::Info;
use Plugins::RadiRuKo::Utils qw(
	RE_RADIKO_AUDIO_URL RE_RADIKOTF_AUDIO_URL
	jptime  
	fetchXml parseDateTime
	createMetaData jpShortDateTimeF
);
use Plugins::RadiRuKo::TextUtil;
use Data::Dumper;

my $log = logger('plugin.radiruko');

# 
# 番組表のXMLを取得する。
#  id: stationId || areaId || 'ALL'
#  [time]: 過去の番組表(エポック時間)
#  @_: fetchXmlの引数
#
sub fetchProgramXml {
	my $id = shift;
	my $now = time();
	my $time = ref($_[0]) ne 'CODE' ? shift : undef;
	$time ||= $now;

	#朝５時更新
	my $date = strftime('%Y%m%d', jptime($time - 5*60*60));
	my $expires = ($now - $time > 24*60*60) ? 7*24*60*60: 60*60;

	my $u = ($id =~ /^(JP\d+|ALL)$/) ?
		"http://radiko.jp/v3/program/date/$date/$id.xml" :        #JP13
		"http://radiko.jp/v3/program/station/date/$date/$id.xml"; #FMJ
	
	fetchXml($u, @_, expires=>$expires);
}

#いま放送中のprog
sub _findProg {
	my $xml  = shift;
	my $time = shift || time();
	return first {
		$time >= parseDateTime($_->{ft}) && parseDateTime($_->{to}) > $time
	} @{$xml->{stations}{station}{progs}{prog}};
}

sub _on_parse {
	my ($xml, $url, $params) = @_;
	my $meta = $params->{meta};
	my $stId = $params->{stId};
	my $startTime = $params->{startTime}; #開始時間, undef=現在の番組

	my $prog = _findProg($xml, $startTime) or do {
		$log->error("$stId's program on " . jpShortDateTimeF($startTime) . ' is not found.');		
		return;
	};

	my $stationName = $xml->{stations}{station}{name};
	my $progTitle = $prog->{title};

	#局名がタイトルに含まれていれば追加する必要はない
	if (index($progTitle, $stationName) == -1){
		$progTitle = "$stationName $progTitle";
	}
	my $title = _prepareText($progTitle);

	my $expires;
	if ($startTime){
		#タイムフリー用
		$title .= ' (' . jpShortDateTimeF($startTime) . '-)';
		$expires = 2**32;
	} else {
		$expires = parseDateTime($prog->{to});
	}

	$params->{updateMetadata}->(
		title => $title,
		album => _prepareText($prog->{desc}),
		artist => _prepareText($prog->{pfm}),
		icon => 'plugins/RadiRuKo/html/images/icon.png',
		cover => $prog->{img} || "http://radiko.jp/station/logo/$stId/logo_large.png",
		expires => $expires,
	);
}

sub _prepareText {
	Plugins::RadiRuKo::TextUtil->new($_[0])
		->stripTag
		->z2h
		->abbreviate($_[1])
		->text;
}

sub _async {
	my ($client, $url, $updateMetadata) = @_;

	my ($stId, $startTime); 
	if ($url =~ RE_RADIKOTF_AUDIO_URL){
		$stId = $1;
		$startTime = parseDateTime($2);
	} elsif ($url =~ RE_RADIKO_AUDIO_URL){
		$stId = $1;
	} else {
		$log->error("invalid url: $url");
		return;
	}

	$log->debug("stId=$stId, startTime=$startTime");
	
	fetchProgramXml(
		$stId, $startTime, \&_on_parse, 
		updateMetadata=>$updateMetadata,
		startTime=>$startTime, stId=>$stId,
	);
}

sub _provider {
	my ($client, $url) = @_;

	createMetaData($client, $url,
		async=>\&_async
	);
}


Slim::Formats::RemoteMetadata->registerProvider(
	match => RE_RADIKO_AUDIO_URL,
	func  => \&_provider,
);

1;
