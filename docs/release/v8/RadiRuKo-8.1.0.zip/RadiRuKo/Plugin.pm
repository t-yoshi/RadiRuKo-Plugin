# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKo::Plugin;

use strict;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Timers;
use Slim::Utils::Misc;
use Slim::Utils::OSDetect;

use base qw(Slim::Plugin::OPMLBased);


# create log categogy before loading other modules
my $log = Slim::Utils::Log->addLogCategory( {
	category     => 'plugin.radiruko',
	defaultLevel => 'INFO',
	description  => getDisplayName(),
});

use Plugins::RadiRuKo::FFMpegHandler;
use Plugins::RadiRuKo::RadikoHandler;
use Plugins::RadiRuKo::RadiruHandler;

my $prefs = preferences('plugin.radiruko');

use Plugins::RadiRuKo::SimulradioMeta;
use Plugins::RadiRuKo::Feed;
use Plugins::RadiRuKo::RadiruConfig;
use Plugins::RadiRuKo::Settings;

sub getDisplayName {
	return 'PLUGIN_RADIRUKO_NAME';
}


sub initPlugin {
	my $class = shift;
	my $version = $class->_pluginDataFor('version');
	$log->info('Initialising.. RadiRuKo-Plugin v' . $version);

	$class->SUPER::initPlugin(
		tag    => 'RadiRuKo',
		menu   => 'radios',
		weight => 1.01, # ラジオの先頭にメニュー表示
	);

	$log->info('Register protocols: ffmpegpcm ffmpegaac radiko radiru');
	Slim::Player::ProtocolHandlers->registerHandler('ffmpegpcm', q(Plugins::RadiRuKo::FFMpegHandler));
	Slim::Player::ProtocolHandlers->registerHandler('ffmpegaac', q(Plugins::RadiRuKo::FFMpegHandler));
	Plugins::RadiRuKo::FFMpegHandler->find_ffmpeg();

	Slim::Player::ProtocolHandlers->registerHandler('radiko',  q(Plugins::RadiRuKo::RadikoHandler));
	Slim::Player::ProtocolHandlers->registerHandler('radiru',  q(Plugins::RadiRuKo::RadiruHandler));
	Plugins::RadiRuKo::RadiruConfig->initLoadConfig();

	Plugins::RadiRuKo::SimulradioMeta::registerMetaProvider();

	Plugins::RadiRuKo::Settings->new();

	#FreeBSD | NetBSD
	my $osDetails = Slim::Utils::OSDetect::details();
	if ($osDetails->{osArch} =~ /(amd64|x86_64)-(FreeBSD|NetBSD)/i){
		my $baseDir = $class->_pluginDataFor('basedir');
		Slim::Utils::Misc::addFindBinPaths("$baseDir/Bin/x86_64-linux");	
	}

	return 1;
}

sub feed {
	my $class = shift;
	my $client = shift;
	return \&Plugins::RadiRuKo::Feed::createFeed;
}

sub playerMenu { 'RADIO' }

sub getFunctions(){ return {}; }

1;
