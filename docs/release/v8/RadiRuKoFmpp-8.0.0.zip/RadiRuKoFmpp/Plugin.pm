# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKoFmpp::Plugin;

use strict;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::OSDetect;
use Slim::Music::Info;

use base qw(Slim::Plugin::Base);

sub getDisplayName { 'PLUGIN_RADIRUKO_FMPP_NAME' }

sub initPlugin {
	my $class = shift;

	my $minBasicVersion = $class->_pluginDataFor('_minBasicVersion');
	my $basicFound = eval {
		require Plugins::RadiRuKo::Utils;		
		Plugins::RadiRuKo::Utils::checkBasicVersion($minBasicVersion);
	};
	if ($@ || !$basicFound){
		logError("Please install BasicPlugin >= $minBasicVersion");
		return;
	}

	my $log = logger('plugin.radiruko');
	eval { require IO::Socket::SSL; 1; } || do {
		#SSLがインストールされていない
		$log->error('FAIL RadiRuKoFmpp; IO::Socket::SSL is not installed');
		return;
	};

	$log->info('Register protocol: fmpp');
	
	require Plugins::RadiRuKoFmpp::FmppClient;
	require Plugins::RadiRuKoFmpp::FmppDecodeHandler;
	
	#TODO: 一部アーキのsoxでopusがサポートされていない
	my $handler = 0 && _isOpusSupported() 
		? q(Plugins::RadiRuKoFmpp::FmppClient) 
		: q(Plugins::RadiRuKoFmpp::FmppDecodeHandler);
	Slim::Player::ProtocolHandlers->registerHandler('fmpp'=>$handler);

	return $class->SUPER::initPlugin();
}

sub _isOpusSupported() {
	#一部arm-linux(armv5te)でlibopusが原因のノイズが
	#発生するのでffmpegでデコードする
	my $osDetails = Slim::Utils::OSDetect::details();
	return 0 if $osDetails->{binArch} =~ /arm-linux/;

	#opusのサポートは7.9.2以降
	return defined $Slim::Music::Info::types{ops};
}

sub getFunctions(){ return {}; }

1;
