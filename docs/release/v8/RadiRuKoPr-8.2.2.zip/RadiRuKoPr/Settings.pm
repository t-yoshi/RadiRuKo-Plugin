
package Plugins::RadiRuKoPr::Settings;

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

use strict;
use base qw(Slim::Web::Settings);
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Plugins::RadiRuKoPr::RadikoLogin;

my $log   = logger('plugin.radiruko');
my $prefs = preferences('plugin.radiruko');
my $all_stations;

sub new {
    my $class = shift;

    Plugins::RadiRuKoPr::Plugin::fetchAllStationXml(sub { $all_stations = shift->{station}; }, 0);

    return $class->SUPER::new();
}

sub name {
    return Slim::Web::HTTP::CSRF->protectName('PLUGIN_RADIRUKO_PREMIUM');
}

sub page {
    return Slim::Web::HTTP::CSRF->protectURI('plugins/RadiRuKoPr/settings/basic.html');
}

my $login_status = '';

sub handler {
    my ($class, $client, $params) = @_;

  # When "apply" is pressed on the settings page, this function gets called.
  # So, double check that the apply button was pressed and if so check that the field was populated.
  # If so, set that value into the prefs variable
  # It's easiest if you use the same name for the HTML field and the prefs field.
  # In this case everything is called helloname and if you look at basic.html
  # you'll see the field is called helloname.
    if ($params->{'saveSettings'}) {

        if ($params->{radiko_login} eq 'login' &&
            $params->{radiko_mail}
            =~ /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/ &&
            $params->{radiko_password})
        {
            $login_status = 'try to log in...';
            Plugins::RadiRuKoPr::RadikoLogin->login(
                $params->{radiko_mail},
                $params->{radiko_password},
                sub {
                    $login_status = '';
                },
                sub {
                    $login_status = 'login failed: ' . shift;
                }
            );
        }
        if ($params->{radiko_login} eq 'logout') {
            $login_status = 'try to log out...';
            Plugins::RadiRuKoPr::RadikoLogin->logout(
                sub {
                    $login_status = 'logout success';
                },
                sub {
                    $login_status = 'logout failed: ' . shift;
                }
            );
        }

        Plugins::RadiRuKoPr::Plugin::favoriteStations($params->{premium_favorite_stations});
    }

# This puts the value on the webpage.
# If the page is just being displayed initially, then this puts the current value found in prefs on the page.
    $params->{prefs}{cookie_radiko_session} = $login_status ||
        Plugins::RadiRuKoPr::RadikoLogin->get_radiko_session() ||
        '(none)';
    $params->{prefs}{premium_favorite_stations} = $prefs->get('premium_favorite_stations');
    $params->{all_stations} = $all_stations;

    # I have no idea what this does, but it seems important and it's not plugin-specific.
    return $class->SUPER::handler($client, $params);
}

1;

__END__
