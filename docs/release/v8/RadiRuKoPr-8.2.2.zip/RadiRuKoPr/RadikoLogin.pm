# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoPr::RadikoLogin;

use strict;
use Plugins::RadiRuKo::RadikoAuth qw(getAsyncHttpsClient UA);
use URI::Escape qw(uri_escape);
use JSON::XS::VersionOneAndTwo;
use Slim::Utils::Log;
use Slim::Utils::Prefs;

my $prefs = preferences('plugin.radiruko');
my $log   = logger('plugin.radiruko');

#class-methods
sub login {
    my ($class, $mail, $pass, $cb, $ecb) = @_;

    $log->debug("login: Start [$mail]");

    getAsyncHttpsClient()->new(
        sub {
            my $http    = shift;
            my $headers = $http->headers;
            my $json    = eval { from_json($http->content) };
            $log->debug("login: OK [" . $http->content . "]");
            if ($json->{radiko_session} !~ /^[\da-f]{40}$/) {
                $log->error('invalid: radiko_session');
                return $ecb->('invalid: radiko_session') if $ecb;
            }
            $prefs->set('cookie_radiko_session', $json->{radiko_session});
            $cb->($json->{radiko_session}) if $cb;
        },
        sub {
            my ($http, $err) = @_;
            $log->error("login: failed [$err]");
            $ecb->($err) if $ecb;
        }
    )->post(
        'https://radiko.jp/v4/api/member/login',
        'User-Agent'   => UA,
        'Content-Type' => 'application/x-www-form-urlencoded',
        sprintf('mail=%s&pass=%s', uri_escape($mail), uri_escape($pass))
    );
}

sub logout {
    my ($class, $cb, $ecb) = @_;

    my $radiko_session = $prefs->get('cookie_radiko_session');

    $log->debug("logout: Start");

    unless ($radiko_session) {
        $ecb->('radiko_session is already empty') if $ecb;
        return;
    }

    $prefs->set('cookie_radiko_session', '');

    getAsyncHttpsClient()->new(
        sub {
            my $http    = shift;
            my $headers = $http->headers;
            $log->debug("logout: OK [" . $http->content . "]");
            $cb->($radiko_session) if $cb;
        },
        sub {
            my ($http, $err) = @_;
            $log->error("logout: failed [$err]");
            $ecb->($err) if $ecb;
        }
    )->post(
        'https://radiko.jp/v4/api/member/logout',
        'User-Agent'   => UA,
        'Content-Type' => 'application/x-www-form-urlencoded',
        'Cookie'       => "radiko_session=$radiko_session",
        "radiko_session=$radiko_session"
    );
}

sub get_radiko_session {
    my ($class) = @_;
    return $prefs->get('cookie_radiko_session');
}

1;
