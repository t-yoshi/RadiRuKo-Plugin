# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoTf::Plugin;

use strict;

use Slim::Formats::RemoteMetadata;
use Slim::Utils::Log;

use base qw(Slim::Plugin::OPMLBased);

my $log;

sub getDisplayName {
	return 'PLUGIN_RADIRUKO_TIMEFREE_NAME';
}

sub initPlugin {
	my $class = shift;

	$class->SUPER::initPlugin(
		tag    => 'RadiRuKoTf',
		menu   => 'radios',
		weight => 1.04, # ラジオの先頭にメニュー表示
	);

	my $minBasicVersion = $class->_pluginDataFor('_minBasicVersion');
	my $basicFound = eval {
		require Plugins::RadiRuKo::Utils;		
		Plugins::RadiRuKo::Utils::checkBasicVersion($minBasicVersion);
	};
	if ($@ || !$basicFound){
		logError("Please install BasicPlugin >= $minBasicVersion");
		return;
	}

	$log = logger('plugin.radiruko');
	$log->debug('Initialising.. RadiRuKoTimeFree-Plugin v' . $class->_pluginDataFor('version'));

	require Plugins::RadiRuKoTf::Feed;
	require Plugins::RadiRuKoTf::ProtocolHandler;
	require Plugins::RadiRuKo::RadikoMeta;

	Slim::Player::ProtocolHandlers->registerHandler(
		'radikotf', q(Plugins::RadiRuKoTf::ProtocolHandler)
	);

	return 1;
}

sub feed {
	my ($class) = @_;	
	return \&Plugins::RadiRuKoTf::Feed::createFeed;
}

sub playerMenu { 'RADIO' }

sub getFunctions(){ return {}; }


1;
