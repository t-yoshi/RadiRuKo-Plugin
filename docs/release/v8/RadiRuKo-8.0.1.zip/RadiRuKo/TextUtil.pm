# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::TextUtil;

use strict;
use utf8;
use Text::VisualWidth::PP qw(vtrim);
use Lingua::JA::Regular::Unicode;
use Slim::Utils::Log;

my $log = logger('plugin.radiruko');

sub new {
	my $class = shift;
	my $text = shift || '';
    bless { text=>$text }, $class;
}

#
# HTMLタグを除去する。
#
sub stripTag {
    my $self = shift;
	$self->{text} =~ s/<.*?>/ /g;
	$self->{text} =~ s/\s+/ /g;
	return $self;
}

#
# 文字列を後略する。
#
sub abbreviate {
    my $self = shift;
	my $maxWidth = shift || 200; #半角換算の文字幅
    my $origLen = length($self->{text});
    return $self if $origLen < $maxWidth / 2;
    
    my $trimed = vtrim($self->{text}, $maxWidth);
    if (length($trimed) + 3 < $origLen){
        $self->{text} = $trimed . '...';
    }

    return $self;
}

#
# 関数を適用する
#
sub apply {
    my $self = shift; 
    for my $f (@_){
        $self->{text} = $f->($self->{text});
    }
    return $self;
}

#
# 全角の空白と英数字を半角にする。
#
sub z2h {
    $_[0]->apply(\&alnum_z2h, \&space_z2h);
}

sub text { $_[0]->{text} }


1;