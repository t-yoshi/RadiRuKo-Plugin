package Plugins::RadiRuKo::Feed;
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
use utf8;
use strict;

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Formats::XML;
use Plugins::RadiRuKo::Utils qw(fetchXml);
use Plugins::RadiRuKo::RadiruConfig;
use Plugins::RadiRuKo::RadikoAuth;
use Data::Dumper;

my $log = logger('plugin.radiruko');
my $prefs = preferences('plugin.radiruko');

my @areaNameJP = (undef, qw(
北海道 青森 岩手 宮城 秋田 山形 福島 茨城 栃木 群馬
埼玉 千葉 東京 神奈川 新潟 富山 石川 福井 山梨 長野
岐阜 静岡 愛知 三重 滋賀 京都 大阪 兵庫 奈良 和歌山
鳥取 島根 岡山 広島 山口 徳島 香川 愛媛 高知 福岡
佐賀 長崎 熊本 大分 宮崎 鹿児島 沖縄
));

sub _radiruRegion {
	my $area = shift; #ex: tokyo
	my $addR2 = shift; #R2を含めるか

	my $data = Plugins::RadiRuKo::RadiruConfig->data('area'=>$area);
	#$log->debug(Dumper $data);
	my @items;

	for my $channel (qw(R1 R2 FM)){
		next if ($channel eq 'R2' && !$addR2);

		my $area = ucfirst($data->{area});
		my $areajp = $data->{areajp};
		my $areakey = $data->{areakey};

		my $name = Slim::Utils::Strings::string("PLUGIN_RADIRUKO_NHK_$channel");

		if ($channel eq 'R2' and $area !~ /tokyo/i){
			$area = 'Tokyo';
			$areajp = $areakey = '';
		}

		#ローカル局: R1の後にFMを並べる
		my $sortkey = ($channel eq 'FM') ? '1#': '0#';

		push @items, {
			name  => $name . $areajp,
			url   => "radiru://$channel-$area",
			icon  => "plugins/RadiRuKo/html/images/NHK_$channel.gif",
			type  => 'audio',

			_sortkey => $sortkey . $areakey,
		};
	}
	return @items;
}

sub _radiruItems {
	my ($cb, $ecb) = @_;

	my @areas = Plugins::RadiRuKo::RadiruConfig->area();

	return $ecb->('config not loaded') unless (@areas);

	my $mainArea = $prefs->get('radiru_area') || 'tokyo';

	my @items = _radiruRegion($mainArea, 1);

	my @locals;
	for my $area (grep { $_ ne $mainArea } @areas){
		push @locals, _radiruRegion($area);
	}

	#R1を先に持ってくる
	@locals = sort { $a->{_sortkey} cmp $b->{_sortkey} } @locals;

	push @items, +{
		title => 'NHKローカル',
		icon  => 'html/images/radio.png',
		items => \@locals,
	};

	$cb->(\@items);
}

sub _radikoItems {
	my ($cb, $ecb) = @_;

	my $onAuth = sub {
		my (undef, $areaId) = @_;
		$areaId =~ /JP(\d+)/;
		my $title = ' (' . $areaNameJP[$1] . 'エリア)';

		fetchXml("http://radiko.jp/v2/station/list/${areaId}.xml", sub {
			my $xml = shift;
			my @stations = @{$xml->{station}};
			
			#radikoでのNHKを表示するか
			unless ($prefs->get('enable_radiko_nhk')){
				@stations = grep { $_->{name} !~ /^NHK/ } @stations; 
			}

			my @items = map {
				my $name = $_->{name};
				$name .= ' (via radiko)' if $name =~ /^NHK/;
				+{
					name => Slim::Formats::XML::unescapeAndTrim($name),
					url  => 'radiko://' . $_->{id},
					icon => $_->{logo_small},
					type => 'audio',
				};
			} @stations;

			$cb->({
				title => $title,
				items => \@items,
			});
		}, $ecb, expires=>'30 days');
	};

	Plugins::RadiRuKo::RadikoAuth->new(
		$onAuth, sub { $ecb->('(エリア不明)') }
	)->execute('cache');
}

sub _simulRadioItems {
	my ($cb, $ecb) = @_;
	$cb->([{
		name => "コミュニティFM",
		icon => "html/images/radio.png",
		url  => 'http://t-yoshi.github.io/RadiRuKo-Plugin/feed/simulradio-8.opml',
		type => 'slim:link',
	}]);
}

#1-9,0のリモコン数字ボタン
sub _setTextKey {
	my $items = shift;
	my $key=0;
	for (@$items){
		if ($_->{type} eq 'audio'){
			last if ++$key > 10;
			$_->{textkey} = substr($key, -1);
		}
	}
}

sub _asyncMerge {
	my $callback = shift;
	my @generators = @_;

	my %results = map { $_, undef } @generators;

	my $onMerge = sub {
		my $mergedFeed = {
			title => 'らじる&ラジコ ',
			items => [],
		};
		for my $g (@generators){
			my $feed = $results{$g};
			if (ref($feed) eq 'ARRAY') {
				push @{$mergedFeed->{items}}, @$feed; 
			} else {
				$mergedFeed->{title} .= $feed->{title};
				push @{$mergedFeed->{items}}, @{$feed->{items}};
			}
		}
		_setTextKey($mergedFeed->{items});
		#$log->debug(Dumper($mergedFeed));
		$callback->($mergedFeed);
	};

	for my $g (@generators){
		my $cb = sub {
			$results{$g} = shift || [];
			
			$log->debug(Dumper(\%results)) if $log->is_debug;

			$onMerge->() unless (grep { !defined } values(%results));
		};
		my $ecb = sub {
			my $error = shift;
			$cb->([{ 
				title => "$error",
				items => [],
			}]);
		};
		$g->($cb, $ecb);
	}
}

sub createFeed {
	my ($client, $callback, $args) = @_;

	_asyncMerge(
		$callback,
		
		\&_radikoItems,
		\&_radiruItems,
		\&_simulRadioItems,
	);
}

1;
