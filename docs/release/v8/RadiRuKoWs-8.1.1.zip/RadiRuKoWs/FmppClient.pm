package Plugins::RadiRuKoWs::FmppClient;
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

use strict;
use base qw(
    Plugins::RadiRuKoWs::BaseWebSocketHandler 
    Plugins::RadiRuKo::MetadataHandler
);

use Slim::Utils::Log;
use Slim::Music::Info;
use JSON::XS::VersionOneAndTwo;
use Slim::Networking::SimpleAsyncHTTP;

use Data::Dumper;

use Plugins::RadiRuKo::FFMpegHandler;
use Plugins::RadiRuKo::Utils qw(fetchJson);

my $log = logger('plugin.radiruko');

my %configs = (
    'fmpp' => ['https://fmplapla.com', 'https://fmplapla.com/api/select_stream?station=%s&burst=5'],
    'jcba' => ['https://www.jcbasimul.com', 'https://api.radimo.smen.biz/api/v1/select_stream?station=%s&channel=0&quality=high&burst=5'],
);

sub _stationConfig {
    $_[0] =~ m{^([a-z]+)://([a-z\d\-]+)\b};
    my $c = $configs{$1} || return undef;
    return {
        protocol => $1,
        id => $2,
        origin => $c->[0],
        js => sprintf($c->[1], $2),
    };
}

#JCBA/FMPP Client
sub new {
	my $class = shift;
    my $args  = shift;

    $log->debug('url=' . $args->{url});

	my $song = $args->{song};         ## Slim::Player::Song
#	my $track = $song->currentTrack(); ## Slim::Schema::RemoteTrack
#	$track->samplerate(48000);
#	$track->samplesize(16);

    $args->{ws_url} = $song->pluginData('location');

    my $self = $class->SUPER::new($args) or return;

    $self->ws_printf('%s', $song->pluginData('token'));
    return $self;
}

sub _ws_on_new_handshake_client {
    my ($class, $args, $hs) = @_;
    my $u = $args->{url};
    $log->debug("url --> $u");
    $hs->req->{origin} = _stationConfig($u)->{origin};
    $hs->req->{subprotocol} = 'listener.fmplapla.com';
}

sub ws_printf {
    my $self = shift;
    my $fmt = shift;
    my $buf = sprintf($fmt, @_);
    $log->debug('send: ' . $buf);
    $self->ws_write(masked=>1, buffer=>$buf);
}

sub _loadStreamJson {
    my ($class, $config, $cb, $ecb) = @_;

    Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my $http = shift;
			my $hash = eval { from_json($http->content) };
			if (defined $hash){
				$cb->($hash);
			} else {
				$ecb->($@ or 'parse error');
			}
		}, 
		sub {
			my ($http, $err) = @_;
			$ecb->($err);
		}, 
		+{
			'cache'   => 0,
			'Timeout' => 10,
		}
	)->post($config->{js}, 
        'User-Agent'=>'Mozilla/5.0', 
        'Origin' => $config->{origin},
        '', #empty post data
    );
}

sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $client = $song->master();
	my $url    = $song->track()->url;
	
    if (my $config = _stationConfig($url)){
        $log->debug(Dumper($config));
        $class->_loadStreamJson($config,
            sub {
                my $js = shift;
                $log->debug(Dumper($js));

                $song->pluginData(token => $js->{token});
                $song->pluginData(location => $js->{location});
                
                if ($js->{code} == 200){
                    $successCb->();
                } else {
                    $errorCb->("code is " . $js->{code});
                }
            },
            $errorCb
        );
    } else {
        my $err = "Invalid URL: $url";
        $log->error($err);
        $errorCb->($err);
    }
}

sub isRemote { 1 }
sub contentType { 'audio/opus' }
sub getStreamBitrate { 96_000 }
sub getFormatForURL () { 'ops' }

1;
