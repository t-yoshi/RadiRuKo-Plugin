# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::MetadataHandler;

use Slim::Utils::Log;
use Slim::Utils::PerlRunTime;
use Slim::Utils::Timers;
use Slim::Control::Request;
use Slim::Formats::RemoteMetadata;
use Slim::Music::Info;
use Time::HiRes q(time);
use Data::Dumper;
use Plugins::RadiRuKo::Utils qw(createMetaData jpShortDateTimeF);

my $log = logger('plugin.radiruko');

#
# メタデータを返す。
# Note: Touchは10分毎に呼び出してくる。
#      制御アプリは数秒毎に呼び出すこともある。
#
#	{
#          url     => 'ffmpegaac:http://...',
#          artist  => 'Artist Name',
#          album   => 'Album Name',
#          title   => 'Track Title',
#          cover   => 'http://...',
#          bitrate => 128,
#          type    => 'Internet Radio',
#    #Options
#		   expires => Time::HiRes::time()+60, #キャッシュする期限
#          async   => sub ($client, $url, $updateMetadata)  {} #非同期更新
#   }
#
sub getMetadataFor {
    my ($class, $client, $url, $forceCurrent) = @_;

    my $now         = time();
    my $defaultMeta = createMetaData($client, $url, expires => $now + 30);

    return $defaultMeta
        unless ($client->isPlaying() || $client->isPaused());

    my $cachedMeta = $client->master->pluginData('ffMeta') || {};
    if ($cachedMeta->{url} eq $url && $cachedMeta->{expires} > $now) {
        return $cachedMeta;
    }

    #取得中はデフォルトを返す
    $client->master->pluginData('ffMeta', $defaultMeta);

    my $provider = Slim::Formats::RemoteMetadata->getProviderFor($url)
        or return $defaultMeta;
    my $meta = eval { $provider->($client, $url); };
    if (my $err = $@ or !(ref $meta eq 'HASH' and keys %{$meta})) {
        my $name = Slim::Utils::PerlRunTime::realNameForCodeRef($provider);
        $log->error("Metadata provider $name failed: $err");
        return $defaultMeta;
    }

    Slim::Utils::Timers::killTimers($client, \&_notifyNewMetadata);

    if (ref $meta->{async} eq 'CODE') {
        _setMinimumExpires($meta, $now);

        my $async          = delete $meta->{async};
        my $updateMetadata = sub {
            return if (@_ == 0);

            while (my ($k, $v) = splice(@_, 0, 2)) {
                $meta->{$k} = ref($v) eq 'CODE' ? $v->($meta->{$k}) : $v;
            }
            _setMinimumExpires($meta);

            $client->master->pluginData('ffMeta', $meta);
            $log->debug('Set meta expires: ' . localtime($meta->{expires}));
            Slim::Utils::Timers::setTimer($client, $meta->{expires}, \&_notifyNewMetadata);
            _notifyNewMetadata($client);
        };

        Slim::Utils::Timers::setTimer(
            $client, $now,
            sub {
                eval { $async->($client, $url, $updateMetadata) };
                if (my $err = $@) {
                    my $name = Slim::Utils::PerlRunTime::realNameForCodeRef($async);
                    $log->error("Metadata async $name failed: $err");
                }
            }
        );
    } else {
        if (meta->{expires} > $now) {
            $client->master->pluginData('ffMeta', $meta);
            Slim::Utils::Timers::setTimer($client, $meta->{expires}, \&_notifyNewMetadata);
        } else {
            $client->master->pluginData('ffMeta', +{});
        }
    }

    return $meta;
}

sub _notifyNewMetadata {
    my $client = shift;
    my $cb     = sub {
        Slim::Control::Request::notifyFromArray($client, ['newmetadata']);
    };
    Slim::Music::Info::setDelayedCallback($client, $cb, 'output-only');
}

sub _setMinimumExpires {
    my $meta = shift;
    my $now  = shift || time();
    if ($meta->{expires} < $now + 60) {
        $meta->{expires} = $now + 60;
    }
}

1;
