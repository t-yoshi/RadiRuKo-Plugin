# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruHandler;
#
# RADIRU URL protocol handler
#
#  radiru://Station[-Area]
#
#  Station:
#    R1, R2, FM
#  Area:
#    Sendai, Tokyo, Nagoya, Osaka
#
#  See: http://www.nhk.or.jp/radio/config/config_web.xml
#
use strict;
use Data::Dumper;
use Slim::Utils::Misc;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Timers;

use Plugins::RadiRuKo::Utils qw(RE_RADIRU_AUDIO_URL fetchXml);
use Plugins::RadiRuKo::RadiruMeta;
use Plugins::RadiRuKo::RadiruConfig;

my $log   = logger('plugin.radiruko');
my $prefs = preferences('plugin.radiruko');

use base q(Plugins::RadiRuKo::FFMpegHandler);

# new is called by openRemoteStream() for URLs with "radiru:" protocol prefix
sub new {
    my $class = shift;
    my $args  = shift;

    #my $client = $args->{client};
    my $song       = $args->{song};
    my $stream_url = $song->pluginData('stream_url') || return;

    $args->{url} = $stream_url;

    return $class->SUPER::new($args);
}

sub getNextTrack {
    my ($class, $song, $successCb, $errorCb) = @_;

    my $client = $song->master();
    my $url    = $song->track()->url;

    my ($channel, $area) = $url =~ RE_RADIRU_AUDIO_URL or return do {
        my $error = "Invalid URL: $url";
        $log->error($error);
        $errorCb->($error);
    };
    $area ||= 'tokyo';

    my $data = Plugins::RadiRuKo::RadiruConfig->data(area => lc($area));
    my $u    = $data->{ lc($channel . 'hls') };

    #$log->debug("$channel, $area, $u, " . Dumper($data));
    if ($u) {
        $song->pluginData({ stream_url => $u });
        $successCb->();
    } else {
        my $error = "Missing stream_url: $url";
        $log->error($error);
        $errorCb->($error);
    }
}

1;
