# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

package Plugins::RadiRuKo::SimulradioMeta;

use strict;
use utf8;
use URI::Escape qw(uri_unescape);
use Slim::Formats::RemoteMetadata;
use Slim::Utils::Log;
use Data::Dumper;
use Plugins::RadiRuKo::Utils qw(createMetaData RE_SIMULRADIO_AUDIO_URL);

my $log = logger('plugin.radiruko');
#
#
# http://www.simulradio.jp/asx/XXX.asx#simulradio=1;title=タイトル;icon=http://icon-url/;homepage=http://station-homepage/;--
#
# NOTE:
#  拡張子や開始/終了時間だと誤認させないように";--"で終端させる
#
sub _parseUrl {
    my ($url) = @_;

    my ($fragment) = $url =~ RE_SIMULRADIO_AUDIO_URL;
    my $fields = {};
    for (split(/[&;]/, $fragment)) {
        my ($key, $value) = $_ =~ /^([a-z]+)=(.*)/ or next;
        $fields->{$key} = uri_unescape($value);
    }
    return $fields;
}

sub _provider {
    my ($client, $url) = @_;

    my @args;
    my $fields = _parseUrl($url);

    if (defined $fields->{title}) {
        utf8::decode($fields->{title});
        @args = (
            title  => $fields->{title},
            artist => ' ',
            album  => $fields->{homepage},
            cover  => $fields->{icon} || 'html/images/radio.png',
        );
    }

    createMetaData($client, $url, expires => 2**32, @args);
}

sub registerMetaProvider {
    Slim::Formats::RemoteMetadata->registerProvider(
        match => RE_SIMULRADIO_AUDIO_URL,
        func  => \&_provider,
    );
}

1;

