# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoTf::Feed;

use utf8;
use strict;

use Tie::IxHash;
use URI::Escape qw(uri_escape_utf8);
use POSIX qw(strftime);

use Slim::Utils::Log;
use Slim::Utils::DateTime;
use Slim::Utils::Prefs;
use Slim::Utils::Strings;

use Plugins::RadiRuKo::RadikoMeta;
use Plugins::RadiRuKo::RadikoAuth;
use Plugins::RadiRuKo::Utils qw(
	fetchXml jptime parseDateTime  
	fetchJson jpShortDateTimeF enabledPremiumPlugin
	RE_RADIKOTF_AUDIO_URL
);

use Data::Dumper;

my $log = logger('plugin.radiruko');
my $prefs = preferences('plugin.radiruko');

my @Wday = qw(Sun Mon Tue Wed Thu Fri Sat);

#
# URL形式
# radikotf://LFR/20171113110000-20171113112000
#
sub _createUrl {
	my ($self, $stationId, $ftStrTime, $toStrTime) = @_;

	my $ftET = parseDateTime($ftStrTime);

	$ftStrTime =~ s/[\- \:]//g;
	$toStrTime =~ s/[\- \:]//g;

	return "radikotf://$stationId/$ftStrTime-$toStrTime";
}


sub _xmlErrorHandler {
	my $callback = shift;
	my $items = shift || [];
	return sub {
		my ($err, $url) = @_;
		push @$items, { title => "$err: $url" };
		$callback->($items);		
	};
}

#
# *一部NG **全部?
#
sub _createProgramItems {
	my ($self, $stationId, $date) = @_;

	return sub {
		my ($client, $callback, $args) = @_;

		my $onParse = sub {
			my $xml = shift;

			my @progs = grep {
				parseDateTime($_->{to}) < $self->{now};
			} @{$xml->{stations}{station}{progs}{prog}};

			$callback->([map {
				+{
					title => sprintf(
						'%s%s',
						'*' x int($_->{ts_in_ng}),
						$_->{title}
					),
					icon  => 'html/images/radio.png',
					url   => $self->_createUrl($stationId, $_->{ft}, $_->{to}),
					type  => 'audio',
				}
			} @progs]);
		};

		Plugins::RadiRuKo::RadikoMeta::fetchProgramXml(
			$stationId, $date, $onParse, _xmlErrorHandler($callback));
	};
}

sub _fetchStationXml {
	my $self = shift;

	if (1 and $self->{isPremium}) {
		Plugins::RadiRuKoPr::Plugin::fetchAllStationXml(@_, 1);
	} else {
		my $u = 'http://radiko.jp/v3/station/list/' . $self->{areaId} . '.xml';
		fetchXml($u, @_, expires=>'30 days');
	}	
}

sub _createStationItems {
	my ($self, $date) = @_;
	return sub {
		my ($client, $callback, $args) = @_;

		my $onParse = sub {
			my $xml = shift;
			#$log->info(Dumper($xml));
			my @stations = @{$xml->{station}};			
			
			unless (0){ #現在らじるは無し $prefs->get('enable_radiko_nhk')
				@stations = grep { $_->{name} !~ /^NHK/ } @stations;
			}
			
			my @items = map {
				+{
					title => $_->{name},
					icon  => $_->{logo}->[0]->{content},
					url   => $self->_createProgramItems($_->{id}, $date),
				};
			} @stations;
			#$log->debug(Dumper @items);
			$callback->(\@items);
		};

		$self->_fetchStationXml($onParse, _xmlErrorHandler($callback));
	};
}

#
# 検索
#

#URIが古くて日本語含みのquery_formが機能しない
sub urlencode {
	tie(my %q, 'Tie::IxHash', @_);
	return join '&', map {
		$_ . '=' . uri_escape_utf8($q{$_});
	} keys %q;
}

use constant ROW_LIMIT => 50;

sub _fetchSearchJson {
	my $self  = shift;
	my $query = shift;
	my $page  = shift;

	my $uid = preferences('plugin.radiruko')->cookie_rdk_uid();
	my $regionId = $self->{isPremium} ? 'all' : '';
	my $areaId = $self->{areaId};	
	

	my $u = 'http://radiko.jp/v3/api/program/search?' . urlencode(
		key=>$query, filter=>'past', start_day=>'', end_day=>'',
		area_id=>$areaId, region_id=>$regionId,
		cul_area_id=>$areaId, page_idx=>$page, uid=>$uid, 
		app_id=>'pc', row_limit=>ROW_LIMIT);

	$log->debug($u) if ($log->is_debug);

	fetchJson($u, @_);
}

sub _searchTimeFree {
	my ($self, $query, $page, $items, $callback) = @_;

	my $onParse = sub {
		my $hash = shift;
		push @$items, map {
			+{
				title => sprintf('%s (%s - %s)', $_->{title},
							$self->stationName($_->{station_id}),
							jpShortDateTimeF(parseDateTime($_->{start_time}))
						),
				url   => $self->_createUrl($_->{station_id}, $_->{start_time}, $_->{end_time}),
				type  => 'audio',
				_sortKey => $_->{start_time} . '#' . $_->{title},
			}
		} @{$hash->{data}};

		$log->debug("p=$page, r=" . $hash->{meta}{result_count}) if $log->is_debug;

		if ($page < 3 && $hash->{meta}{result_count} > ROW_LIMIT*(1+$page)){
			# 次のページのために再帰
			return $self->_searchTimeFree($query, $page+1, $items, $callback);
		}
		
		#@$items = sort { $b->{_sortKey} cmp $a->{_sortKey} } @$items;
		$callback->($items);			
	};

	$self->_fetchSearchJson($query, $page, 
		$onParse, _xmlErrorHandler($callback, $items)
	);
}

sub stationName {
	my ($self, $stId, $stName) = @_;
	if (defined $stName){ #setter
		$self->{stationNames}{ $stId } = $stName;
	} else { #getter
		return $self->{stationNames}{ $stId } || $stId;		
	}
}

sub new {
	my ($class) = @_;
	my $self = bless {
		areaId => 'JP13',
		isPremium => enabledPremiumPlugin(),
		now => time(),
		stationNames => {}, #stationId=>stationName
	}, $class;

	Plugins::RadiRuKo::RadikoAuth->new(
		sub {
			my ($authToken, $areaId) = @_;
			$self->{areaId} = $areaId;
		}
	)->execute('cache');
	
	fetchXml(
		'http://radiko.jp/v3/station/region/full.xml', 
		sub {
			my $xml = shift;
			my @station = map(@{$_->{station}}, @{$xml->{stations}});
			for (@station){
				$self->stationName(
					$_->{id}, 
					$_->{name}); 					
			}
		}, 
		sub { $log->error($_[0]) },
		expires=>'30 days',
	);

	return $self;
}

sub _weekdayIcon {
	my ($sec,$min,$hour,$mday,$mon,$year,$wday) = jptime($_[0]);
	return "plugins/RadiRuKoTf/html/images/wday$wday.png";
}


#
#  2017/10/01 -> (Stations) -> (Programs)
#
sub createFeed {
	my ($client, $callback, $args) = @_;

	my $feed = __PACKAGE__->new();

	#1週間分 (5時更新)
	my @times = map { $feed->{now} - ($_*24+5)*60*60 } 0..7;
	my @items = map {
		+{
			title => Slim::Utils::DateTime::longDateF($_),
			icon  => _weekdayIcon($_),
			url   => $feed->_createStationItems($_),
		};
	} @times;

	#$items[0]{title} = Slim::Utils::Strings::string('PLUGIN_RADIRUKO_TODAY');
	#$items[1]{title} = Slim::Utils::Strings::string('PLUGIN_RADIRUKO_YESTERDAY');

	push @items, {
		title => Slim::Utils::Strings::string('SEARCHFOR'),
		icon  => 'html/images/search.png',
		type  => 'search',		
		url   => sub {
			my ($client, $callback, $args) = @_;
			$feed->_searchTimeFree($args->{search}, 0, [], $callback);
		},
	};

	$callback->(\@items);
}



1;