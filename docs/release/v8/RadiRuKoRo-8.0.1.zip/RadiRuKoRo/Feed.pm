# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoRo::Feed;

use utf8;
use strict;

use Tie::IxHash;
use URI::Escape qw(uri_escape_utf8);
use POSIX qw(strftime);
use Lingua::JA::Regular::Unicode qw/alnum_z2h space_z2h/;

use Slim::Utils::Log;
use Slim::Utils::DateTime;
use Slim::Utils::Prefs;
use Slim::Utils::Strings;

use Plugins::RadiRuKo::Utils qw(
	parseDateTime fetchJson 
);
use Plugins::RadiRuKo::TextUtil;

use Data::Dumper;

my $log = logger('plugin.radiruko');

sub _programTitle {
	my ($file, $headline) = @_;
	my $t = $headline or ($file->{aa_vinfo} . ' ' . $file->{onair_date});

	if ($file->{file_title} && $headline ne $file->{file_title}){
		$t .= ' ' . $file->{file_title};
	}
	$t =~ s/\s*番組を聴く$//;
	$t .= ' ' . $file->{file_title_sub} if defined $file->{file_title_sub};
#	$t = 'Play' if $t =~ /^\s*$/;

	return Plugins::RadiRuKo::TextUtil->new($t)->z2h->abbreviate()->text;
}

sub _createProgramCallback {
	my $detail_json = shift;
	my $icon = shift;

	return sub {
		my ($client, $callback, $args) = @_;
		my $jsCb = sub {
			my $json = shift;
			my $icon = $json->{main}{thumbnail_p} || $json->{main}{thumbnail_c} || 'html/images/radio.png';
			my @items;
			for (@{$json->{main}{detail_list}}){
				my $headline = $_->{headline};
				my $nFiles = @{$_->{file_list}};

				for (@{$_->{file_list}}){
					my $u = $_->{file_name};
					next unless $u;

					$u =~ s/^https:/radiruod:/;
					my $duration = '';
					#STARTDATE_ENDDATE (番組の長さが不明な場合は9999年?)
					if ($_->{aa_vinfo4} =~ /^(20.+)_(20.+)$/){
						$duration = parseDateTime($2) - parseDateTime($1);
					}
					
					my $title = _programTitle($_, $headline);
					push @items, +{
						title => $title,
						icon  => $icon,
						url   => $u . sprintf(
							'#simulradio=1;duration=%s;title=%s;icon=%s;homepage=%s;--',
								$duration, uri_escape_utf8($title), uri_escape_utf8($icon),
								uri_escape_utf8($_->{official_url} || $_->{share_url})
							),
						type  => 'audio'
					};
				}
			}

			$callback->(\@items);
		};

		fetchJson($detail_json, $jsCb, expires=>'10 min');
	};
}

sub _datalistToItems {
	my $data_list = shift;
	my @items;
	#my $now = time();
	for (@$data_list){
		next if (!$_->{detail_json}); # || parseDateTime($_->{open_time}) > $now);

		my $title = $_->{program_name} . ' ' . $_->{corner_name};
		$title .= sprintf(' [%s]', $_->{onair_date}) if $_->{onair_date};

		push @items, +{
			title => $title,
			icon  => $_->{thumbnail_p},
			url   => _createProgramCallback($_->{detail_json}, $_->{thumbnail_p}),
		};
	}
	return \@items;
}

sub createFeed {
	my ($client, $callback, $args) = @_;

	fetchJson(
		'https://www.nhk.or.jp/radioondemand/json/index_v3/index_genre.json',
		sub {
			my $json = shift;
			my @data_list = @{$json->{genre_list}};
			my @items;
			my $textkey = 0;
			for (@{$json->{genre_list}}){
				my $item = {
					title => $_->{genre},
					icon  => 'html/images/radio.png',
					items => _datalistToItems($_->{data_list}),
				};
				$item->{textkey} = substr($textkey, -1) if $textkey++ <= 10;
				push @items, $item;
			}

			$callback->(\@items);

		}, expires=>'1 min'
	);

}


1;