package Plugins::RadiRuKoFmpp::FmppClient;

use strict;
use base qw(
    Plugins::RadiRuKoFmpp::BaseWebSocketHandler 
    Plugins::RadiRuKo::MetadataHandler
);

use Slim::Utils::Log;
use Slim::Music::Info;
use Data::Dumper;

use Plugins::RadiRuKo::FFMpegHandler;

my $log = logger('plugin.radiruko');

sub stationId {
    $_[0] =~ m|fmpp://([a-z\d]+)\b| ? $1 : undef;
}

sub new {
	my $class = shift;
    my $args  = shift;

    $log->debug('url=' . $args->{url});
	my $station = stationId($args->{url}) or do {
        $log->error('Invalid URL: ' . $args->{url});
        return;
    };

#	my $song  = $args->{song};         ## Slim::Player::Song
#	my $track = $song->currentTrack(); ## Slim::Schema::RemoteTrack
#	$track->samplerate(48000);
#	$track->samplesize(16);

    $args->{origin} = 'wss://fmplapla.com/socket';

    my $self = $class->SUPER::new($args) or return;
    ${*$self}{_fc_count} = 0;
    $self->ws_printf('{"method":"start","station":"%s","burst":5}', $station);
    return $self;
}

sub ws_printf {
    my $self = shift;
    my $fmt = shift;
    my $buf = sprintf($fmt, @_);
    $log->debug('send: ' . $buf);
    $self->ws_write(masked=>1, buffer=>$buf);
}

sub sysread {
	my $self = $_[0];
    my $r = $self->SUPER::sysread($_[1], $_[2], $_[3]);
    if ($r > 0){
        $self->ws_printf(
            '{"method":"continue","count":%d}',
            ${*$self}{_fc_count}++);
    }
    return $r;
}


sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $client = $song->master();
	my $url    = $song->track()->url;
	
    if (stationId($url)){
	    $successCb->();
    } else {
        my $err = "Invalid URL: $url";
        $log->error($err);
        $errorCb->($err);
    }
}

sub isRemote { 1 }
sub contentType { 'audio/opus' }
sub getStreamBitrate { 96_000 }
sub getFormatForURL () { 'ops' }

1;
