# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoRo::ProtocolHandler;
use utf8;
use strict;
use Slim::Utils::Log;

use base qw(Plugins::RadiRuKo::FFMpegHandler);

my $log = logger('plugin.radiruko');

sub new {
    my $class = shift;
    my $args  = shift;

    my $client = $args->{client};

    my $song = $args->{song};

    my ($duration) = $args->{url} =~ /\bduration=(\d+)/;
    $args->{url} =~ s/^radiruod:/https:/;

    $args->{ffoptions} = [
        #FIX: 22/05/13頃からffmpegがエラーになる問題
        -http_seekable => 0,

        #語学番組でたまに404が発生する
        -reconnect_on_http_error => '5xx,404',
    ];

    my $offset = ($song->seekdata() || {})->{timeOffset};
    if ($offset) {
        push(@{ $args->{ffoptions} }, '-ss', "+$offset");    #ffmpeg-seek
        $song->startOffset($offset);
    }
    $song->duration($duration);

    return $class->SUPER::new($args);
}

sub canSeek {
    my ($class, $client, $song) = @_;
    return 1;
}

sub getSeekData {
    my ($class, $client, $song, $newtime) = @_;
    return { timeOffset => int($newtime), };
}

sub getFormatForURL {'aac'}

1;
