# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoTf::ProtocolHandler;
use utf8;
use strict;
use POSIX qw(strftime);
use Slim::Utils::Log;

use Plugins::RadiRuKoTf::Feed;
use Plugins::RadiRuKo::RadikoAuth;
use Plugins::RadiRuKo::RadikoMeta;
use Plugins::RadiRuKo::Utils qw(
    parseDateTime jptime jpShortDateTimeF
    RE_RADIKOTF_AUDIO_URL
);

use base qw(Plugins::RadiRuKo::FFMpegHandler);

my $log = logger('plugin.radiruko');

sub new {
    my $class = shift;
    my $args  = shift;

    my $client = $args->{client};

    my $song      = $args->{song};
    my $authToken = $song->pluginData('authToken') || return;

    my ($stId, $ft, $to, $ftET, $toET) = @{ $song->pluginData('parsedUrl') };

    $args->{ffoptions} = [
        '-post_data', unpack('H*', "flash=1\r\n"),        #ffmpeg binary option
        '-headers',   "X-Radiko-AuthToken: $authToken",
    ];
    my $seek;
    my $offset = ($song->seekdata() || {})->{timeOffset};
    if ($offset) {
        #ex 20161013051000
        $seek = strftime('%Y%m%d%H%M%S', jptime($ftET + $offset));
        push(@{ $args->{ffoptions} }, '-ss', "+$offset");    #ffmpeg-seek
        $song->startOffset($offset);
    }
    $args->{url} = _m3u8Url($stId, $ft, $to, $seek);
    $song->duration($toET - $ftET);

    return $class->SUPER::new($args);
}

sub getNextTrack {
    my ($class, $song, $successCb, $errorCb) = @_;

    my $client = $song->master();
    my $url    = $song->track()->url;

    $url =~ RE_RADIKOTF_AUDIO_URL or return $errorCb->("Invalid URL: $url");
    $song->pluginData(
        #[stationId, ft, to, ftEpochTime, toEpochTime]
        parsedUrl => [ $1, $2, $3, parseDateTime($2), parseDateTime($3) ]
    );

    Plugins::RadiRuKo::RadikoAuth->new(
        sub {
            my ($authToken, $areaId) = @_;
            $song->pluginData(authToken => $authToken);
            $successCb->();
        },
        sub {
            my ($error) = @_;
            $errorCb->($error);
        }
    )->execute();
}

sub canSeek {
    my ($class, $client, $song) = @_;
    return 1;
}

sub getSeekData {
    my ($class, $client, $song, $newtime) = @_;

    #$log->debug($newtime);
    return { timeOffset => int($newtime), };
}

sub _m3u8Url {
    my ($stId, $ft, $to, $seek) = @_;
    my $u = "https://radiko.jp/v2/api/ts/playlist.m3u8?station_id=${stId}&l=15&ft=${ft}&to=${to}";
    $u .= "&seek=${seek}" if $seek;
    return $u;
}

sub getFormatForURL {'aac'}

1;
