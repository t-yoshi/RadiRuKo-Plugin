package Plugins::RadiRuKoFmpp::FmppClient;

use strict;
use base qw(
    Plugins::RadiRuKoFmpp::BaseWebSocketHandler 
    Plugins::RadiRuKo::MetadataHandler
);

use Slim::Utils::Log;
use Slim::Music::Info;
use Data::Dumper;

use Plugins::RadiRuKo::FFMpegHandler;
use Plugins::RadiRuKo::Utils qw(fetchJson);

my $log = logger('plugin.radiruko');

sub stationId {
    $_[0] =~ m|fmpp://([a-z\d\-]+)\b| ? $1 : undef;
}

sub new {
	my $class = shift;
    my $args  = shift;

    $log->debug('url=' . $args->{url});

	my $song  = $args->{song};         ## Slim::Player::Song
#	my $track = $song->currentTrack(); ## Slim::Schema::RemoteTrack
#	$track->samplerate(48000);
#	$track->samplesize(16);

    $args->{ws_url} = $song->pluginData('location');

    my $self = $class->SUPER::new($args) or return;

    $self->ws_printf('%s', $song->pluginData('token'));
    return $self;
}

sub _ws_on_new_handshake_client {
    my ($class, $hs) = @_;
    $hs->req->{origin} = 'https://fmplapla.com';
    $hs->req->{subprotocol} = 'listener.fmplapla.com';
}

sub ws_printf {
    my $self = shift;
    my $fmt = shift;
    my $buf = sprintf($fmt, @_);
    $log->debug('send: ' . $buf);
    $self->ws_write(masked=>1, buffer=>$buf);
}

sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $client = $song->master();
	my $url    = $song->track()->url;
	
    if (my $sId = stationId($url)){
        fetchJson(
            "https://fmplapla.com/api/select_stream?station=$sId&burst=5",
            sub {
                my $js = shift;
                $log->debug(Dumper($js));

                $song->pluginData(token => $js->{token});
                $song->pluginData(location => $js->{location});
                
                if ($js->{code} == 200){
                    $successCb->();
                } else {
                    $errorCb->("code is " . $js->{code});
                }
            },
            $errorCb,
            expires=>'0'
        );

    } else {
        my $err = "Invalid URL: $url";
        $log->error($err);
        $errorCb->($err);
    }
}

sub isRemote { 1 }
sub contentType { 'audio/opus' }
sub getStreamBitrate { 96_000 }
sub getFormatForURL () { 'ops' }

1;
