# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKo::Plugin;

use strict;
use File::Spec;

use vars qw($VERSION);
use Slim::Utils::Misc;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::OSDetect;
use Slim::Utils::Timers;

use base qw(Slim::Plugin::OPMLBased);


# create log categogy before loading other modules
my $log = Slim::Utils::Log->addLogCategory( {
	category     => 'plugin.radiruko',
	defaultLevel => 'INFO',
	description  => getDisplayName(),
});

use Plugins::RadiRuKo::Utils qw(feedCompat);
use Plugins::RadiRuKo::FFMpegHandler;
use Plugins::RadiRuKo::RadikoHandler;
use Plugins::RadiRuKo::RadiruHandler;
use Plugins::RadiRuKo::AuthRadiko;

my $prefs = preferences('plugin.radiruko');

use Plugins::RadiRuKo::RadikoMeta;
use Plugins::RadiRuKo::RadiruMeta;
use Plugins::RadiRuKo::SimulradioMeta;
use Plugins::RadiRuKo::MenuOpml;

use Plugins::RadiRuKo::Settings;

sub getDisplayName {
	return 'PLUGIN_RADIRUKO_NAME';
}

#
# 実行ファイル検索パスに追加
#	Mac: Bin/_darwin
#	Windows: Bin/_win32
#	FreeBSD: Bin/i386-linux
#
sub _addPluginFindBinPath {
	my $class = shift;

	my $binDir;
	if (Slim::Utils::OSDetect::isWindows()){ 
		$binDir = '_win32';
	} elsif (Slim::Utils::OSDetect::isMac()){ 
		$binDir = '_darwin';
	} else {
		#FreeBSD
		my $osDetails = Slim::Utils::OSDetect::details();
		if ($osDetails->{osArch} =~ /(i\d86|amd64|x86_64)-freebsd/i){
			$binDir = 'i386-linux';
		}
	}
	if ($binDir){
		my $baseDir = $class->_pluginDataFor('basedir');
		my $binPath = File::Spec->catdir($baseDir, 'Bin', $binDir);
		Slim::Utils::Misc::addFindBinPaths($binPath);		
	}
}

sub initPlugin {
	my $class = shift;
	my $version = $class->_pluginDataFor('version');
	$log->info('Initialising.. RadiRuKo-Plugin v' . $version);

	$class->SUPER::initPlugin(
		tag    => 'radiruko',
		menu   => 'radios',
		weight => 1.01, # ラジオの先頭にメニュー表示
	);

	$class->_addPluginFindBinPath();

	Plugins::RadiRuKo::AuthRadiko::init();

	Plugins::RadiRuKo::FFMpegHandler::init();
	Plugins::RadiRuKo::RadikoHandler::init();
	Plugins::RadiRuKo::RadiruHandler::init();	

	Plugins::RadiRuKo::RadikoMeta::registerMetaProvider();
	Plugins::RadiRuKo::RadiruMeta::registerMetaProvider();
	Plugins::RadiRuKo::SimulradioMeta::registerMetaProvider();

	Plugins::RadiRuKo::Settings->new();

	return 1;
}

sub feed {
	my $class = shift;
	my $client = shift;
	
	return feedCompat(
		$class, $client,
		\&Plugins::RadiRuKo::MenuOpml::createFeedAsync
	);
}

sub playerMenu { 'RADIO' }

sub getFunctions(){ return {}; }

1;
