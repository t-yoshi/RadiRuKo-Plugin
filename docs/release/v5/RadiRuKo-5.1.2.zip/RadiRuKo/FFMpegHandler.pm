# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::FFMpegHandler;
#
# URL protocol handler
#     
# ffhls: HTTP Live Streaming
# ffhlsadts: HTTP Live Streaming / ADTS
# ffrtmp: RTMP
# ffrtmpe: RTMPE
#
use strict;
use File::Spec;
use Slim::Utils::Misc;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::PerlRunTime;
#use Data::Dumper;
use Slim::Formats::RemoteMetadata;
use Slim::Control::Request;
use Plugins::RadiRuKo::Utils;

use base q(Slim::Player::Pipeline);

my $log = logger('plugin.radiruko');

sub init {
	my @protocols = qw(ffhls ffhlsadts ffrtmp ffrtmpe rtsp mmst);
	#my @protocols = qw(ffhls ffhlsadts ffrtmp ffrtmpe rtsp mmst ffmpeg);
	$log->info("Register protocols: @protocols");

	# register protocol handler
	foreach my $proto (@protocols){     
		Slim::Player::ProtocolHandlers->registerHandler($proto, __PACKAGE__);
	}
}

sub new {
	my $class = shift;
	my $args  = shift;

	my $transcoder = $args->{'transcoder'};
	my $url        = $args->{'url'};
	my $client     = $args->{'client'};

	#$log->info("url: '$url'");

	$url =~ s|#.*$||;
	$url =~ s|^ff(rtmp[e]?://.+)|$1|;	
	$url =~ s|^ffhls(?:adts)?(://.+)|http$1|;
	#$url =~ s=^ffmpeg://((http|rt|mms).*://.+)=$1=;
	#$url =~ s|^ffhttps(://.+)|https$1|;	
	#if ($url =~ /^rtsp/){
	#	$args->{_radiruko_command_substitute} = {
	#		FF_OPTIONS => ['-rtsp_transport', 'tcp'],
	#	};
	#}
	#$log->info("url2: '$url'");

	my $command = Slim::Player::TranscodingHelper::tokenizeConvertCommand2(
		$transcoder, $url, $url, 1, undef
	);

	#ex. {arg=>['-arg', 'arg1']} -> #ARG1# to "-arg" "arg1" 
	_commandSubstitute(\$command, $args->{_radiruko_command_substitute});

	$log->info("Command: '$command'");

	my $self = $class->SUPER::new(undef, $command, 1);

	my $format = $transcoder->{'streamformat'};
	${*$self}{'contentType'} = $format;

	#TODO: 48khz-PCMも可能だが、SqueezePlay(WinPC)で頻々にバッファが発生する。
	#if ($format eq 'pcm'){ 
	#  my $song  = $args->{song};         ## Slim::Player::Song
	#  my $track = $song->currentTrack(); ## Slim::Schema::RemoteTrack
	#  $track->samplerate(44100);
	#  $track->samplesize(16);
	#}

	return $self;
}

sub _commandSubstitute {
	my $cmdref = shift;
	my $substitute = shift || {};

	foreach my $k (keys %{$substitute}) {
		my $opts = $substitute->{$k};
		$opts = [$opts] if ref($opts) ne 'ARRAY';
		$opts = Plugins::RadiRuKo::Utils::escapeCommands(@$opts);
		$$cmdref =~ s/#$k#/$opts/g;
	}
	$$cmdref =~ s/#[A-Z_]+#//g;
}

#
# SBTouchは10分毎に呼び出す。
# その他のアプリ等は数秒毎に呼び出す。
#
sub getMetadataFor {
	my ($class, $client, $url, $forceCurrent) = @_;

	my $provider = Slim::Formats::RemoteMetadata->getProviderFor($url);
	if ($provider) {
		my $meta = eval { $provider->($client, $url); };
		if ($@) {
			my $name = Slim::Utils::PerlRunTime::realNameForCodeRef($provider);
			$log->error("Metadata provider $name failed: $@");
		}
		return $meta if (ref($meta) eq 'HASH' && keys %{$meta});
	}

	return {
		title => Slim::Music::Info::getCurrentTitle($url),
		icon  => 'html/images/radio.png',
		type  => $client->string('RADIO'),
	};
}

sub canHandleTranscode {
	my ($self, $song) = @_;  
	return 1;
}

sub getStreamBitrate {
	my ($self, $maxRate) = @_;  
	return Slim::Player::Song::guessBitrateFromFormat(${*$self}{'contentType'}, $maxRate);
}

sub contentType {
	my $self = shift;
	return ${*$self}{'contentType'};
}

# XXX - I think that we scan the track twice, once from the playlist and then again when playing
sub scanUrl {
	my ($class, $url, $args) = @_;  
	Slim::Utils::Scanner::Remote->scanURL($url, $args);
}

sub canDirectStream { 0; }

sub isRemote { 1; } 

sub isAudioURL {  1; }

1;
