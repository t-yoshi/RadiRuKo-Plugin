# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKoPr::Plugin;

use strict;

use vars qw($VERSION);
use Slim::Utils::Misc;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Strings;
use Data::Dumper;

use base qw(Slim::Plugin::OPMLBased);


my $prefs;
my $log;

sub getDisplayName {
	return 'PLUGIN_RADIRUKO_PREMIUM_NAME';
}

sub initPlugin {
	my $class = shift;

	my $minBasicVersion = $class->_pluginDataFor('_minBasicVersion');
	my $basicFound = eval {
		require Plugins::RadiRuKo::Utils;		
		Plugins::RadiRuKo::Utils::checkBasicVersion($minBasicVersion);
	};
	if ($@ || !$basicFound){
		logError("Please install BasicPlugin >= $minBasicVersion");
		return;
	}

	$prefs = preferences('plugin.radiruko');
	$log = logger("plugin.radiruko");
	
	$log->info("Register protocol: radikop");
	Slim::Player::ProtocolHandlers->registerHandler(
		"radikop", q(Plugins::RadiRuKo::RadikoHandler)
	);

	require Plugins::RadiRuKo::RadikoHandler;	
	Plugins::RadiRuKo::Utils->import(qw(fetchXml fetchJson feedCompat));


	$class->SUPER::initPlugin(
		tag    => 'radirukopr',
		menu   => 'radios',
		weight => 1.02, # ラジオの先頭にメニュー表示
	);

	return 1;
}

sub _failedFeed {
	return +{
		title => Slim::Utils::Strings::string('PLUGIN_RADIRUKO_PREMIUM_NAME'),
		items => [ {title => shift} ],
	};
}

sub _createFeed {
	my ($client, $callback, $args) = @_;
	my @allstation;

	my $cbExclude = sub {
		my $json = shift;
		#$log->debug('excludes: ' . Dumper($json));
		my %excludeIds = +(eval {
			map {
				map({$_ => 1} keys(%{$_}))
			} grep(ref eq 'HASH', values %{$json});
		});

		$log->debug('Premium excludes: ' . join(', ', keys %excludeIds)) if ($log->is_debug);

		my @items;
		foreach my $station (@allstation){
			my $id = $station->{id}{content};
			next if $excludeIds{$id};

			my $url = "radikop://$id";
			push @items, {
				title => $station->{name}{content},
				url   => $url,
				value => $url,
				icon  => "http://radiko.jp/v2/static/station/logo/${id}/logo_xsmall.png",
				type  => 'audio',
			};
		}
		$callback->({
			title => Slim::Utils::Strings::string('PLUGIN_RADIRUKO_PREMIUM_NAME'),
			items => \@items,
		});
	};

	my $cbStation = sub {
		my $xml = shift;
		return _failedFeed($xml->{_failed}) if ($xml->{_failed});

		@allstation = map(@{$_->{station}}, @{$xml->{stations}});
		#$log->debug(Dumper(\@allstation));

		fetchJson(
			'http://radiko.jp/v2/station/exclude_areafree/list.json', 
			$cbExclude, cacheExpire=>'30 days'
		);
	};

	fetchXml(
		'http://radiko.jp/v2/station/region/full.xml', 
		$cbStation, cacheExpire=>'30 days'
	);
}

sub feed {
	my $class = shift;
	my $client = shift;

	unless ($prefs->get('cookie_radiko_session')){
		return _failedFeed('Require radiko_session');
	}

	return feedCompat($class, $client, \&_createFeed);
}


sub playerMenu { 'RADIO' }

sub getFunctions(){ return {}; }

1;
