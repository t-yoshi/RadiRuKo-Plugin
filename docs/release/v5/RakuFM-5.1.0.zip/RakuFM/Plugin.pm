# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RakuFM::Plugin;

use strict;
use vars qw($VERSION);

use utf8;
use Slim::Formats::XML;
use Slim::Formats::RemoteMetadata;
use Slim::Utils::Log;
use Slim::Utils::Strings;
use Slim::Utils::Prefs;
use Slim::Utils::Unicode;
use Slim::Utils::Timers;
use Slim::Control::Request;
use Slim::Music::Info;

use Date::Parse;
use IO::File;
use File::Spec;
use JSON::XS::VersionOneAndTwo;
use POSIX qw(strftime);
use Data::Dumper;
use List::Util qw(first);

use base qw(Slim::Plugin::OPMLBased);

my $log;

sub getDisplayName {
	return 'PLUGIN_RAKUFM_NAME';
}

sub initPlugin {
	my $class = shift;

	#$log->info('Initialising.. RakuFM-Plugin v' . $class->_pluginDataFor('version'));
	my $minBasicVersion = $class->_pluginDataFor('_minBasicVersion');
	my $basicFound = eval {
		require Plugins::RadiRuKo::Utils;		
		Plugins::RadiRuKo::Utils::checkBasicVersion($minBasicVersion);
	};
	if ($@ || !$basicFound){
		logError("Please install BasicPlugin >= $minBasicVersion");
		return;
	}

	$log = logger("plugin.radiruko");

	require Plugins::RadiRuKo::RadikoHandler;
	Plugins::RadiRuKo::Utils->import(qw(
		fetchJson jptime abbreviate notifyNewMeta 
		notifyNewMetaAt refSize parseDateTime
		feedCompat
	));

	$class->SUPER::initPlugin(
		tag    => 'rakufm',
		menu   => 'radios',
		weight => 1.03, # ラジオの先頭
	);

	Slim::Formats::RemoteMetadata->registerProvider(
		match => qr{^http://rakuten\.},
		func  => \&_metaProvider,
	);
	#Slim::Formats::RemoteMetadata->registerParser(
	#	match => qr{^http://rakuten\.},
	#	func  => \&notifyNewMeta, #->($client, $url, $metadata)
	#);
	return 1;
}

sub _createFeed {
	my $jsStation = shift;

	my @stations = @{ $jsStation->{stations} or [] };
	#現在放送中か
	my %nowOnAir = map {
		+($_, refSize($_->{liveinfo}{shows}{current}))
	} @stations;
	
	@stations = (
		grep({  $nowOnAir{$_} } @stations),
		grep({ !$nowOnAir{$_} } @stations),
	);

	my @items;
	for my $station (@stations){
		my $name = $station->{name};
		my $url = $station->{endpoint}{main};

		unless ($nowOnAir{$station}){
			$name .= ' (' . _nextShowTime($station) . ')';
		}
		#$name .= Dumper($station->{liveinfo}->{shows}->{current});

		push @items, {
			name  => Slim::Formats::XML::unescapeAndTrim($name),
			url   => $url,
			value => $url || $name,
			icon  => $station->{logo},
			type  => 'audio',
		};
	}

	my $title = 'Rakuten FM ';
	if (defined $jsStation->{_failed}){
		$title .= $jsStation->{_failed};
	} else {
		$title .= '(' . _jpTimeF($jsStation->{_fetchTime}) . ')';
	}

	return {
		title => $title,
		items => \@items,
	};
}

sub _fetchStationJson {
	my $callback = shift; #->(hash)
	return fetchJson(
		'http://api.rakuten.fm/list/station',
		$callback, cacheExpire=>'5 min'
	);
}

#see XMLBrowser.pm
sub feed {
	my $class = shift;
	my $client = shift;
	my $feed = sub {
		my ($client, $callback, $args) = @_;
		_fetchStationJson(sub {
			my $js = shift;
			$callback->(_createFeed($js));
		});
	};
	return feedCompat($class, $client, $feed);
}


#
# 鯖のロケール設定に関係なく日本時間を表示する。
#
sub _jpTimeF {
	my @tm = jptime(shift);
	my $timeFormat = preferences('server')->get('timeFormat');
	my $time = strftime($timeFormat, @tm);
	$time =~ s/\|0?(\d+)/$1/;
	return Slim::Utils::Unicode::utf8decode_locale($time);
}

# ex '8/31 12:34'
sub _jpShortDateTimeF {
	my $time = shift;
	my @tm;
	if ($time != 0){#string
		@tm = strptime($time);
	} else {
		@tm = jptime($time); #int
	}

	my $serverPrefs = preferences('server');
	my $dateFormat = $serverPrefs->get('shortdateFormat');
	my $timeFormat = $serverPrefs->get('timeFormat');
	$dateFormat =~ s=\W*%[yY][^%]*==; #年は省略
	$dateFormat =~ s=(?<!\|)%m([\.\-/]%d)=|%m$1=; #月の0を除く 08 -> 8
	#$log->info("$dateFormat $timeFormat");

	my $date = strftime("$dateFormat $timeFormat", @tm);
	$date =~ s/\|0*//g; #see DateTime.pm
	return Slim::Utils::Unicode::utf8decode_locale($date);
}

sub _trimTitle {
	my $str = Slim::Formats::XML::unescapeAndTrim(shift);
	return abbreviate($str, shift || 200); #半角換算の文字幅
}

sub _nextShowTime {
	my $station = shift;
	my $now = time();
	my ($next) = @{$station->{liveinfo}{shows}{next}};

	return Slim::Utils::Strings::string('PLUGIN_RAKUFM_UNDECIDED')
			unless refSize($next);

	return _jpShortDateTimeF($next->{starts}) . '-';
}

sub _updateMetaFromJson {
	my ($client, $url, $meta) = @_;

	#キャッシュ
	my $jsStation = _fetchStationJson(sub {
		my $hash = shift;
		notifyNewMeta($client) if (!$hash->{_isCache} && !$hash->{_failed});
	});
	return if $jsStation->{_failed};

	my $station = first { 
		$_->{endpoint}{main} eq $url 
	} @{$jsStation->{stations}} or return;

	my @shows = (
		$station->{liveinfo}{shows}{current},
		@{ $station->{liveinfo}{shows}{next} },
	);

	my $now = time();
	my $nowOnAir = sub {
		$_ && $now >= parseDateTime($_->{starts}) && parseDateTime($_->{ends}) > $now
	};   

	my $currShow = first { &$nowOnAir } @shows;
	my $currTrack = first { &$nowOnAir } values %{ $station->{liveinfo}{tracks} };

	my $cover = $currShow->{image_path} || $station->{logo};

	my $progName = $station->{name};
	if (refSize($currShow)){
		if (refSize($currTrack)){
			my $trackName = $currTrack->{name};
			$trackName =~ s/^[\s\-]+//;
			$progName = $currShow->{name} . ' / ' . $trackName;
		} else {
			$progName .= ' - ' . $currShow->{name};
		}
	} else {
		$progName .= ' (Next: ' . _nextShowTime($station) . ')';
	}
	#$log->info("currShow: " . Dumper($currShow));

	#現在の番組orトラック終了時にメタ更新を通知する
	notifyNewMetaAt($client, $currShow->{ends}, $currTrack->{ends});
	 	 
	$meta->{title}  = _trimTitle($progName, 80);
	$meta->{artist} = _trimTitle($station->{name});
	$meta->{album}  = _trimTitle($currShow->{description});
	$meta->{cover}  = $cover;
}

sub _metaProvider {
	my ($client, $url) = @_;
	my $meta = {
		title => Slim::Music::Info::getCurrentTitle($client, $url),
		cover => 'html/images/radio.png',
		type  => 'Rakuten FM',
	};
	if ($client->isPlaying() || $client->isPaused()){
		_updateMetaFromJson($client, $url, $meta);
	}
	return $meta;
}


sub playerMenu { 'RADIO' }

sub getFunctions(){ return {}; }

1;
