# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadikoMeta;

use strict;
use utf8;
use POSIX;
use List::Util qw(first);
use Slim::Utils::Log;
use Slim::Utils::Strings;
use Slim::Music::Info;
use Plugins::RadiRuKo::Utils qw(
	jptime stripTagAndAbbreviate 
	radikoId fetchXml notifyNewMetaAt parseDateTime
);

my $log = Slim::Utils::Log::logger("plugin.radiruko");

sub _fetchProgramXml {
	my $id = shift || 'ALL'; #stationId or areaId
	my $now = time();
	my $time = shift || $now; #エポック時間
	$time -= 5*60*60; #朝５時更新

	my $date = strftime('%Y%m%d', jptime($time));
	my $expire = ($now - $time > 24*60*60) ? '7 days':'1 hour';

	my $u = ($id =~ /^JP\d+/) ?
		"http://radiko.jp/v3/program/date/$date/$id.xml" :        #JP13
		"http://radiko.jp/v3/program/station/date/$date/$id.xml"; #FMJ
	
	push @_, (cacheExpire=>$expire);
	return fetchXml($u, @_);
}

sub _updateMetaFromXml {
	my ($client, $stId, $time, $meta) = @_;

	my $xml = _fetchProgramXml($stId, $time);
	return if $xml->{_failed};

	my $station = $xml->{stations}{station} or return;

	$meta->{title} = $station->{name}{content};

	#いま放送中のprog
	my $prog = first {
		$time >= parseDateTime($_->{ft}) && parseDateTime($_->{to}) > $time
	} @{$station->{progs}{prog}} or do {
		$log->error(jptime($time) . " not found.");		
		return;
	};

	# 番組info内に画像があれば使う。
	my $info = $prog->{info}->{content} || '';
	my ($image) = $info =~ m{\bhttp://[-_.a-zA-Z0-9;/?:@&=+\$,%]+\.(?:gif|jpe?g|png)\b}g;

	$meta->{title} .= ' - ' . stripTagAndAbbreviate($prog->{title}{content});
	$meta->{artist} = stripTagAndAbbreviate($prog->{pfm}{content});
	$meta->{album} = stripTagAndAbbreviate($prog->{desc}{content}) || $meta->{album};
	$meta->{cover} = $image || "http://radiko.jp/station/logo/$stId/logo_large.png";

	#次の番組開始時間にメタ更新を予約する
	notifyNewMetaAt($client, $prog->{to});
}

sub _metaProvider {
	my ($client, $url) = @_;

	my $stId = radikoId($url);
	
	$stId || return { title => "invalid url [$url]" };

	my $type = 'radiko';
	$type .= ' premium' if ($url =~ /^radikop:/); 

	my $meta = {
		title    => $stId,
		album    => ' ',
		icon     => 'plugins/RadiRuKo/html/images/icon.gif',
		bitrate  => '48kbps',
		type     => "AAC ($type)",
	};

	if ($client->isPlaying() || $client->isPaused()){
		_updateMetaFromXml($client, $stId, time(), $meta);
	}
	return $meta;
}


sub registerMetaProvider {
	Slim::Formats::RemoteMetadata->registerProvider(
		match => qr{(^|#)radikop?(://|=)},
		func  => \&_metaProvider,
	);
}

1;
