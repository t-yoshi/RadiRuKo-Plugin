package Plugins::RadiRuKo::MenuOpml;
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
use utf8;
use strict;

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Formats::XML;
use Plugins::RadiRuKo::Utils qw(fetchXml);
use Plugins::RadiRuKo::RadiruHandler;
use Plugins::RadiRuKo::AuthRadiko;
use Data::Dumper;

my $log = logger('plugin.radiruko');
my $prefs = preferences('plugin.radiruko');

my @areaNameJP = (undef, qw(
北海道 青森 岩手 宮城 秋田 山形 福島 茨城 栃木 群馬
埼玉 千葉 東京 神奈川 新潟 富山 石川 福井 山梨 長野
岐阜 静岡 愛知 三重 滋賀 京都 大阪 兵庫 奈良 和歌山
鳥取 島根 岡山 広島 山口 徳島 香川 愛媛 高知 福岡
佐賀 長崎 熊本 大分 宮崎 鹿児島 沖縄
));

sub _radiruRegion {
	my $self  = shift;
	my $props = shift; #{area=>tokyo,...
	my $addR2 = shift; #R2を含めるか

	my @items;

	foreach my $channel (qw(R1 R2 FM)){
		next if ($channel eq 'R2' && !$addR2);

		my $area = ucfirst($props->{area});
		my $areajp = $props->{areajp};
		my $areakey = $props->{areakey};

		my $name = Slim::Utils::Strings::string("PLUGIN_RADIRUKO_NHK_$channel");

		if ($channel eq 'R2' and $area !~ /tokyo/i){
			$area = 'Tokyo';
			$areajp = $areakey = '';
		}
		my $url = "radiru://$channel-$area";
		my $icon = "plugins/RadiRuKo/html/images/NHK_$channel.png";

		#ローカル局: R1の後にFMを並べる
		my $sortkey = ($channel eq 'FM') ? '1#': '0#';

		push @items, {
			name  => $name . $areajp,
			url   => $url,
			value => $url,
			icon  => $icon,
			type  => 'audio',

			_sortkey => $sortkey . $areakey,
		};
	}
	return @items;
}

sub _addRadiruItems {
	my $self = shift;
	my $radiruConfig = shift;
	my $items = $self->{items};

	my @areas = keys %$radiruConfig;
	return unless (scalar @areas);

	my $areaMain = $prefs->get('radiru_area') || 'tokyo';	
	push @$items, $self->_radiruRegion($radiruConfig->get($areaMain), 1);

	my @locals;
	foreach my $area (grep { $_ ne $areaMain } @areas){
		push @locals, $self->_radiruRegion($radiruConfig->get($area));
	}

	#R1を先に持ってくる
	@locals = sort { $a->{_sortkey} cmp $b->{_sortkey} } @locals;

	push @$items, {
		title => 'NHKローカル',
		icon  => 'html/images/radio.png',
		items => \@locals,
	};
}

sub _addRadikoItems {
	my $self  = shift;

	# XMLin済みの http://radiko.jp/v2/station/list/JP13.xml
	my $stationXml = shift;

	foreach my $station (@{$stationXml->{station}}){
		my $name = Slim::Formats::XML::unescapeAndTrim($station->{name}{content});
		my $url = 'radiko://' . $station->{id}{content};
		my $icon = $station->{logo_small}{content};
		#$outlines .= "\t<outline text=\"$name\" URL=\"$url\" type=\"audio\" icon=\"$icon\" />\n";

		push @{$self->{items}}, {
			name  => $name,
			url   => $url,
			value => $url,
			icon  => $icon,
			type  => 'audio',
		};
	}
}

sub _addSimulRadios {
	my $self  = shift;
	my $items = $self->{items};
	push @$items, {
		name => "コミュニティFM",
		icon => "html/images/radio.png",
		url  => 'http://t-yoshi.github.io/RadiRuKo-Plugin/feed/simulradio50.opml',
		type => 'link',
	};
}

#リモコン数字ボタン
sub _markTextKey {
	my $self  = shift;
	my $items = $self->{items};
	my $i = 0;
	foreach my $c (1 .. 9, 0){
		my $item = $items->[$i++];
		last unless defined $item;
		$item->{textkey} = $c;
	}
}

sub createFeedAsync {
	my ($client, $feedCallback, $args) = @_;

	my $menuOpml = bless {
		title => 'らじる&ラジコ ',
		items => [],
	};

	my $cbRadiru = sub {
		$menuOpml->_addRadiruItems(shift);
		$menuOpml->_addSimulRadios();
		#$menuOpml->_markTextKey();
		#to hash
		$feedCallback->({%$menuOpml});
	};

	my $cbRadiko = sub {
		my ($areaName, $xml, $err) = @_;
		$menuOpml->{title} .= "($areaName) $err";
		if ($xml){
			$menuOpml->_addRadikoItems($xml);
		}
		Plugins::RadiRuKo::RadiruHandler::config->fetch($cbRadiru);
	};

	my $auth = Plugins::RadiRuKo::AuthRadiko->new();
	#radiko 'JP13'
	my ($areaId) = $auth->areaId || $auth->connect();

	if ($areaId =~ /JP(\d+)/){
		my $areaName = $areaNameJP[$1] . 'エリア';
		fetchXml("http://radiko.jp/v2/station/list/${areaId}.xml",
			sub {
				my $radikoXml = shift;
				$cbRadiko->($areaName, $radikoXml);
			}, cacheExpire=>'30 days'
		);
	} else {
		$cbRadiko->('エリア不明', undef, $auth->error);
	}
}

1;

__END__

<?xml version="1.0" encoding="UTF-8"?>
<opml version="1.0">
	<head title="らじる&amp;ラジコ ($areaName)" >
		<expansionState></expansionState>
	</head>
	<body>

		radiko...

		<outline text="NHKラジオ第1" URL="radiru://R1-Tokyo" icon="plugins/RadiRuKo/html/images/NHK_R1.png" type="audio" />
		<outline text="NHKラジオ第2" URL="radiru://R2-Tokyo" icon="plugins/RadiRuKo/html/images/NHK_R2.png" type="audio" />
		<outline text="NHK-FM" URL="radiru://FM-Tokyo" icon="plugins/RadiRuKo/html/images/NHK_FM.png" type="audio" />

		<outline icon="html/images/radio.png" text="NHKローカル">
			<outline text="NHKラジオ第1仙台" URL="radiru://R1-Sendai" icon="plugins/RadiRuKo/html/images/NHK_R1.png" type="audio" />
			<outline text="NHKラジオ第1名古屋" URL="radiru://R1-Nagoya" icon="plugins/RadiRuKo/html/images/NHK_R1.png" type="audio" />
			<outline text="NHKラジオ第1大阪" URL="radiru://R1-Osaka" icon="plugins/RadiRuKo/html/images/NHK_R1.png" type="audio" />
			<outline text="NHK-FM仙台" URL="radiru://FM-Sendai" icon="plugins/RadiRuKo/html/images/NHK_FM.png" type="audio" />
			<outline text="NHK-FM名古屋" URL="radiru://FM-Nagoya" icon="plugins/RadiRuKo/html/images/NHK_FM.png" type="audio" />
			<outline text="NHK-FM大阪" URL="radiru://FM-Osaka" icon="plugins/RadiRuKo/html/images/NHK_FM.png" type="audio" />
		</outline>

		<outline text="コミュニティFM" URL="http://t-yoshi.github.io/RadiRuKo-Plugin/feed/simulradio40.opml" icon="html/images/radio.png" />

	</body>
</opml>
