# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::AuthRadiko;

use strict;
use HTTP::Request;
use IO::File;
use MIME::Base64;
use Digest::MD5 qw(md5_hex);
use Slim::Utils::Log;
use Slim::Utils::Misc;
use Slim::Utils::Prefs;
use Plugins::RadiRuKo::Utils qw(getCache);

my $log = Slim::Utils::Log::logger("plugin.radiruko");

use LWP::UserAgent;
use Plugins::RadiRuKo::SwfDump;

my $swfUrl = 'http://radiko.jp/apps/js/flash/myplayer-release.swf';
my $swfKeyId   = 12;
my $appVersion = '4.0.0';


#HTTPS
my $clsLwpUserAgent;

sub getUserAgent {
	my ($class) = @_;
	return $clsLwpUserAgent;
}

my $prefs = preferences('plugin.radiruko');

#
#  一部のNASではSSL関連のモジュールがインストールされていないので、
# LWP::UserAgentでhttpsを扱えないことがある。
# その場合は自前のcurlコマンドでhttpsにアクセスする。
#

sub isSslAvailable {
	return eval { require LWP::Protocol::https; };
}

sub init {
	$prefs->cookie_rdk_uid(md5_hex(int(rand (10000)) . time()));

	if (isSslAvailable() || main::ISMAC || main::ISWINDOWS){
		# Win, Mac, 大多数のLinux
		$clsLwpUserAgent = q(LWP::UserAgent);
	} else {
		# 一部のNAS
		require Plugins::RadiRuKo::CurlUserAgent;
		if (!Plugins::RadiRuKo::CurlUserAgent::init()){
			$log->error('[curl] initialize error.');
			return;
		}
		$clsLwpUserAgent = q(Plugins::RadiRuKo::CurlUserAgent);
	}
	$log->info("Https User-Agent is '$clsLwpUserAgent'");
}

# radiko認証を行う。
# 成功した場合、結果を10分間キャッシュする。
#
sub new {
	my ($class) = @_;

	my $cookie_radiko_session = $prefs->get('cookie_radiko_session');
	my $cacheKeyPrefix = 'radiruko:AuthRadiko-';
	if ($cookie_radiko_session) {
		$cacheKeyPrefix .= $cookie_radiko_session . '-';
		$log->debug("Premium: radiko_session=$cookie_radiko_session") if $log->is_debug;
	}

	my $basedir = Plugins::RadiRuKo::Plugin->_pluginDataFor('basedir');

	return bless {
		_keypath => File::Spec->catfile($basedir, "_radikokey_app${appVersion}.png"),
		_cookie_rdk_uid => $prefs->get('cookie_rdk_uid'),
		_cookie_radiko_session => $cookie_radiko_session,
		_cacheKeyPrefix => $cacheKeyPrefix,
	}, $class;
}

sub _getKeyFile {
	my ($self) = @_;
	my $req = HTTP::Request->new('GET', $swfUrl);
	my $ua = LWP::UserAgent->new(); #httpなのでLWP::UserAgentでよい
	$ua->timeout(10);
	my $res = $ua->request($req);
	if (!$res->is_success()){
		$self->{error} = "_getKeyFile: $swfUrl download error. ";
		return;
	}
	my $tmp_fh = IO::File->new_tmpfile();
	$tmp_fh->binmode();
	my $content = $res->decoded_content();

	$log->debug("player.swf length=" . length($content) ." sig=" . substr($content, 0, 3)) if $log->is_debug;

	$tmp_fh->write($content, length($content));
	$tmp_fh->seek(0, SEEK_SET);

	my $swfdump = Plugins::RadiRuKo::SwfDump->new();
	my $ret = $swfdump->open($tmp_fh) &&
			$swfdump->writeBinary($swfKeyId, $self->{_keypath});
	if (!$ret){
		$self->{error} = 'swfdump error: ' . $swfdump->error();
		return;
	}
	$tmp_fh->close();
	return 1;
}

sub _setDefaultRequestHeader {
	my $self = shift;
	my $req = shift;
	my $cookie = 'rdk_uid=' . $self->{_cookie_rdk_uid};

	if ($self->{_cookie_radiko_session}) {
		$cookie .= '; radiko_session=' . $self->{_cookie_radiko_session};
	}
	$req->header(
		'User-Agent' => 'Mozilla/5.0 like Gecko',
		'pragma' => 'no-cache',
		'Cookie' => $cookie,
		'Referer' => $swfUrl,

		'X-Radiko-App' => 'pc_ts',
		'X-Radiko-App-Version' => $appVersion,
		'X-Radiko-User' => 'test-stream',
		'X-Radiko-Device' => 'pc',
		'X-Requested-With' => 'ShockwaveFlash/23.0',		
	);
}

sub _auth1 {
	my ($self) = @_;

	my $req = HTTP::Request->new(
		'POST', 'https://radiko.jp/v2/api/auth1_fms'
	);
	$req->content("\r\n");

	$self->_setDefaultRequestHeader($req);

	my $ua = $clsLwpUserAgent->new();
	$ua->timeout(10);
	my $res = $ua->request($req);
	if (!$res->is_success()){
		$self->{error} = 'fail auth1: ' . $res->status_line();
		return;
	}
	#print $res->as_string;

	$self->{authToken} = $res->header("x-radiko-authtoken");
	$self->{_keyoffset} = int($res->header("x-radiko-keyoffset"));
	$self->{_keylength} = int($res->header("x-radiko-keylength"));
	return 1;
}

sub _partialkey {
	my ($self) = @_;

	my $fh = IO::File->new($self->{_keypath}, 'r');
	if (!$fh){
		$self->{error} = '_partialkey: keyfile open error.';
		return;
	}

	$fh->binmode();

	$fh->seek($self->{_keyoffset}, 0);
	my $buf;
	$fh->read($buf, $self->{_keylength});

	return MIME::Base64::encode_base64($buf, '');
}

sub _auth2 {
	my ($self) = @_;

	my $req = HTTP::Request->new(
		'POST', 'https://radiko.jp/v2/api/auth2_fms'
	);
	$req->content("\r\n");

	$self->_setDefaultRequestHeader($req);

	$req->header(
		'X-Radiko-Authtoken' =>  $self->{authToken},
		'X-Radiko-Partialkey' => $self->_partialkey(),
	);

	my $ua = $clsLwpUserAgent->new();
	$ua->timeout(10);
	my $res = $ua->request($req);
	if (!$res->is_success()){
		$self->{error} = 'fail auth2: ' . $res->status_line();
		return;
	}

	my $buf = $res->content(128);
	if ($buf !~ /(JP\d+)/){
		$self->{error} = 'fail auth2: bad area_id.';
		return;
	}

	$self->{areaId} = $1;
	return 1;
}

sub _storeCache {
	my ($self, $key, $expire) = @_;
	my $value = $self->{ $key };
	getCache()->set($self->{_cacheKeyPrefix} . $key, $value, $expire);
	return $value;
}

#
# 引数 force キャッシュを無視
# 戻り値 (areaId, authToken) エラー時()
#
sub connect {
	my ($self, $force) = @_;

	#Cacheされている
	if (!$force && (my $id = $self->areaId) && (my $tk = $self->authToken)){
		return ($id, $tk);
	}

	if (!$clsLwpUserAgent){
		$self->{error} = 'curl not installed.';
		return;
	}

	if (! -r $self->{_keypath}){
		$self->_getKeyFile();
	}
	if ($self->_auth1() && $self->_auth2()){
		return (
			# エリアIDは無期限
			$self->_storeCache(areaId => 'never'),	

			# 成功した場合、トークンを10分間Cacheする。
			$self->_storeCache(authToken => '10 min'),
		);
	}
	return;
}

sub _fromCache {
	my ($self, $key) = @_;
	return getCache()->get($self->{_cacheKeyPrefix} . $key);
}

sub authToken { shift->_fromCache('authToken'); }
sub areaId { shift->_fromCache('areaId'); }
sub error { shift->{error}; }

1;
