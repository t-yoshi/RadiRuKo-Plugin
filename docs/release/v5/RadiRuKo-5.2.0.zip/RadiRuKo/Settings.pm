
package Plugins::RadiRuKo::Settings;
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

use strict;
use base qw(Slim::Web::Settings);
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Plugins::RadiRuKo::RadiruHandler;
use Plugins::RadiRuKo::Utils;

my $log = logger('plugin.radiruko');
my $prefs = preferences('plugin.radiruko');

sub name {
	return Slim::Web::HTTP::CSRF->protectName('PLUGIN_RADIRUKO');
}

sub page {
	return Slim::Web::HTTP::CSRF->protectURI('plugins/RadiRuKo/settings/basic.html');
}

sub handler {
	my ($class, $client, $params) = @_;
	
	# When "apply" is pressed on the settings page, this function gets called.
	# So, double check that the apply button was pressed and if so check that the field was populated.
	# If so, set that value into the prefs variable
	# It's easiest if you use the same name for the HTML field and the prefs field.
	# In this case everything is called helloname and if you look at basic.html 
	# you'll see the field is called helloname.
	if ($params->{'saveSettings'}){ 
		$prefs->set('radiru_area', $params->{radiru_area});

		my $cookie_radiko_session = $params->{'cookie_radiko_session'};
        if ($cookie_radiko_session =~ /^([\da-f]{40}|)$/) {
    		$prefs->set('cookie_radiko_session', $cookie_radiko_session); 
		}

		if ($params->{radiruko_clear_cache}){
			Plugins::RadiRuKo::Utils::clearCache();
			$log->info('clearCache');
		}
		#$log->info('radiru_mode: ' . $params->{radiru_mode});
		#$log->info('radiruko_clear_cache: ' . $params->{radiruko_clear_cache});
	}

	# This puts the value on the webpage. 
	# If the page is just being displayed initially, then this puts the current value found in prefs on the page.
	$params->{'radiru_all_areas'} = [Plugins::RadiRuKo::RadiruHandler::config->areas];
	$params->{'prefs'}->{'radiru_area'} = $prefs->get('radiru_area') || 'tokyo';
	$params->{'prefs'}->{'cookie_radiko_session'} = $prefs->get('cookie_radiko_session');

	# I have no idea what this does, but it seems important and it's not plugin-specific.
	return $class->SUPER::handler($client, $params);
}

1;

__END__
