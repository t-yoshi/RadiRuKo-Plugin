# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

package Plugins::RadiRuKo::SimulradioMeta;

use strict;
use utf8;
use URI::Escape qw(uri_unescape);
use Slim::Formats::RemoteMetadata;
use Slim::Music::Info;
use Slim::Utils::Log;
use Slim::Utils::Strings;
use Data::Dumper;

my $log = logger('plugin.radiruko');
# 
# 
# http://www.simulradio.jp/asx/XXX.asx#simulradio=1;title=タイトル;icon=http://icon-url/;homepage=http://station-homepage/;
#   
#   
#
sub _parseUrl {
	my ($url, $fields) = @_;

	my ($scheme, $authority, $path, $query, $fragment) =
				$url =~ m|(?:([^:/?#]+):)?(?://([^/?#]*))?([^?#]*)(?:\?([^#]*))?(?:#(.*))?|;

	foreach (split(/[&;]/, $fragment)) {
		my ($key, $value) = split('=', $_, 2);
		$fields->{$key} = uri_unescape($value);
	}
}


sub _updateFromURLfragment {
	my ($url, $meta) = @_;

	my $fields = {}; 
	_parseUrl($url, $fields);
	#$log->info(Dumper($fields));

	if (!$fields->{title} || $fields->{icon} !~ m{^http://}){
		return;
	}
	utf8::decode($fields->{title});

	$meta->{title} = $fields->{title};
	$meta->{_url} =~ /^(.*)#simulradio=.*?$/;
	#$meta->{artist} = $1;
	
	$meta->{album} = $fields->{homepage};
	$meta->{cover} = $fields->{icon};
	$meta->{type} = Slim::Utils::Strings::string('PLUGIN_RADIRUKO_SIMULRADIO');
}

sub _provider {
	my ($client, $url) = @_;
	my $meta = {
		title => Slim::Music::Info::getCurrentTitle($url),
		icon  => 'html/images/radio.png',
		type  => Slim::Utils::Strings::string('RADIO'),
	};
	_updateFromURLfragment($url, $meta);
	return $meta; 
}

sub registerMetaProvider {
	Slim::Formats::RemoteMetadata->registerProvider(
		match => qr/#simulradio=1/,
		func  => \&_provider,
	);
}

1;


