# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::CurlUserAgent;
#
# PerlにSSL関連のモジュールがインストールされていない場合は、
# LWP::UserAgentの代わりにcurlコマンド経由とする。
#
# https://radiko.jp/ への接続に必要。
#
use strict;
use HTTP::Request;
use HTTP::Response;
use HTTP::Headers;
use IO::File;
use IPC::Open2;
#use Data::Dumper;
use Slim::Utils::Misc;

my $log = Slim::Utils::Log::logger("plugin.radiruko");

my $curl;

sub init {
	$curl = Slim::Utils::Misc::findbin('curl_bin') ||
			Slim::Utils::Misc::findbin('curl') ||
			return;

	my $fh;
	if (open($fh, '-|', $curl, '-V')){ 
		my $buf;
		read($fh, $buf, 1024);
		return 1 if ($buf =~ /^Protocols:.*\bhttps\b/mi);
	}
	$log->error('[curl] https not supported.'); 
	return;
}


sub new {
	my ($class, %cnf) = @_;

	my $err;
	if (!defined $curl) { 
		$err = 'not initialized.'; 
	}
	if (%cnf) { 
		$err = 'refuse parameters.';
	}
	if ($err){
		$log->error($err);
		return undef;
	}
	return bless({
		_timeout => 180,
	}, $class);
}

sub timeout {
	my ($self, $secs) = @_;
	$self->{_timeout} = $secs if ($secs > 0);
	return $self->{_timeout};
}

sub _requestToCurlCommand {
	my ($self, $request) = @_;

	my @cmds = (
		$curl, '-s',
		#'-X', $request->method(),
		'--connect-timeout', $self->timeout, 
		#LinuxバイナリをFreeBSDで動かすには --no-keepaliveが必要。
		'--no-keepalive',
		#レスポンスヘッダーをstdoutに出力する
		'-D', '-',
	);
	
	#環境によってはCA証明書エラーが起き得る。
	push @cmds, '-k' if $request->uri() =~ /^https:/;

	#POSTデータをstdinから読み込む
	push @cmds, '--data-binary', '@-' if $request->method() eq 'POST';
	
	for my $name ($request->header_field_names()){
		for my $val ($request->header($name)){
			push @cmds, '-H', "$name: $val";
		}
	}
	
	push @cmds, '--url', $request->uri();
	
	return @cmds;
}

sub request {
	my ($self, $request) = @_;
	
	my @cmds = $self->_requestToCurlCommand($request);
	
	$log->debug(
		'open2: ' . Plugins::RadiRuKo::Utils::escapeCommands(@cmds)
	) if $log->is_debug;

	my ($rfd, $wfd);
	unless (open2($rfd, $wfd, @cmds)){
		return HTTP::Response->new(501, "curl execute error: [@cmds]");
	}

	if ($request->method() eq 'POST'){
		print($wfd, $request->content());
	}
	close($wfd);

	my $buf;
	read($rfd, $buf, 256*1024);
	
	close($rfd);
	return HTTP::Response->parse($buf);
}


1;

