# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruHandler;
#
# RADIRU URL protocol handler
#
#  radiru://Station[-Area][-Type]
#
#  Station:
#    R1, R2, FM
#  Area:
#    Sendai, Tokyo, Nagoya, Osaka
#  Type:
#    RTMPE, HLS
#
#  See: http://www3.nhk.or.jp/netradio/app/config_pc.xml
#
use strict;

use Slim::Utils::Misc;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Timers;

my $log = logger('plugin.radiruko');
my $prefs = preferences('plugin.radiruko');

use base q(Plugins::RadiRuKo::FFMpegHandler);

#{
#	tokyo=> {
#		areajp=>'東京', apikey=>'001', areakey=>'130',
#		nowonair=>'http://api.nhk.or.jp/r2/pg/now/4/130/netradio.json',
#		stream_url=> {
#			r1=>'rtmp://...', r1hls=>'http://',
#			r2=>'rtmp://...', r2hls=>'http://',
#			fm=>'rtmp://...', fmhls=>'http://',
#		}
#	},
#	osaka=>{...
{
	package Config;

	use Plugins::RadiRuKo::Utils qw(fetchXml);
	use List::Util qw(first);
	use Tie::IxHash;
	use Data::Dumper;

	sub new {
		tie my %hash, 'Tie::IxHash';
		return bless \%hash;
	}

	my $configUrl = 'http://www3.nhk.or.jp/netradio/app/config_pc_2016.xml';

	sub fetch {
		my ($self, $callback) = @_;
		fetchXml($configUrl, sub {
				my ($xml, $args) = @_;

				$self->_onParseConfigXml($xml)
					unless ($xml->{_failed} || ($xml->{_isCache} && $self->areas));

				$callback->($self) if ($callback);
		}, cacheExpire=>'30 days');
		return;
	}

	sub _onParseConfigXml {
		my ($self, $xml) = @_;

		my @datas = @{ $xml->{stream_url}{data} or [] };

		my @areas = map { $_->{area}{content} } @datas;

		foreach my $area (@areas){
			my $data = first {
				$_->{area}{content} eq $area
			} @datas;
			my $prop = $self->{$area} = {};

			foreach my $k (qw(area areajp apikey areakey)){
				$prop->{$k} = $data->{$k}{content};
			}

			my $noa = $xml->{url_program_noa}{content};
			my $areakey = $prop->{areakey};
			$noa =~ s/\{area\}/$areakey/;
			$prop->{nowonair} = $noa;

			my $stream_url = $prop->{stream_url} = {};
			foreach my $ch (qw(r1 r2 fm r1hls r2hls fmhls)){
				$stream_url->{$ch} = $data->{$ch}{content};
			}
		}

		$log->debug(Dumper($self)) if $log->is_debug;
	}

	#
	# ex ('tokyo', 'osaka', ..)
	#
	sub areas {
		return keys %{ +shift };
	}

	sub get {
		my $self = shift;
		my $area = lc(shift);
		return $self->{$area} || {};
	}
}


my $config = Config->new();

sub init {
	# register protocol handler
	$log->info("Register protocol: radiru");
	Slim::Player::ProtocolHandlers->registerHandler("radiru",  __PACKAGE__);

	Slim::Utils::Timers::setTimer(undef, time() + 1, sub { $config->fetch() });
}

sub config () {
	return $config;
}

# new is called by openRemoteStream() for URLs with "radiru:" protocol prefix
sub new {
	my $class = shift;
	my $args  = shift;
	#my $client = $args->{client};
	my $song = $args->{song};
	my $stream_url = $song->pluginData('stream_url') || return;

	$args->{_radiruko_command_substitute} = {
		RTMP_SWFVERIFY => ['-rtmp_swfverify', 'http://www3.nhk.or.jp/netradio/files/swf/rtmpe.swf'],
	} if ($stream_url =~ /^rtmpe:/);
	
	$args->{url} = $stream_url;

	return $class->SUPER::new($args);
}

# radiru://R1-Tokyo-HLS  -> ('R1', 'Tokyo', 'HLS')
sub parseRadiruUrl {
	my $u = shift;
	my ($c, $a, $t) = $u =~ m{(R1|R2|FM)(?:-([A-Z][a-z]+))?(?:-(RTMPE|HLS))?$} or return;
	$a ||= 'Tokyo';
	$t ||= $prefs->get('radiru_mode') || '';
	return ($c, $a, ($t !~ /rtmpe/i) ? 'HLS' : 'RTMPE');
}

sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $client = $song->master();
	my $url = $song->track()->url;

	my ($channel, $area, $type) = parseRadiruUrl($url) or do {
		my $error .= 'Invalid URL';
		$log->error("$error: $url");
		return $errorCb->($error);
	};

	$type = '' if ($type eq 'RTMPE');

	$config->fetch(sub {
		my $u = $config->{ lc($area) }{stream_url}{ lc($channel . $type) };
		if ($u){
			$song->pluginData({stream_url=>$u});
			$successCb->();
		} else {
			my $error = 'Missing stream_url';
			$log->error("$error: $url");
			$errorCb->($error);
		}
	});
}

1;

__END__
my %radiruUrls = (
	Sendai => {
		R1 => 'rtmpe://netradio-hkr1-flash.nhk.jp/live/NetRadio_HKR1_flash@108442',
		R2 => 'rtmpe://netradio-r2-flash.nhk.jp/live/NetRadio_R2_flash@63342',
		FM => 'rtmpe://netradio-hkfm-flash.nhk.jp/live/NetRadio_HKFM_flash@108237',
	},
	Tokyo => {
		R1 => 'rtmpe://netradio-r1-flash.nhk.jp/live/NetRadio_R1_flash@63346',
		R2 => 'rtmpe://netradio-r2-flash.nhk.jp/live/NetRadio_R2_flash@63342',
		FM => 'rtmpe://netradio-fm-flash.nhk.jp/live/NetRadio_FM_flash@63343',
	},
	Nagoya => {
		R1 => 'rtmpe://netradio-ckr1-flash.nhk.jp/live/NetRadio_CKR1_flash@108234',
		R2 => 'rtmpe://netradio-r2-flash.nhk.jp/live/NetRadio_R2_flash@63342',
		FM => 'rtmpe://netradio-ckfm-flash.nhk.jp/live/NetRadio_CKFM_flash@108235',
	},
	Osaka => {
		R1 => 'rtmpe://netradio-bkr1-flash.nhk.jp/live/NetRadio_BKR1_flash@108232',
		R2 => 'rtmpe://netradio-r2-flash.nhk.jp/live/NetRadio_R2_flash@63342',
		FM => 'rtmpe://netradio-bkfm-flash.nhk.jp/live/NetRadio_BKFM_flash@108233',
	}
);

