# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::Utils;

use strict;

use XML::Simple;
use JSON::XS::VersionOneAndTwo;

use Slim::Utils::Log;
use Slim::Utils::Cache;
use Slim::Utils::Strings;
use Slim::Utils::Timers;
use Slim::Utils::Versions;
use Slim::Control::Request;
use Slim::Networking::SimpleAsyncHTTP;
use Date::Parse;
use Time::Zone;
use Time::Local;
use POSIX qw(strftime);

use Exporter 'import';
our @EXPORT_OK = qw(
	fetchXml fetchJson getCache radikoId stripTag jptime 
	notifyNewMeta notifyNewMetaAt 
	abbreviate stripTagAndAbbreviate
	refSize parseDateTime 
	feedCompat 
);

#use Data::Dumper;

my $log = Slim::Utils::Log::logger("plugin.radiruko");
my $cache = Slim::Utils::Cache->new('cache.radiruko');

sub getCache () {
	return $cache;
}

#読込中のurl
my %_fetchLoading; 

sub _failedResult {
	return +{ 
		_url    => shift,
		_failed => shift,
	};
}

sub _onContentParsed {
	#$hash: hash or string(エラー時) 
	my ($hash, $retCallback, $url, $args) = @_;
	
	#parse error
	if (ref($hash) ne 'HASH'){ 
		$log->error("$url: $hash");
		$hash = _failedResult($url, $hash);
	} elsif (! scalar keys %$hash) {
		$hash = _failedResult($url, 'empty hash');
		$log->error('empty hash: ' . $url);
	}

	$hash->{_url} = $url;
	$hash->{_fetchTime} = time();
	$hash->{_isCache} = 0;

	$retCallback->($hash, $args) if ($retCallback);

	my $expire = $hash->{_failed} ? $args->{errorCacheExpire} : $args->{cacheExpire};
	$log->debug("$url cacheExpire='$expire'") if $log->is_debug;
	$cache->set('radiruko:' . $url, $hash, $expire); 
	
	delete $_fetchLoading{$url};
};

sub _fetchUrl {
	my $parseCallback = shift; # string to hash
	my $url = shift;
	# ->(hash)
	my $callback = (ref($_[0]) eq 'CODE') ? shift : undef; 

	$log->error("invalid args: @_") if (scalar(@_) % 2);

	my $args = {
		#SimpleAsyncHTTP args
		timeout => 10,
		cache   =>  1,

		#hashのキャッシュ保存期間
		cacheExpire => '60 min',
		#パースエラー時の保存期間 (エラーなのに何回も接続しにいくのを防ぐ)
		errorCacheExpire => '90 sec',
		@_
	};

	my $hash = $cache->get('radiruko:' . $url);
	if ($hash){
		$hash->{_isCache} = 1;
		$log->debug("cache -> $url") if $log->is_debug;
		$callback->($hash, $args) if $callback; 
		return $hash;
	}

	goto now_loading if ($_fetchLoading{$url});

	$_fetchLoading{$url} = 1;
	my $client = Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my $http = shift;
			my $hash = eval {
				$parseCallback->($http->content);
			} or $@ or 'parse error';
			_onContentParsed(
				$hash, $callback, $url, $args
			);
		}, 
		sub {
			my ($http, $err) = @_;
			_onContentParsed(
				$err, $callback, $url, +{}
			);
		}, 
		$args
	)->get($url, 'User-Agent'=>'Mozilla/5.0 like Gecko');

now_loading:
	#未取得
	return _failedResult($url, "url='$url' is not yet loaded"); 
}

#
# 非同期でXML|JSONを取得しキャッシュする。
#
# 引数:
#	url, callback, args(SimpleAsyncHTTPの引数、キャッシュ設定)
# 戻り値:
#   ハッシュ化したxml|json
# 追加キー:
#  _url: URL
#  _fetchTime: 取得したエポック時間
#  _isCache: キャッシュを返すとき
#  _failed: 取得エラー時
#
# ex:
#	*同期処理ではキャッシュ済みがあれば得る
#	my $cached = fetchXml('http://abc/d.xml', timeout=>15, cacheExpire=>'10 min') 
#
#	fetchXml('http://abc/d.xml', sub {
#		my ($hash, $args) = @_;
#		return if ($hash->{_failed});
#		...
#		$args->{cacheExpire} = '1 day'; #キャッシュ保存設定を上書き
#	}) 
#
sub fetchXml {
	return _fetchUrl(sub {
		XMLin(shift, ForceArray=>0, ForceContent=>1, KeyAttr=>[]);
	}, @_);
}

sub fetchJson {
	return _fetchUrl(\&from_json, @_);
}

sub radikoId {
	my $url = shift;
	return $1 if $url =~ m{^radikop?://([A-Z\d]+[\-_]?[A-Z\d]+)$};
	return $1 if $url =~ m{#radikop?=([A-Z\d]+[\-_]?[A-Z\d]+)$};
	return;
}

sub jptime {
	my $t = shift || time();
	return gmtime($t + tz_offset('JST'));
}

#
# 日時の文字列をエポック秒に変換する
#   ex. '2004-04-01T12:00+09:00' -> 1080788400
#
sub parseDateTime {
	my $dateTime = shift;

	#radiko形式 '20160910151500' -> '20160910T151500'
	$dateTime =~ s/^(20\d{6})(\d{4,}.*)$/$1T$2/;

	my @tm = strptime($dateTime, 'JST');
	return timegm(@tm) - $tm[6] if scalar @tm;	 
}

# メタの変更を通知する。
sub notifyNewMeta {
	my $client = shift;
	Slim::Control::Request::notifyFromArray($client, ['newmetadata']);
}

#
# 指定時刻にメタの変更を通知する。
#　(複数の引数があるときは現在時刻に近い方)
#
# ex. notifyNewMetaAt($client, '2016-09-01T12:00+09:00', '2016-09-01 12:03 JST', ...)
#
sub notifyNewMetaAt {
	my $client = shift;
	# epoch|string  -> epoch
	my @times = sort map {
		/^20\d+/ ? parseDateTime($_) : $_;
	} @_; 

	my $now = time();

	#過去 or 10分以上先なら無視
	my ($t) = grep { 
		$_ > $now and ($_ - $now) <= 600
	} @times or return;

	my $tdiff = $t - $now;
	$log->debug(strftime('set: %F %T', localtime $t) . " after=${tdiff}secs") if $log->is_debug;

	#前回の指定をキャンセル
	Slim::Utils::Timers::killTimers($client, \&notifyNewMeta);
	Slim::Utils::Timers::setTimer($client, $t, \&notifyNewMeta);
	return 1;
}

#
# 文字列を後略する。
#
sub abbreviate {
	my $str = shift or return '';
	my $maxWidth = shift || 200; #半角換算の文字幅

	my $maxLength = 0;
	foreach (split //, $str){
		--$maxWidth if /[^\p{InBasicLatin}]/;
		last if $maxWidth-- <= 0;
		$maxLength++;
	}
	return $str if $maxWidth > 0;
	
	$str = substr($str, 0, $maxLength);
	$str =~ s/\s+$//;
	return  $str . '...';
}

#
# HTMLタグを除去する。
#
sub stripTag {
	my $s = shift or return '';

	$s =~ s/<.*?>/ /g;
	$s =~ s/\s+/ /g;
	return $s;
}

sub stripTagAndAbbreviate {
	my $s = shift or return '';
	my $maxWidth = shift;
	return abbreviate(stripTag($s), $maxWidth);
}

#
# リストまたはハッシュリファレンスの要素数を返す。
#
sub refSize {
	my $r = shift;
	my $t = ref($r);
	return 0 unless defined $r;
	return scalar keys(%{$r}) if $t eq 'HASH';
	return scalar @{$r} if $t eq 'ARRAY';
	$log->error('invalid type: ' . $t);
	return 0;
}


my %_feedCompatCache;
#
# Plugin->feedの後方互換性
#  (7.5: feed=CODE時の実装が完全ではない)
#
sub feedCompat {
	my ($clsPlugin, $client, $feed) = @_;

	return $feed if ($main::VERSION !~ /^7\.5/ || ref($feed) ne 'CODE');
	
	#7.5 && feed is CODE
	#Slim::Utils::Timers::setTimer($client, time(), sub {
		$feed->($client, sub {
			$_feedCompatCache{$clsPlugin} = shift;
		}, +{});
	#});

	return $_feedCompatCache{$clsPlugin} || {
		title => 'Please reload',
		items => [],
	};
}

#基本プラグインのバージョンをチェックする。
sub checkBasicVersion {
	my $minVer = shift;
	require Plugins::RadiRuKo::Plugin;
	my $basicVersion = Plugins::RadiRuKo::Plugin->_pluginDataFor('version');
	#$log->debug("basic=$basicVersion, min=$minVer");
	return Slim::Utils::Versions->checkVersion($basicVersion, $minVer, '100101');
}

#コマンド引数をエスケープする
sub escapeCommands {
	my $escape = sub {
		s/([\$\"\`])/\\$1/g; 
		return /^[\w\+\-\/\.]+$/ ? $_ : "\"$_\"";	
	};
	@_ = map { $escape->() } @_;
	return wantarray ? @_ : join(' ', @_);
}

sub clearCache () {
	$cache->clear();
}

1;
