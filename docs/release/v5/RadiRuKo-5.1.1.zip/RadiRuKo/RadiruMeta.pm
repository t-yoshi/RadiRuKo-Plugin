# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruMeta;

use strict;
use utf8;
use POSIX;
use List::Util qw(first);
use Slim::Utils::Log;
use Slim::Utils::Strings;
use Slim::Utils::Prefs;
use Plugins::RadiRuKo::Utils qw(jptime abbreviate fetchJson notifyNewMetaAt parseDateTime);

use Plugins::RadiRuKo::RadiruHandler;

my $log = Slim::Utils::Log::logger("plugin.radiruko");
my $prefs = preferences('plugin.radiruko');


# URL:
#  radiru://Station[-Area][-Type]
#
#  Station:
#    R1, R2, FM
#  Area:
#    Sendai, Tokyo, Nagoya, Osaka
#  Type:
#    RTMPE, HLS
#

sub _updateFromJson {
	my ($client, $jsUrl, $meta) = @_;
	
	# http://api.nhk.or.jp/r2/pg/now/4/130/netradio.json
	my $js = fetchJson($jsUrl, cacheExpire=>'5 min');
	return if $js->{_failed};

	my $ch = {R1=>'n1',R2=>'n2',FM=>'n3'}->{ $meta->{_channel} };
    my @programs = values %{$js->{nowonair_list}->{ $ch }};

	my $now = time();
	#放送中
	my $prog = first {
		$now >= parseDateTime($_->{start_time}) && parseDateTime($_->{end_time}) > $now 
	} @programs or return;

	my $logo = $prog->{images}{logo_l}{url} || $prog->{images}{thumbnail_m}{url};

	$meta->{title} .= ' ' . $prog->{title};
	$meta->{artist} = $prog->{act} || $prog->{subtitle} || $meta->{artist};
	$meta->{album} = abbreviate($prog->{content}) || $meta->{album};
	$meta->{cover} = $logo || $meta->{cover};

	#次の番組開始時間にメタ更新を通知する
	my $following = $js->{nowonair_list}{ $ch }{following};
	notifyNewMetaAt($client, $following->{start_time}, $following->{end_time});
} 

sub _metaProvider {
	my ($client, $url) = @_;
	
	my ($channel, $area, $type) = 
			Plugins::RadiRuKo::RadiruHandler::parseRadiruUrl($url) or return {};

	my $icon = "plugins/RadiRuKo/html/images/NHK_${channel}.png";
	my $chName = Slim::Utils::Strings::string("PLUGIN_RADIRUKO_NHK_${channel}");
	my $props = Plugins::RadiRuKo::RadiruHandler::config->get($area);
	$chName .= $props->{areajp} or ' ' . ucfirst($area);

	my $meta = {
		title    => $chName,
		artist   => ' ',
		album    => ' ',
		type     => "(Radiru/$type)",
		bitrate  => '48kbps', 
		cover    => $icon,
		icon     => $icon,

		_channel => $channel, #R1|R2|FM
	};	
	
	my $jsUrl = $props->{nowonair};
	if ($jsUrl =~ /http:.*nhk/ && ($client->isPlaying() || $client->isPaused())) {
		_updateFromJson($client, $jsUrl, $meta);
	}	
	return $meta;
}

sub registerMetaProvider {
	Slim::Formats::RemoteMetadata->registerProvider(
		match => qr{radiru(://|=)(R1|R2|FM)},  
		func  => \&_metaProvider,
	);
}

1;
