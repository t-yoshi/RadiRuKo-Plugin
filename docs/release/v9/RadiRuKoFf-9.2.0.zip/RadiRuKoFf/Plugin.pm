# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKoFf::Plugin;

use v5.20;
use warnings;
use base qw(Slim::Plugin::Base);
use Slim::Utils::Log;

sub getDisplayName {'PLUGIN_RADIRUKO_FF_NAME'}

sub initPlugin {
	my $class = shift;
	my $log   = logger('plugin.radiruko');

	$log->info('RadiRuKo-FFmpeg-Plugin v', $class->_pluginDataFor('version'));

	$class->SUPER::initPlugin();
}

1;
