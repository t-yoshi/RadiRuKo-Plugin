# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKoFf::Plugin;

use v5.20;
use warnings;
use Slim::Music::Info;
use Slim::Utils::Log;
use Slim::Utils::Misc;
use Slim::Utils::OSDetect;
use Slim::Utils::Prefs;

use base qw(Slim::Plugin::Base);

use Plugins::RadiRuKo::Utils 9.1;

sub getDisplayName {'PLUGIN_RADIRUKO_FF_NAME'}

sub initPlugin {
	my $class = shift;
	my $log   = logger('plugin.radiruko');

	$log->info('RadiRuKo-FFmpeg-Plugin v' . $class->_pluginDataFor('version'));

	$class->SUPER::initPlugin();
}

1;
