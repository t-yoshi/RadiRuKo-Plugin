# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoTf::ProtocolHandler;
use v5.20;
use warnings;
use utf8;
use base q(Plugins::RadiRuKo::BaseFFSeekableHandler);
use Carp::Assert;
use POSIX qw(strftime fmod);
use Slim::Utils::Log;
use Promises2 qw(collect);
use Plugins::RadiRuKo::RadikoAuth;
use Plugins::RadiRuKo::RadikoFeed;
use Plugins::RadiRuKoTf::Feed;
use Plugins::RadiRuKo::Utils qw(
  parseDateTime RE_RADIKO_TF_URL isEnabledAreaFree jptime
);

my $log = logger('plugin.radiruko');

sub new {
	my $class  = shift;
	my $args   = shift;
	my $client = $args->{client};
	my $song   = $args->{song};

	# pluginDataはシーク時に再利用される
	my $m3u8 = $song->pluginData('radikoPlaylist');
	my $opt  = $song->pluginData('ffOptions');

	return $class->SUPER::new($args, $m3u8->clone, @$opt);
}

sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $url = $song->track()->url;

	my ($stId, $ft, $to) = $url =~ RE_RADIKO_TF_URL
	  or return $errorCb->("Invalid URL: $url");

	my $ts_ft = parseDateTime($ft);
	my $ts_to = parseDateTime($to);

	$song->duration($ts_to - $ts_ft);

	my $isAreaFree = isEnabledAreaFree();

	collect(
		Plugins::RadiRuKo::RadikoAuth->execute(url => $url),
		Plugins::RadiRuKo::RadikoFeed::loadPlaylist($stId, $isAreaFree, 1),
	)->then(
		sub {
			my ($token, $area) = @{ $_[0] };
			my ($m3u8) = @{ $_[1] };
			$log->debug("Authtoken=$token, AreaId=$area, Playlist=$m3u8") if $log->is_debug;

			$m3u8->query_param(start_at => $ft);
			$m3u8->query_param(ft       => $ft);
			$m3u8->query_param(end_at   => $to);
			$m3u8->query_param(to       => $to);

			$song->pluginData(
				ffOptions => [
					-headers => "X-Radiko-AuthToken: $token\cM\cJ",
				]
			);
			$song->pluginData(radikoPlaylist => $m3u8);
			$song->pluginData(ts_ft          => $ts_ft);
		}
	)->done($successCb, $errorCb);
}

sub add_seek_option {
	my ($class, $song, $ffurl, $offset, $r_ffoptions) = @_;

	assert($ffurl->isa('URI'));

	my $ts_ft = $song->pluginData('ts_ft');
	assert($ts_ft > 0);

	#5秒単位のセグメントだから切り詰め、残りをffmpeg +ss Nとする
	my $ss      = fmod($ts_ft + $offset, 5);
	my $ts_seek = $ts_ft + $offset - $ss;

	my $seek = strftime('%Y%m%d%H%M%S', jptime($ts_seek));

	$ffurl->query_param(seek    => $seek);
	$ffurl->query_param(preroll => 0);

	$class->SUPER::add_seek_option($song, $ffurl, $ss, $r_ffoptions);
}

sub getFormatForURL {'aac'}

1;
