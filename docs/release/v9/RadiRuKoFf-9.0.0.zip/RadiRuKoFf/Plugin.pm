# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKoFf::Plugin;

use strict;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::OSDetect;
use Slim::Music::Info;
use Slim::Utils::Misc;

use base qw(Slim::Plugin::Base);

use Plugins::RadiRuKo::Utils 9.0;

sub getDisplayName {'PLUGIN_RADIRUKO_FF_NAME'}

sub initPlugin {
    my $class = shift;
    my $log   = logger('plugin.radiruko');

    $log->info('RadiRuKo-FFmpeg-Plugin v' . $class->_pluginDataFor('version'));

    #FreeBSD | NetBSD
    my $osDetails = Slim::Utils::OSDetect::details();
    if ($osDetails->{osArch} =~ /(amd64|x86_64)-(FreeBSD|NetBSD)/i) {
        $class->_tryAddLinuxBinPath();
    }

    $class->SUPER::initPlugin();
}

sub _tryAddLinuxBinPath($) {
    my $class   = shift;
    my $baseDir = $class->_pluginDataFor('basedir');
    my $binDir  = "$baseDir/Bin/x86_64-linux";
    my $cmd     = sprintf '"%s/ffmpeg_bin" -version >/dev/null 2>&1', $binDir;
    if (system $cmd == 0) {
        Slim::Utils::Misc::addFindBinPaths($binDir);
    }
}

1;
