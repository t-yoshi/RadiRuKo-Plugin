# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoRo::Feed;
use utf8;
use strict;
use URI::Escape qw(uri_escape_utf8);
use Slim::Utils::Log;
use Plugins::RadiRuKo::Utils qw(
    AsyncHttp prettyTitle strWidth trimWidth
    parseDateTime feedFromPromise
);
use Tie::Cache::LRU;
use Data::Dumper;
use Promises::Tiny qw(resolved);

my $log = logger('plugin.radiruko');

sub _audioUrl ($@) {
    my $u = shift;
    my $f;
    while (my ($k, $v) = splice(@_, 0, 2)) {
        $f .= sprintf('%s=%s;', $k, uri_escape_utf8($v)) if $v =~ /\S/;
    }
    return "$u#$f?--";
}

sub _seriesItems {
    my ($client, $args, $site_id, $corner_site_id) = @_;
    my $jsUrl = "https://www.nhk.or.jp/radio-api/app/v1/web/ondemand/series?site_id=$site_id";

    if (defined $corner_site_id and $corner_site_id ne '') {
        $jsUrl .= "&corner_site_id=$corner_site_id";
    }

    $log->debug("[$jsUrl]");
    my $now = time();

    return AsyncHttp()->get($jsUrl)->then(
        sub {
            my $json   = shift;
            my $client = shift;

            my $progName = prettyTitle($json->{title} . ' ' . $json->{corner_name});
            my $icon     = $json->{thumbnail_url} ||
                'html/images/radio.png';

            my @items;

            for (@{ $json->{corners} or [] }) {
                my $line1 = prettyTitle($_->{title} . ' ' . $_->{corner_name});
                my $line2 = prettyTitle($_->{onair_date} . ' ' . $_->{corner_name});
                my $title = sprintf('%s [%s]', $line1, $_->{onair_date});

                my $item = {
                    title       => $title,
                    line1       => $line1,
                    line2       => $line2,
                    icon        => $icon,
                    url         => feedFromPromise(\&_seriesItems),
                    passthrough => [ $_->{series_site_id}, $_->{corner_site_id} ],
                };
                push @items, $item;
            }

            for (@{ $json->{episodes} or [] }) {
                my $u = $_->{stream_url};
                next unless $u;

                $u =~ s/^https:/radiruod:/;
                my $duration = '';

                #2024-06-03T21:30:00+09:00_2024-06-03T21:45:00+09:00
                if ($_->{aa_contents_id} =~ /^.+;(20.+?)_(20.+?)$/) {
                    $duration = parseDateTime($2) - parseDateTime($1);
                }

                my $line1 = prettyTitle($_->{program_title} . ' ' . $_->{series_description});
                my $line2 = prettyTitle($_->{onair_date} . ' ' . $_->{program_sub_title});
                my $title = sprintf('%s [%s]', $line1, $_->{onair_date});
                my $item  = {
                    title => $title,
                    line1 => $line1,
                    line2 => $line2,
                    icon  => $icon,
                    url   => _audioUrl(
                        $u,
                        duration => $duration,
                        title    => $line1,
                        icon     => $icon,
                        album    => $progName || $_->{series_url} || $_->{share_text_url},
                        artist   => prettyTitle($_->{program_sub_title}),
                    ),
                    type => 'audio',
                };
                push @items, $item;
            }
            return \@items;
        }
    );
}

#未放送か
sub _isUnaired {
    my $now = time();

    #2024年4月1日 -> 2024-04-01T00:00+09:00
    my ($y, $m, $d) = $_[0] =~ /(20\d\d)年(0?[1-9]|1[012])月(0?[1-9]|[12]\d|3[01])日/ or do {
        $log->warn('E: ' . $_[0]);
        return 0;
    };
    my $t = sprintf(
        '%d-%02d-%02dT00:00+09:00',
        $y, $m, $d
    );
    $log->debug("$_[0] -> $t");
    return parseDateTime($t) > $now;
}

sub _cbGenreOrSearch {
    my $json   = shift;
    my $client = shift;
    my @airedItems;
    my @unairedItems;

    for (@{ $json->{series} or [] }) {
        my $line1 = prettyTitle($_->{title} . ' ' . $_->{corner_name});
        my $line2 = $_->{onair_date} || '';
        my $title = $line2 ? "$line1 [$line2]" : $line1;

        my $item = {
            title       => $title,
            line1       => $line1,
            line2       => $line2,
            icon        => $_->{thumbnail_url} || 'html/images/radio.png',
            url         => feedFromPromise(\&_seriesItems),
            passthrough => [ $_->{series_site_id}, $_->{corner_site_id} ],
        };

        if (_isUnaired($_->{onair_date})) {
            $item->{line1} = '*' . $item->{line1};
            $item->{title} = '*' . $item->{title};
            push @unairedItems, $item;
        } else {
            push @airedItems, $item;
        }
    }
    return [ @airedItems, @unairedItems ];
}

sub _genreItems {
    my ($client, $args, $genre) = @_;
    my $jsUrl = "https://www.nhk.or.jp/radio-api/app/v1/web/ondemand/series?genre=$genre";
    $log->debug("[$jsUrl]");
    return AsyncHttp()->get($jsUrl)->then(\&_cbGenreOrSearch);
}

sub _searchItems {
    my ($client, $args) = @_;

    my $jsUrl = 'https://www.nhk.or.jp/radio-api/app/v1/web/ondemand/series/search';
    $jsUrl .= '?keyword=' . uri_escape_utf8($args->{search});

    $log->debug("[$jsUrl]");
    return AsyncHttp()->get($jsUrl)->then(\&_cbGenreOrSearch);
}

tie my %sessionCache, 'Tie::Cache::LRU', 10;

sub feedPromise() {
    my ($client, $args, @passthrough) = @_;

    #らじるのメニューは頻繁に更新されるので
    # メニューをたどっているときに更新されると
    # ナビゲーションがおかしくなる
    my $item_id = $args->{params}{item_id} || $args->{params}{index};
    my ($cacheKey) = $item_id =~ /^(\w+)\./;
    if ($cacheKey && $sessionCache{_}) {
        $log->debug("Using cached items for [$cacheKey]");
        $sessionCache{$cacheKey} ||= $sessionCache{_};
        return resolved($sessionCache{$cacheKey});
    }

    my $u = 'https://www.nhk.or.jp/radio-api/app/v1/web/ondemand/series/genres';
    return AsyncHttp()->get($u)->then(
        sub {
            my $json = shift;
            my @items;

            for (@{ $json->{genres} }) {
                my $item = {
                    title       => $_->{name},
                    icon        => 'html/images/radio.png',
                    url         => feedFromPromise(\&_genreItems),
                    passthrough => [ $_->{genre} ],
                };
                push @items, $item;
            }

            push @items, +{
                title       => Slim::Utils::Strings::string('SEARCHFOR'),
                icon        => 'html/images/search.png',
                type        => 'search',
                url         => feedFromPromise(\&_searchItems),
                passthrough => [],
            };

            if (0) {
                #テスト用
                use List::Util;
                @items = List::Util::shuffle @items;
            }

            $sessionCache{_} = \@items;
            return \@items;
        },
    );

}

1;
