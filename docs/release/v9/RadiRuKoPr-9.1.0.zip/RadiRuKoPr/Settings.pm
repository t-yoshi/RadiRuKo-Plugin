# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoPr::Settings;

use v5.20;
use warnings;
use base qw(Slim::Web::Settings);
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Plugins::RadiRuKoPr::RadikoLogin;
use Data::Dumper;

my $log       = logger('plugin.radiruko');
my $app_prefs = preferences('plugin.radiruko');

sub name {
	return Slim::Web::HTTP::CSRF->protectName('PLUGIN_RADIRUKO_PREMIUM');
}

sub page {
	return Slim::Web::HTTP::CSRF->protectURI('plugins/RadiRuKoPr/settings/basic.html');
}

sub handler {
	my ($class, $client, $params, $callback, @args) = @_;

	my $doCallback = sub {
		#$log->debug('result=' . $_[0]);
		$params->{cookie_radiko_session} = $_[0] // '(none)';
		$params->{radiko_logged_in}      = $_[0] =~ /^[a-f\d]{40}$/;
		$params->{radiko_password}       = '';
		my $body = $class->SUPER::handler($client, $params);
		$callback->($client, $params, $body, @args);
	};

	if ($params->{radiko_logout}) {
		Plugins::RadiRuKoPr::RadikoLogin->logout()->done($doCallback, $doCallback);
		return;
	}

	if ($params->{saveSettings}) {
		$log->debug('saveSettings');

		Plugins::RadiRuKoPr::RadikoLogin->login(
			$params->{radiko_mail},
			$params->{radiko_password}
		)->done($doCallback, $doCallback);
	} else {
		$doCallback->(Plugins::RadiRuKo::RadikoAuth::cookie_radiko_session());
	}

	return;
}

1;
