# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKoPr::Feed;

use v5.20;
use warnings;
use Slim::Utils::Log;
use Promises2 qw(rejected collect);
use Plugins::RadiRuKo::RadikoMeta;
use Data::Dumper;
use Plugins::RadiRuKo::Utils qw(
  localized localizedString
);
use Plugins::RadiRuKo::RadikoFeed qw(
  loadAreaFreeStationXml
);
use Plugins::RadiRuKo::RadikoAuth qw(
  cookie_radiko_session
);

my $log = logger('plugin.radiruko');

sub feedPromise () {
	if (!$log->is_debug && !cookie_radiko_session()) {
		return rejected('Please login first.');
	}

	return loadAreaFreeStationXml()->then(
		sub {
			my $stations = shift;

			my @items;
			for (@$stations) {
				my $name = localized(JA => $_->{name}, EN => $_->{ascii_name});
				push @items, +{
					title => $name,
					url   => 'radikop://' . $_->{id},
					icon  => $_->{logo}->[0]->{content},
					type  => 'audio',
				};
			}

			return {
				type  => 'opml',
				title => localizedString('PLUGIN_RADIRUKO_PREMIUM_NAME'),
				items => \@items,
			};
		}
	);
}

1;
