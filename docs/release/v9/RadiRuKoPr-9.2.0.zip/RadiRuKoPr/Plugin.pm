# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKoPr::Plugin;

use v5.20;
use warnings;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Strings;
use Data::Dumper;

use constant RADIRUKO_REQUIRED_VERSION => 9.2;

use base qw(Slim::Plugin::OPMLBased);

sub getDisplayName {'PLUGIN_RADIRUKO_AREAFREE_NAME'}

sub initPlugin {
	my $class = shift;

	my $app_prefs = preferences('plugin.radiruko');
	my $log       = logger('plugin.radiruko');

	$log->info('RadiRuKo-AreaFree-Plugin v', $class->_pluginDataFor('version'));

	require Plugins::RadiRuKo::Utils;
	Plugins::RadiRuKo::Utils->VERSION(RADIRUKO_REQUIRED_VERSION);

	require Plugins::RadiRuKo::RadikoHandler;
	require Plugins::RadiRuKoPr::Settings;
	require Plugins::RadiRuKoPr::Feed;

	Slim::Player::ProtocolHandlers->registerHandler(radikop => q(Plugins::RadiRuKo::RadikoHandler));

	$class->SUPER::initPlugin(
		tag    => 'RadiRuKoPr',
		menu   => 'radios',
		weight => 1.02,
		feed   => Plugins::RadiRuKo::Utils::feedFromPromise(\&Plugins::RadiRuKoPr::Feed::feedPromise),
	);

	Plugins::RadiRuKoPr::Settings->new();
}

sub playerMenu {'RADIO'}

1;
