# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKoPr::Feed;

use v5.20;
use warnings;
use Slim::Utils::Log;
use Plugins::RadiRuKo::Utils qw(
  localized lstring
);
use Plugins::RadiRuKo::RadikoFeed qw(
  loadAreaFreeStationXml
);
use Data::Dumper;

my $log = logger('plugin.radiruko');

sub feedPromise () {
	return loadAreaFreeStationXml()->then(
		sub {
			my $stations = shift;

			my @items;
			for (@$stations) {
				my $name = localized(JA => $_->{name}, EN => $_->{ascii_name});
				push @items, +{
					title => $name,
					url   => 'radikop://' . $_->{id},
					icon  => $_->{logo}->[0]->{content},
					type  => 'audio',
				};
			}

			return {
				type  => 'opml',
				title => lstring('PLUGIN_RADIRUKO_AREAFREE_NAME'),
				items => \@items,
			};
		}
	);
}

1;
