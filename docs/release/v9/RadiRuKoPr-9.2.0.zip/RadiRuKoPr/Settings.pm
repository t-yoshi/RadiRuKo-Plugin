# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoPr::Settings;

use v5.20;
use warnings;

use base qw(Slim::Web::Settings);

use URI::Escape qw(uri_escape);
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Promises2                     qw(rejected);
use Plugins::RadiRuKo::RadikoAuth qw(UA cookie_radiko_session);
use Plugins::RadiRuKo::Utils      qw(AsyncHttp);
use Data::Dumper;

my $log       = logger('plugin.radiruko');
my $app_prefs = preferences('plugin.radiruko');

sub name {
	return Slim::Web::HTTP::CSRF->protectName('PLUGIN_RADIRUKO_AREAFREE');
}

sub page {
	return Slim::Web::HTTP::CSRF->protectURI('plugins/RadiRuKoPr/settings/basic.html');
}

use constant {
	RE_MAIL_ADDRESS   => qr/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,
	RE_RADIKO_SESSION => qr/^[\da-f]{40}$/,
};

sub _radiko_login {
	my ($mail, $pass) = @_;

	$log->debug("login: [$mail]");

	return rejected('Invalid mail address.') unless $mail =~ RE_MAIL_ADDRESS;
	return rejected('Empty password')        unless $pass;

	return AsyncHttp()->post(
		'https://radiko.jp/v4/api/member/login',
		'User-Agent'   => UA,
		'Content-Type' => 'application/x-www-form-urlencoded',
		sprintf('mail=%s&pass=%s', uri_escape($mail), uri_escape($pass))
	)->then(
		sub {
			my $json = shift;
			$log->debug("login: OK");
			my $radiko_session = $json->{radiko_session};
			if ($radiko_session =~ RE_RADIKO_SESSION) {
				cookie_radiko_session($radiko_session);
				return Plugins::RadiRuKo::RadikoAuth->checkLogin();
			}
			return rejected('Invalid: radiko_session');
		}
	);
}

sub _radiko_logout {
	$log->debug("logout: Start");

	my $radiko_session = cookie_radiko_session();
	unless ($radiko_session) {
		return rejected('radiko_session is already empty.');
	}

	return AsyncHttp()->post(
		'https://radiko.jp/v4/api/member/logout',
		'User-Agent'   => UA,
		'Content-Type' => 'application/x-www-form-urlencoded',
		"radiko_session=$radiko_session"
	)->then(
		sub {
			my ($payload, $http) = @_;
			$log->debug('logout: OK ', Dumper $payload);
			cookie_radiko_session('');
			return 'Logout Successful.';
		}
	);
}

sub handler {
	my ($class, $client, $params, $callback, @args) = @_;

	my $on_result = sub {
		my $status = shift;

		my $radiko_session = cookie_radiko_session();

		$params->{cookie_radiko_session} = $radiko_session // '(none)';
		$params->{radiko_logged_in}      = $radiko_session =~ RE_RADIKO_SESSION;
		$params->{radiko_password}       = '';
		$params->{radiko_status}         = $status // '';

		my $body = $class->SUPER::handler($client, $params);
		$callback->($client, $params, $body, @args);
	};

	do {
		if ($params->{radiko_logout}) {
			_radiko_logout();
		} elsif ($params->{saveSettings}) {
			_radiko_login(@$params{qw(radiko_mail radiko_password)});
		} else {
			Plugins::RadiRuKo::RadikoAuth->checkLogin();
		}
	  }
	  ->done($on_result, $on_result);
}

1;
