# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoRo::ProtocolHandler;

use v5.20;
use warnings;
use utf8;
use Slim::Utils::Log;
use Data::Dumper;

use base q(Plugins::RadiRuKo::BaseFFSeekableHandler);

my $log = logger('plugin.radiruko');

sub new {
	my $class = shift;
	my $args  = shift;

	my $client = $args->{client};
	my $song   = $args->{song};

	my $u = $args->{url};
	$u =~ s/^radiruod:/https:/;

	return $class->SUPER::new($args, $u);
}

sub getFormatForURL {'aac'}

1;
