# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::FFMpegHandler;
#
# URL protocol handler
#
#  ffmpegpcm: PCMにデコードする
#  ffmpegaac: ソースのAACをそのまま出力 (48Khz)
#
# (例)
# ffmpegaac:http://xxxx/stream.m3u8#?--  HTTP Live Streaming
#   (NOTE) .m3u8はプレイリストと認識されて再生できないので#?--を付けること。
# ffmpegpcm:rtsp://xxxx/
# ffmpegpcm:mmst://xxxx/
#
use strict;
use base qw(Plugins::RadiRuKo::BaseFFMpegHandler);
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Data::Dumper;
use constant RE_FF_URL => qr{^ffmpeg(pcm|aac):((https?|rtsp|mms[th])://.+)};

my $log   = logger('plugin.radiruko');
my $prefs = preferences('server');

sub new {
    my $class = shift;
    my $args  = shift;

    if ($args->{url} =~ RE_FF_URL) {
        return $class->SUPER::new($args, $2);
    }

    logError('Invalid url: ' . $args->{url});
    return;
}

sub getNextTrack {
    my ($class, $song, $successCb, $errorCb) = @_;
    my $url = $song->currentTrack()->url();

    if ($url =~ RE_FF_URL) {
        $successCb->();
    } else {
        $errorCb->("Invalid url: $url");
    }
}

sub getFormatForURL {
    my ($class, $url) = @_;
    return $url =~ /^ffmpegaac:/ ? 'aac' : 'wav';
}

1;
