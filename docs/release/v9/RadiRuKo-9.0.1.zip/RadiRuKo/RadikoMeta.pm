# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadikoMeta;

use strict;
use utf8;
use POSIX;
use List::Util qw(first);
use Slim::Utils::Log;
use Plugins::RadiRuKo::Utils qw(
    RE_RADIKO_AUDIO_URL RE_RADIKOTF_AUDIO_URL
    jptime parseDateTime jpShortDateTimeF
    createMetaData prettyTitle
);
use Plugins::RadiRuKo::RadikoFeed qw(loadProgramXml);
use Data::Dumper;
use Promises::Tiny qw(collect resolved rejected);

my $log = logger('plugin.radiruko');

sub load {
    my $class  = shift;
    my $client = shift if ref $_[0];
    my $url    = shift;

    my $stId;         #TBS
    my $startTime;    #開始時間, undef=現在の番組
    if ($url =~ RE_RADIKOTF_AUDIO_URL) {
        $stId      = $1;
        $startTime = parseDateTime($2);
    } elsif ($url =~ RE_RADIKO_AUDIO_URL) {
        $stId = $1;
    } else {
        return rejected("RadikoMeta Invalid url: $url");
    }

    collect(
        resolved($client, $url, $stId, $startTime),
        loadProgramXml($stId, $startTime),
    )->then(\&_onParse);
}

sub _onParse {
    my ($client, $url, $stId, $startTime) = @{ $_[0] };
    my ($xml, $prog) = @{ $_[1] };

    unless ($prog) {
        my $d = 'on ' . jpShortDateTimeF($startTime) if $startTime;
        return rejected("RadikoMeta: $stId's program $d is not found.");
    }

    my $stationName = $xml->{stations}{station}{name};
    my $progTitle   = $prog->{title};

    #局名がタイトルに含まれていれば追加する必要はない
    if (index($progTitle, $stationName) == -1) {
        $progTitle = "$stationName $progTitle";
    }
    my $title = prettyTitle($progTitle);

    my $expires;
    if ($startTime) {
        #タイムフリー用
        $title .= ' (' . jpShortDateTimeF($startTime) . '-)';
        $expires = 2**32;
    } else {
        $expires = parseDateTime($prog->{to});
    }

    return createMetaData(
        $client, $url,
        title   => $title,
        album   => prettyTitle($prog->{desc} . ' ' . $prog->{info}),
        artist  => prettyTitle($prog->{pfm}),
        icon    => 'plugins/RadiRuKo/html/images/icon.png',
        cover   => $prog->{img} || "https://radiko.jp/station/logo/$stId/logo_large.png",
        expires => $expires,
    );
}

1;
