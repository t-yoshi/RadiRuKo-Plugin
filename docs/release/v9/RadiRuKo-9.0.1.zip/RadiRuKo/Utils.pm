# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::Utils;

use strict;
use Plugins::RadiRuKo::AsyncHttp;
use Slim::Utils::Log;
use Slim::Utils::Cache;
use Slim::Utils::Strings qw(string);
use Slim::Utils::Prefs;
use Slim::Music::Info;
use Carp::Assert qw(assert);
use Slim::Utils::Misc();
use Date::Parse;
use Time::Zone;
use Time::Local;
use POSIX                        qw(strftime);
use Scalar::Util                 qw(blessed);
use Time::HiRes                  qw(time);
use Text::VisualWidth::PP        qw(vwidth vtrim);
use Lingua::JA::Regular::Unicode qw(alnum_z2h space_z2h);
use Data::Dumper;

our $VERSION = 9.0;

use Exporter 'import';

our @EXPORT = qw(
    AsyncHttp prettyTitle
    RE_RADIKO_AUDIO_URL RE_RADIRU_AUDIO_URL
    RE_RADIKOTF_AUDIO_URL
);

our @EXPORT_OK = qw(
    strWidth trimWidth
    jptime parseDateTime jpShortDateTimeF
    isEnabledAreaFree
    createMetaData
    localized localizedString
    feedFromPromise
);

use constant {
    #(radikoId)
    RE_RADIKO_AUDIO_URL => qr'^radiko(?:p|tf)?://([A-Z\d]+[\-_]?[A-Z\d]+)',

    #(radikoId, startTime, endTime)
    RE_RADIKOTF_AUDIO_URL => qr'^radikotf://([A-Z\d]+[\-_]?[A-Z\d]+)/(\d{14})-(\d{14})',

    #(channel, area)
    RE_RADIRU_AUDIO_URL => qr'^radiru://(R1|R2|FM)(?:-([A-Z][a-z]+))?$',
};

my $log = logger('plugin.radiruko');

sub AsyncHttp { Plugins::RadiRuKo::AsyncHttp->new(@_) }

sub strWidth {
    local $Text::VisualWidth::PP::EastAsian = 1;
    return vwidth($_[0]);
}

#
# 文字列を後略する。
#
sub trimWidth {
    my $s        = shift || return '';
    my $maxWidth = shift || 200;         #半角換算の文字幅
    my $origLen  = length($s);
    $s = vtrim($s, $maxWidth);
    $s .= "..." if (length($s) + 3 < $origLen);
    return $s;
}

sub prettyTitle {
    local $_ = shift || '';
    my $maxWidth = shift || 200;         #半角換算の文字幅

    if (m{</?[a-z]\w*>}i) {
        # HTMLタグを除去する。
        s/<[^>]+>/ /g;
    }

    # 全角の空白と英数字を半角にする。
    $_ = alnum_z2h($_);
    $_ = space_z2h($_);
    s/\s+/ /g;
    s/^\s+//;
    s/\s+$//;
    $_ = trimWidth($_, $maxWidth) if $maxWidth > 0;
    return $_;
}

sub jptime(;$) {
    my $t = shift || time();
    return gmtime($t + tz_offset('JST'));
}

#
# 日時の文字列をエポック秒に変換する
#   ex. '2004-04-01T12:00+09:00' -> 1080788400
#
sub parseDateTime ($) {
    my $dateTime = shift;

    #radiko形式 '20160910151500' -> '20160910T151500'
    $dateTime =~ s/^(20\d{6})(\d{4,}.*)$/$1T$2/;

    my @tm = strptime($dateTime, 'JST');
    return timegm(@tm) - $tm[6] if scalar @tm;
}

# ex '8/31 12:34'
sub jpShortDateTimeF($) {
    my @tm = jptime(shift);

    my $serverPrefs = preferences('server');
    my $dateFormat  = $serverPrefs->get('shortdateFormat');
    my $timeFormat  = $serverPrefs->get('timeFormat');
    $dateFormat =~ s=\W*%[yY][^%]*==;                #年は省略
    $dateFormat =~ s=(?<!\|)%m([\.\-/]%d)=|%m$1=;    #月の0を除く 08 -> 8
                                                     #$log->info("$dateFormat $timeFormat");

    my $date = strftime("$dateFormat $timeFormat", @tm);
    $date =~ s/\|0*//g;                              #see DateTime.pm
    return Slim::Utils::Unicode::utf8decode_locale($date);
}

sub createMetaData {
    my $client = shift if (blessed $_[0] || !defined $_[0]);
    my $url    = shift;
    assert(@_ % 2 == 0);

    my $song     = $client->playingSong()        if defined $client;
    my $ffFormat = $song->pluginData('ffFormat') if defined $song;
    my $type     = string('RADIO');

    if ($url =~ /^([a-z]+):/) {
        my $token = uc($1);
        $type = string($token) if Slim::Utils::Strings::stringExists($token);
    } elsif ($url =~ /#simulradio=1/) {
        $type = string('PLUGIN_RADIRUKO_SIMULRADIO');
    }

    $type = "$ffFormat($type)" if defined $ffFormat;

    my $meta = {
        url     => $url,
        title   => Slim::Music::Info::title($url) || $url,
        icon    => 'html/images/radio.png',
        type    => $type,
        bitrate => 'n/a',
        @_,
    };

    if ($meta->{bitrate} eq 'n/a' && defined $song && $song->bitrate > 0) {
        my $b = $song->bitrate;
        $b /= 1000 if $b > 1000;
        $meta->{bitrate} = sprintf('%d%s', $b, string('KBPS'));
    }

    return $meta;
}

sub isEnabledAreaFree() {
    return !!Slim::Utils::PluginManager->isEnabled('Plugins::RadiRuKoPr::Plugin');
}

# localized(JA=>$ja, EN=>$en) -> $ja | $en
sub localized {
    my $hash = ref($_[0]) eq 'HASH' ? $_[0] : {@_};
    my $lang = Slim::Utils::Strings::getLanguage();
    my $a    = $hash->{$lang} || $hash->{EN} || $hash->{''} || [];
    #$log->debug(Dumper $hash, $lang, $a);
    return ref($a) eq 'ARRAY' ? @$a : ($a,) if wantarray;
    return $a;
}

# localizedString($token, JA=>[...], EN=>[...])
#
sub localizedString {
    my $token = shift;
    return string($token) if @_ == 0;
    return string($token, localized(@_));
}

sub _copyMenuItems ($) {
    return [ map { +{%$_} } @{ $_[0] } ];
}

sub feedFromPromise($) {
    my $promise = shift;
    assert(ref($promise) =~ /^(Promise|CODE)/);

    return sub {
        my ($client, $callback, $args, @passthrough) = @_;
        assert(ref $callback eq 'CODE');

        my $p = ref $promise eq 'CODE' ? $promise->($client, $args, @passthrough) : $promise;

        $p->done(
            sub {
                my $items = shift;

                #hashにinsertLinkなどが勝手に追加されてしまうので
                #deep copyは必要
                if (ref $items eq 'HASH') {
                    $items->{items} = _copyMenuItems $items->{items};
                } elsif (ref $items eq 'ARRAY') {
                    $items = _copyMenuItems $items;
                } else {
                    $log->logdie('items need as HASH or ARRAY.');
                }
                $callback->($items);
            },
            sub {
                my $error = shift;

                $log->error("Feed error: $error");

                $callback->([ {
                            title => "$error",
                            items => [],
                        }
                    ]
                );
            }
        );

        return;
    };
}

1;
