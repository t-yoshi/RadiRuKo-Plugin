# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKo::Plugin;

use strict;

use base qw(Slim::Plugin::OPMLBased);
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Timers;
use Slim::Utils::Misc();
use Slim::Utils::OSDetect;

BEGIN {
    use Slim::Networking::Async::HTTP;

    Slim::Networking::Async::HTTP::hasSSL() || die 'Require IO::Socket::SSL';
}

use Plugins::RadiRuKo::Utils 9.0 qw(
    feedFromPromise
);
use Plugins::RadiRuKo::FFMpegHandler;
use Plugins::RadiRuKo::RadikoHandler;
use Plugins::RadiRuKo::RadiruHandler;
use Plugins::RadiRuKo::FmppClient;
use Plugins::RadiRuKo::FmppDecodeHandler;
use Plugins::RadiRuKo::RadikoAuth;
use Plugins::RadiRuKo::Feed;
use Plugins::RadiRuKo::RadiruConfig;
use Plugins::RadiRuKo::Settings;

my $app_prefs = preferences('plugin.radiruko');
# create log categogy before loading other modules
my $log = Slim::Utils::Log->addLogCategory({
        category     => 'plugin.radiruko',
        defaultLevel => 'INFO',
        description  => getDisplayName(),
    }
);

sub getDisplayName {'PLUGIN_RADIRUKO_NAME'}

sub initPlugin {
    my $class = shift;

    $log->info('RadiRuKo-Plugin v' . $class->_pluginDataFor('version'));

    $class->SUPER::initPlugin(
        tag    => 'RadiRuKo',
        menu   => 'radios',
        weight => 1.01,
        feed   => feedFromPromise(\&Plugins::RadiRuKo::Feed::feedPromise),
    );

    Slim::Player::ProtocolHandlers->registerHandler(
        ffmpegpcm => q(Plugins::RadiRuKo::FFMpegHandler));
    Slim::Player::ProtocolHandlers->registerHandler(
        ffmpegaac => q(Plugins::RadiRuKo::FFMpegHandler));

    Slim::Player::ProtocolHandlers->registerHandler(radiko => q(Plugins::RadiRuKo::RadikoHandler));
    Slim::Player::ProtocolHandlers->registerHandler(radiru => q(Plugins::RadiRuKo::RadiruHandler));

    #TODO: 一部アーキのsoxでopusがサポートされていない
    my $wsHandler =
        0 && _isOpusSupported()
        ? q(Plugins::RadiRuKo::FmppClient)
        : q(Plugins::RadiRuKo::FmppDecodeHandler);
    Slim::Player::ProtocolHandlers->registerHandler(fmpp => $wsHandler);
    Slim::Player::ProtocolHandlers->registerHandler(jcba => $wsHandler);

    Plugins::RadiRuKo::Settings->new();

    if ($log->is_warn) {
        require Promises::Tiny;
        Promises::Tiny->set_warn_on_unhandled_reject(1);
        #Promises::Tiny::rejected('This is a test.');
    }
}

sub _isOpusSupported() {
    #一部arm-linux(armv5te)でlibopusが原因のノイズが
    #発生するのでffmpegでデコードする
    my $osDetails = Slim::Utils::OSDetect::details();
    return 0 if $osDetails->{binArch} =~ /arm-linux/;

    #opusのサポートは7.9.2以降
    return defined $Slim::Music::Info::types{ops};
}

sub playerMenu {'RADIO'}

1;
