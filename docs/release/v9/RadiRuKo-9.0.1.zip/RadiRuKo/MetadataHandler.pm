# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::MetadataHandler;

use Carp::Assert;
use Slim::Utils::Log;
use Slim::Utils::PerlRunTime;
use Slim::Utils::Timers;
use Slim::Control::Request;
use Slim::Formats::RemoteMetadata;
use Slim::Music::Info;
use Slim::Player::Protocols::HTTP;
use Time::HiRes q(time);
use List::Util qw(min);
use Data::Dumper;
use Plugins::RadiRuKo::Utils qw(createMetaData jpShortDateTimeF);

my $log = logger('plugin.radiruko');

#
# メタデータを返す。
# Note: Touchは10分毎に呼び出してくる。
#      制御アプリは数秒毎に呼び出すこともある。
#
#	{
#          url     => 'ffmpegaac:http://...',
#          artist  => 'Artist Name',
#          album   => 'Album Name',
#          title   => 'Track Title',
#          cover   => 'http://...',
#          bitrate => 128,
#          type    => 'Internet Radio',
#
#          #オプション: 有効期限
#		   expires => time()+180,
#   }
#

sub getMetadataFor($$$;$) {
    my ($class, $client, $url, $forceCurrent) = @_;

    my $meta = $client->master->pluginData('ffMeta');
    if (!$meta || $meta->{url} ne $url) {
        $meta = _defaultMetadata($client, $url);
        $client->master->pluginData(ffMeta => $meta);
    }

    #取得中or期限内
    return $meta if ($meta->{_loading} || $meta->{expires} > time());

    return _defaultMetadata($client, $url) unless ($client->isPlaying() || $client->isPaused());

    return _defaultMetadata($client, $url) unless $class->can('getMetadataForAsync');

    $meta->{_loading} = 1;

    my $promise = $class->getMetadataForAsync($client, $url);

    unless (ref $promise && $promise->can('then')) {
        $log->error('getMetadataForAsync neither returned Deferred nor Promise.');
        return _defaultMetadata($client, $url);
    }

    _asyncCacheMetadata($client, $url, $promise);

    return $meta;
}

#
# メディア・フラグメントURI
#
# http://www.simulradio.jp/asx/XXX.asx#simulradio=1;title=タイトル;icon=http://icon-url/;homepage=http://station-homepage/;--
#
# NOTE:
#  拡張子や開始/終了時間だと誤認させないように";--"で終端させる
#
sub parseMediaFragment {
    my $classOrSelf = shift;
    my $url         = shift;
    if ($url =~ /#(.*)$/) {
        my $frag = "$1;";
        utf8::decode($frag);
        return +{ $frag =~ /([a-z]+)=(.*?)[;&](?=[a-z]+=|\W*$)/g };
    }
    return +{};
}

sub _defaultMetadata ($$) {
    my ($client, $url) = @_;

    my $frags = __PACKAGE__->parseMediaFragment($url);
    if (defined $frags->{title}) {
        return createMetaData(
            $client, $url,
            title  => $frags->{title},
            artist => $frags->{artist} || ' ',
            album  => $frags->{album}  || $frags->{homepage},
            cover  => $frags->{cover}  || $frags->{icon} || 'html/images/radio.png',
        );
    }
    return createMetaData($client, $url);
}

sub _asyncCacheMetadata ($$$) {
    my ($client, $url, $promise) = @_;

    $promise->then(
        sub {
            $log->debug('New meta: ' . Dumper $_[0]) if $log->is_debug;
            return $_[0];
        },
        sub {
            $log->error($_[0]);
            return +{};
        }
    )->done(
        sub {
            my $defaultMeta = _defaultMetadata($client, $url);
            my $newMeta     = {
                %$defaultMeta,
                %{ $_[0] },
            };

            my $now = time();
            if ($newMeta->{expires} < $now + 180) {
                $newMeta->{expires} = $now + 180;
            }

            $client->master->pluginData(ffMeta => $newMeta);
            _notifyNewMetadata($client);
            _scheduleNotifyNewMetadata($client, $newMeta->{expires});
        }
    );
}

sub _scheduleNotifyNewMetadata($$) {
    my $client  = shift;
    my $expires = shift;

    assert($expires >= 0);
    $log->debug('Set meta expires: ' . localtime($expires)) if $log->is_debug;

    Slim::Utils::Timers::killTimers($client, \&_notifyNewMetadata);
    Slim::Utils::Timers::setTimer($client, $expires, \&_notifyNewMetadata);
}

sub _notifyNewMetadata($) {
    my $client = shift;

    Slim::Control::Request::notifyFromArray($client, ['newmetadata']);
}

sub invalidateCachedMetadata($$) {
    my ($classOrSelf, $client) = @_;

    $client->master->pluginData(ffMeta => {});

    #WebUIの更新
    $client->currentPlaylistUpdateTime(time());

    Slim::Utils::Timers::setTimer($client, 0, \&_notifyNewMetadata);
}

1;
