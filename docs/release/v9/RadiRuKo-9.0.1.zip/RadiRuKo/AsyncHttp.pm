# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::AsyncHttp;

use Slim::Networking::SimpleAsyncHTTP;
use Slim::Utils::Log;
use Promises::Tiny qw(deferred);
use Carp::Assert   qw(assert);
use List::Util     qw(min);
use Tie::RegexpHash;
use XML::Simple;
use JSON::XS::VersionOneAndTwo qw(from_json);
use Data::Dumper;

my $log = logger('plugin.radiruko');

tie my %defaultHandlers, 'Tie::RegexpHash';

#
# AsyncHttp(cache => 1, expires => 60)
#  ->handler(func)
#  ->get(url, header => value, ...)
#

sub _canonicalize_expires($) {
    local $_ = shift;
    return $1         if /^(\d+)(\s*sec(onds?)?)?$/;
    return $1 * 60    if /^(\d+)\s*min(s|utes?)?/;
    return $1 * 3600  if /^(\d+)\s*hours?/;
    return $1 * 86400 if /^(\d+)\s*days?/;

    $log->error("Invalid expire: $_");
    return 10 * 60;
}

sub new {
    my $class = shift;
    assert(@_ % 2 == 0);
    my %params = @_;

    if (defined $params{expires}) {
        $params{expires} = _canonicalize_expires($params{expires});
    } elsif ($params{cache} && $params{cache} ne 1) {
        $params{expires} = _canonicalize_expires($params{cache});
        $params{cache}   = 1;
        #$log->debug('set expires: ' . $params{expires});
    }

    #最大10日間キャッシュ可能とする
    $params{expires} = min($params{expires}, 864000) if $params{expires} > 86400;

    my $deferred = deferred();

    my $http = Slim::Networking::SimpleAsyncHTTP->new(
        sub {
            my ($http) = @_;
            #SimpleAsyncHTTPの最大キャッシュ時間は1日だが
            # 少なすぎるので拡張する
            if ($params{cache} && $params{expires} > 86400 && !$http->cachedResponse) {
                $http->cacheResponse($params{expires}, 0, $params{client});
            }
            $deferred->resolve($http);
        },
        sub {
            my ($http, $err) = @_;
            $deferred->reject($err . ': ' . $http->url, $http);
        },
        \%params,
    );

    return bless {
        deferred => $deferred,
        http     => $http,
        handler  => undef,
    }, $class;
}

sub handler {
    my $self    = shift;
    my $handler = shift;

    assert(ref $handler eq 'CODE');
    $self->{handler} = $handler;

    return $self;
}

$defaultHandlers{qr{^(application|text)/xml\b}i} = sub {
    my $http   = shift;
    my %params = (
        ForceArray    => 0,
        KeyAttr       => [],
        SuppressEmpty => '',
    );
    return XMLin($http->contentRef, %params);
};

$defaultHandlers{qr{^(application|text)/json\b}i} = sub {
    my $http = shift;
    return from_json($http->content);
};

sub _parse {
    my $self = shift;
    return $self->{deferred}->then(
        sub {
            my $http = shift;

            return $self->{handler}->($http) if defined $self->{handler};

            my $ct      = $http->headers->content_type;
            my $handler = $defaultHandlers{$ct} || sub {
                my $http = shift;
                return $http->content;
            };
            return $handler->($http);
        }
    );
}

sub get {
    my $self = shift;
    $self->{http}->get(@_);
    return $self->_parse();
}

sub post {
    my $self = shift;
    $self->{http}->post(@_);
    return $self->_parse();
}

sub put {
    my $self = shift;
    $self->{http}->put(@_);
    return $self->_parse();
}

sub head {
    my $self = shift;
    $self->{http}->head(@_);
    return $self->_parse();
}

1;
