# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruMeta;

use strict;
use utf8;
use POSIX;
use List::Util qw(first);
use Slim::Utils::Log;
use Plugins::RadiRuKo::Utils qw(
    AsyncHttp prettyTitle RE_RADIRU_AUDIO_URL
    parseDateTime createMetaData localizedString
);
use Plugins::RadiRuKo::RadiruConfig;
use Promises::Tiny qw(collect resolved);
use Data::Dumper;

my $log = logger('plugin.radiruko');

# URL:
#  radiru://Station[-Area]
#
#  Station:
#    R1, R2, FM
#  Area:
#    Sendai, Tokyo, Nagoya, Osaka, ...
#

sub load {
    my $class  = shift;
    my $client = shift if ref $_[0];
    my $url    = shift;

    my ($channel, $area) = $url =~ RE_RADIRU_AUDIO_URL;
    $area ||= 'tokyo';

    Plugins::RadiRuKo::RadiruConfig->load()->then(
        sub {
            my $config = shift;
            my $data   = $config->data(area => $area) || die "area: '$area' not found.";
            my $chName = localizedString(
                "PLUGIN_RADIRUKO_NHK_${channel}",
                JA => $data->{areajp},
                EN => ucfirst($data->{area}),
            );

            collect(
                resolved($client, $url, $channel, $chName),
                AsyncHttp()->get($data->{url_program_noa}),
            );
        }
    )->then(\&_onJson);
}

sub _onJson {
    #$log->debug(Dumper @_);
    my ($client, $url, $channel, $chName) = @{ $_[0] };
    my $js = $_[1]->[0];

    my $ch       = { R1 => 'n1', R2 => 'n2', FM => 'n3' }->{$channel};
    my @programs = values %{ $js->{nowonair_list}->{$ch} };
    my $now      = time();

    #放送中
    my $prog =
        first { $now >= parseDateTime($_->{start_time}) && parseDateTime($_->{end_time}) > $now }
        @programs
        or return;

    my $logo = $prog->{images}{logo_l}{url} ||
        $prog->{images}{thumbnail_m}{url}   ||
        "plugins/RadiRuKo/html/images/NHK_$channel.png";

    #次の番組開始時間にメタ更新を通知する
    my $following = $js->{nowonair_list}{$ch}{following};
    my $expires   = parseDateTime($following->{start_time});
    if ($expires <= $now) {
        $expires = parseDateTime($following->{end_time});
    }

    return createMetaData(
        $client, $url,
        title   => prettyTitle($prog->{title}),
        artist  => prettyTitle($prog->{act}),
        album   => prettyTitle($prog->{subtitle} || $prog->{music}),
        cover   => $logo,
        expires => $expires,
    );
}

1;
