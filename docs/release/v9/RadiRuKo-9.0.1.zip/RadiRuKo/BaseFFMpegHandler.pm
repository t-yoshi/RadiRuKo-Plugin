# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::BaseFFMpegHandler;

use strict;
use base qw(
    Slim::Player::Pipeline
    Plugins::RadiRuKo::MetadataHandler
);
use Scalar::Util qw(blessed);
use Carp::Assert;
use Slim::Utils::Misc();
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Data::Dumper;
use Plugins::RadiRuKo::FFLogger;

my $log          = logger('plugin.radiruko');
my $server_prefs = preferences('server');
my $app_prefs    = preferences('plugin.radiruko');

# args:
#  ffurl
#  ffoptions

sub new {
    my $class     = shift;
    my $args      = shift;
    my $ffurl     = shift;
    my @ffoptions = @_;

    unless ($ffurl) {
        logError('Missing required argument: ffurl.');
        return;
    }

    my $ffsource;
    if (blessed $ffurl && $ffurl->can('sysread')) {
        $ffsource = $ffurl;
        $ffurl    = '-';
    } else {
        $ffurl =~ s/#.*$//;
    }

    #メディア・フラグメントURI
    my $mediafrags = $class->parseMediaFragment($args->{url});

    my $format;
    if ($class->can('getFormatForURL')) {
        $format = $class->getFormatForURL($args->{url});
    } else {
        $format = 'wav';
    }

    if ($log->is_debug) {
        local $Data::Dumper::Indent = 0;
        local $Data::Dumper::Terse  = 1;
        $log->debug("ffurl: $ffurl, format=$format, flags=" . Dumper($mediafrags));
    }

    my $fflogger = Plugins::RadiRuKo::FFLogger->new();

    my $ffmpeg = _find_ffmpeg() || return undef;
    my @cmds   = (
        $ffmpeg, qw/-hide_banner -nostdin/,
        $fflogger->fflog_options(),
    );

    my $song  = $args->{song};            ## Slim::Player::Song
    my $track = $song->currentTrack();    ## Slim::Schema::RemoteTrack

    if ($ffurl =~ /^https?:/) {
        push @cmds,
            -user_agent    => 'Mozilla/5.0',
            #Rangeヘッダを付加しない
            -seekable      => 0,
            -http_seekable => 0;

        #HLS
        if ($ffurl =~ /\.m3u8\b/) {
            #Liveでのバッファ時間
            my $start_index = {
                #normal => -3,
                long    => -6,
                maximum => -0,
            }->{ $app_prefs->hls_buffering_time() };
            if ($song->isLive && defined $start_index) {
                push(@cmds, -live_start_index => $start_index);
            }
        }
    }

    my $timeout    = $server_prefs->get('remotestreamtimeout') || 30;
    my $timeout_us = $timeout * 1_000_000;

    if ($ffurl =~ /^rtsp:/) {
        #see: https://github.com/ffmpeg/FFmpeg/blob/master/libavformat/rtsp.c
        push @cmds, qw/-rtsp_transport tcp -timeout/, $timeout_us;
    } else {
        push @cmds, -rw_timeout => $timeout_us;
    }

    #HLSでLiveのときは -re は不要
    push(@cmds, '-re') unless ($song->isLive && $ffurl =~ /^https?:.*\.m3u8\b/);

    push @cmds, @ffoptions, -i => $ffurl;

    my $contentType;
    if ($format eq 'aac') {
        push @cmds, qw/-acodec copy -f adts/;
    } elsif ($format eq 'wav') {
        push @cmds, qw/-ar 48k -ac 2 -f s16le/;
    } else {
        logError("Invalid format: $format");
        return;
    }

    if ($mediafrags->{ffmap} =~ /(\d)/) {
        push(@cmds, -map => "0:a:$1");
    }

    push @cmds, '-';
    my $cmd = _escapeCommands(@cmds);

    $fflogger->start();

    my $self = do {
        local $ENV{FFREPORT} = $fflogger->ffreport_environment_value();
        $log->debug('FFREPORT=' . $ENV{FFREPORT});

        $class->SUPER::new($ffsource, $cmd, 0);
    };

    unless (defined $self) {
        $fflogger->stop();
        return undef;
    }

    ${*$self}{url}          = $args->{url};
    ${*$self}{client}       = $args->{client};
    ${*$self}{transcoder}   = $args->{transcoder};
    ${*$self}{song}         = $song;
    ${*$self}{mediafrags}   = $mediafrags;
    ${*$self}{_contentType} = $format;
    ${*$self}{_fflogger}    = $fflogger;

    $track->samplerate(48_000);
    if ($format eq 'wav') {
        $track->samplesize(16);
        $track->channels(2);
    }
    $track->content_type($format);

    return $self;
}

sub _doParseStreamInfo {
    my $self  = shift;
    my $info  = ${*$self}{_fflogger}->parseStreamInfo() || return;
    my $input = $info->{Input}{ $info->{Selected} }     || {};
    if ($input->{Metadata}{variant_bitrate} > 0) {
        Slim::Music::Info::setBitrate(
            ${*$self}{url},
            $input->{Metadata}{variant_bitrate},
            1
        );
    } elsif ($input->{bitrate} > 0) {
        Slim::Music::Info::setBitrate(
            ${*$self}{url},
            $input->{bitrate},
            $input->{Metadata}{IsVBR} || 0
        );
    }

    ${*$self}{song}->pluginData(ffFormat => $input->{audio_format});

    $self->invalidateCachedMetadata(${*$self}{client});
}

sub sysread {
    my $self = shift;
    my $ret  = $self->SUPER::sysread($_[0], $_[1], $_[2]);
    if ($ret) {
        $self->_doParseStreamInfo() if (!${*$self}{_readBytes});
        ${*$self}{_readBytes} += $ret;
    }
    return $ret;
}

sub _find_ffmpeg {
    my $path = Slim::Utils::Misc::findbin('ffmpeg_bin') ||
        Slim::Utils::Misc::findbin('ffmpeg5') ||
        Slim::Utils::Misc::findbin('ffmpeg');

    $log->fatal('Please install ffmpeg') unless $path;

    return $path;
}

#コマンド引数をエスケープする
sub _escapeCommands {
    @_ = map {
        s/([\$\"\`])/\\$1/g;
        /^[\w\+\-\/\.]+$/ ? $_ : "\"$_\"";
    } @_;
    return join(' ', @_);
}

sub close {
    my $self = shift;
    $self->SUPER::close();
    ${*$self}{_fflogger}->stop();
}

sub DESTROY {
    my $self = shift;
    $self->SUPER::DESTROY();
    $self->close();
}

sub contentType {
    my $self = shift;
    return ${*$self}{_contentType};
}

# Avoid scanning
sub scanUrl {
    my ($class, $url, $args) = @_;
    $args->{cb}->($args->{song}->currentTrack());
}

sub canDirectStream {0}

sub isRemote {1}

sub isAudioURL {1}

sub bufferThreshold {
    my ($class, $client, $url) = @_;

    my $type       = $client->playingSong()->track()->content_type();
    my $bufferSecs = $server_prefs->get('bufferSecs') || 3;
    #$log->debug("$url: [$type, $bufferSecs]");

    return ($type eq 'wav' ? 120 : 8) * $bufferSecs;
}

1;
