# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruConfig;

use strict;
use utf8;
use List::Util qw(first);
use URI;
use Carp::Assert;
use Slim::Utils::Log;
use Plugins::RadiRuKo::Utils;
use Promises::Tiny qw(resolved);
use Data::Dumper;

use constant CONFIG_URL => 'https://www.nhk.or.jp/radio/config/config_web.xml';

my $log = logger('plugin.radiruko');

my @cache = (undef, 0);    #(instance, expires)

sub load($) {
    my $class = shift;

    my $now = time();

    return resolved($cache[0]) if (defined $cache[0] && $cache[1] > $now);

    return AsyncHttp()->get(CONFIG_URL)->then(
        sub {
            my $instance = $class->new($_[0]);
            #24Hキャッシュする
            @cache = ($instance, $now + 86400);
            return $instance;
        }
    );
}

sub new ($$) {
    my $class = shift;
    my $xml   = shift;

    my $data = $xml->{stream_url}->{data};

    for (@$data) {
        $_->{url_program_noa} = _subUrl($xml->{url_program_noa}, $_);
    }

    return bless($data, $class);
}

#
# data() 全体を返す
# data(areajp => '東京'), data(area => 'Tokyo')
#
sub data ($;$$) {
    my $self = shift;
    return @$self if @_ == 0;

    my $key = shift;
    my $val = shift;

    assert($key =~ /^(areajp|area|areakey)$/, "Invalid key: $key");

    return first { ucfirst $_->{$key} eq ucfirst $val } @$self;
}

sub _subUrl($$) {
    my $url  = shift;
    my $data = shift;
    $url =~ s/\{area\}/$data->{areakey}/;
    return URI->new_abs($url, CONFIG_URL)->as_string;
}

1;
