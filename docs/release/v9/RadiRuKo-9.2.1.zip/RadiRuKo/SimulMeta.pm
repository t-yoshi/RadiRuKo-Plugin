# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::SimulMeta;

use v5.20;
use warnings;
use utf8;
use Carp::Assert;
use List::Util qw(first);
use Time::HiRes q(time);
use Slim::Utils::Log;
use Plugins::RadiRuKo::MetadataHandler;
use Plugins::RadiRuKo::Utils qw(AsyncHttp parseDateTime formatTitle);
use Data::Dumper;

my $log = logger('plugin.radiruko');

sub _DEBUG() { 1 && $log->is_debug; }

use Exporter 'import';
our @EXPORT_OK = qw(RE_LISTEN_RADIO RE_JCBA RE_FMPP);

use constant {
	RE_LISTEN_RADIO => qr{\.smartstream\.ne\.jp/(\d{5})/},
	RE_JCBA         => qr{^jcba://(\w+)/},
	RE_FMPP         => qr{^fmpp://(\w+)/},
};

sub _fetchListenRadioMeta {
	my ($handler, $client, $url) = @_;
	#$log->debug($url);
	my ($id) = $url =~ RE_LISTEN_RADIO;
	assert($url && $id);

	my $meta = $handler->defaultMetadata($client, $url);

	return AsyncHttp()->post(
		'https://listenradio.jp/Home/NowPlayingMusic',
		'Content-Type' => 'application/x-www-form-urlencoded',
		"id=$id"
	)->then(
		sub {
			my ($js) = @_;

			$log->debug(Dumper($js)) if $log->is_debug;

			if ($js->{Status} =~ /^[23]$/) {
				$meta->{title} .= ' - ' . formatTitle($js->{Title});
				if ($js->{Limit} > 0) {
					$meta->{expires} = int(time() + $js->{Limit} / 1000 + 1);
				}
			}
			return $meta;
		}
	);
}

sub _fetchJcbaMeta {
	my ($handler, $client, $url) = @_;
	#$log->debug($url);
	my ($id) = $url =~ RE_JCBA;
	assert($url && $id);

	my $meta = $handler->defaultMetadata($client, $url);

	return AsyncHttp()->get(
		"https://www.jcbasimul.com/api/timetable/current/$id",
	)->then(
		sub {
			my ($js) = @_;

			$log->debug(Dumper($js, $meta)) if _DEBUG;

			if ($js->{current}{title}) {
				$meta->{title} .= ' - ' . formatTitle($js->{current}{title});
				$meta->{artist} = formatTitle($js->{current}{performer});
				my $end = parseDateTime($js->{current}{air_end});
				if ($end > 0) {
					$meta->{expires} = $end;
				}
			}
			return $meta;
		}
	);
}

sub _fetchFmppMeta {
	my ($handler, $client, $url) = @_;

	my ($id) = $url =~ RE_FMPP;
	assert($url && $id);

	my $meta = $handler->defaultMetadata($client, $url);

	return AsyncHttp(cache => '1 day, no-revalidate')->get(
		'https://api.fmplapla.com/api/v1/mobile/updates',
		'User-Agent' => 'okhttp'
	)->then(
		sub {
			my ($js) = @_;
			my $now = time();

			my $timetable = first { $_->{type} eq 'timetable' && $_->{station} eq $id } @{ $js->{updates} };
			$timetable //= {};
			my $data = first { $now >= $_->{start} && $now < $_->{end} } @{ $timetable->{data} // [] };

			$log->debug(Dumper($data, $meta)) if _DEBUG;

			if ($data && $data->{title}) {
				$meta->{title} .= ' - ' . formatTitle($data->{title});
				$meta->{artist}  = formatTitle($data->{performer});
				$meta->{album}   = formatTitle($data->{sub_title});
				$meta->{expires} = $data->{end};
			}

			return $meta;
		}
	);
}

Plugins::RadiRuKo::MetadataHandler->registerAsyncMetaProvider(
	match => RE_LISTEN_RADIO,
	func  => \&_fetchListenRadioMeta,
);

Plugins::RadiRuKo::MetadataHandler->registerAsyncMetaProvider(
	match => RE_JCBA,
	func  => \&_fetchJcbaMeta,
);

Plugins::RadiRuKo::MetadataHandler->registerAsyncMetaProvider(
	match => RE_FMPP,
	func  => \&_fetchFmppMeta,
);

1;
