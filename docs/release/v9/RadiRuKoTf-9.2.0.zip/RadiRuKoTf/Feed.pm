# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoTf::Feed;

use v5.20;
use warnings;
use utf8;

use Carp::Assert qw(assert);
use POSIX        qw(strftime);
use Tie::IxHash;
use URI::Escape qw(uri_escape_utf8);
use Slim::Utils::DateTime;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Strings;
use Data::Dumper;

use Plugins::RadiRuKo::RadikoAuth;
use Plugins::RadiRuKo::RadikoMeta;
use Plugins::RadiRuKo::RadikoFeed qw(
  loadTimeFreeStationXml loadProgramXml
  searchWordJson PROGRAM_DAY_OFFSET
);
use Plugins::RadiRuKo::Utils qw(
  jptime parseDateTime localized
  jpShortDateTimeF isEnabledAreaFree
  RE_RADIKO_TF_URL formatTitle
  lstring feedFromPromise
);

my $log       = logger('plugin.radiruko');
my $app_prefs = preferences('plugin.radiruko');

my @Wday = qw(Sun Mon Tue Wed Thu Fri Sat);

#
# URL形式
# radikotf://LFR/20171113110000-20171113112000
#
sub _createUrl {
	my ($stationId, $ftStrTime, $toStrTime) = @_;

	my $ftET = parseDateTime($ftStrTime);

	$ftStrTime =~ s/[\- \:]//g;
	$toStrTime =~ s/[\- \:]//g;

	return "radikotf://$stationId/$ftStrTime-$toStrTime";
}

use constant SEARCH_ROW_LIMIT => 50;

sub _doSearchTimeFree {
	my $query      = shift;
	my $areaId     = shift;
	my $stationMap = shift;
	my $page       = shift // 0;
	my $items      = shift // [];

	my $onParse = sub {
		my $hash = shift;
		push @$items, map {
			+{
				title => sprintf(
					'%s (%s - %s)', formatTitle($_->{title}),
					$stationMap->{ $_->{station_id} } || $_->{station_id},
					jpShortDateTimeF(parseDateTime($_->{start_time}))
				),
				url  => _createUrl($_->{station_id}, $_->{start_time}, $_->{end_time}),
				type => 'audio',
				#_sortKey => $_->{start_time} . '#' . $_->{title},
			}
		} @{ $hash->{data} };

		$log->debug("p=$page, r=" . $hash->{meta}{result_count}) if $log->is_debug;

		if ($page < 3 && $hash->{meta}{result_count} > SEARCH_ROW_LIMIT * (1 + $page)) {
			# 次のページのために再帰
			return _doSearchTimeFree($query, $areaId, $stationMap, $page + 1, $items);
		}

		#@$items = sort { $b->{_sortKey} cmp $a->{_sortKey} } @$items;
		return $items;
	};

	return searchWordJson($areaId, $query, $page, SEARCH_ROW_LIMIT)->then($onParse);
}

sub _loadSearchTimeFree {
	my ($client, $args, $areaId, $stations) = @_;

	my $stationMap = +{ map { $_->{id} => $_->{name} } @$stations };

	return _doSearchTimeFree($args->{search}, $areaId, $stationMap);
}

#
# *一部NG **全部?
#
sub _createProgramItems {
	my ($client, $args, $station, $ts_target, $ts_now) = @_;

	assert($station->{id});
	assert($ts_target > 0 && $ts_now > 0);

	return loadProgramXml($station->{id}, $ts_target)->then(
		sub {
			my $xml   = shift;
			my @progs = @{ $xml->{stations}{station}{progs}{prog} };

			my @items;
			for (@progs) {
				my $title = sprintf('%s%s', '*' x int($_->{ts_in_ng}), formatTitle($_->{title}));
				#放送終了前
				$title = "**$title" if parseDateTime($_->{to}) > $ts_now;
				my $start = Slim::Utils::DateTime::timeF(parseDateTime($_->{ft}), '%k:%M', 0) . '～';
				my $icon  = 'html/images/radio.png';
				$icon = $_->{img} if ($_->{img} && $title !~ /^\*{2}/);

				my $item = {
					title => $title,
					line1 => $title,
					line2 => $start,
					icon  => $icon,
					url   => _createUrl($station->{id}, $_->{ft}, $_->{to}),
					type  => 'audio',
				};
				push @items, $item;
			}
			return \@items;
		}
	);
}

sub _weekdayIcon {
	my ($sec, $min, $hour, $mday, $mon, $year, $wday) = jptime($_[0]);
	return "plugins/RadiRuKoTf/html/images/wday$wday.png";
}

sub _createWeekItems {
	my ($station, $ts_now) = @_;

	assert($station->{id});
	assert($ts_now > 0);

	#過去1週間分
	my @times = map { $ts_now - ($_ * 24 * 60 * 60) } 0 .. 7;
	my @items = map {
		+{
			#朝5時更新
			title       => Slim::Utils::DateTime::longDateF($_ - PROGRAM_DAY_OFFSET),
			icon        => _weekdayIcon($_ - PROGRAM_DAY_OFFSET),
			url         => feedFromPromise(\&_createProgramItems),
			passthrough => [ $station, $_, $ts_now ],
		}
	} @times;

	return \@items;
}

#
#  (Stations) -> (Day) -> (Programs)
#
sub feedPromise {
	return loadTimeFreeStationXml()->then(
		sub {
			my $ts_now   = time();
			my $stations = shift;    #ARRAY
			my $areaId   = shift;    #JP13, プレミアム=''

			my @items = map {
				+{
					title => localized(JA => $_->{name}, EN => $_->{ascii_name}),
					icon  => $_->{logo}->[0]->{content},
					items => _createWeekItems($_, $ts_now),
				};
			} @$stations;

			push @items, {
				title       => Slim::Utils::Strings::string('SEARCHFOR'),
				icon        => 'html/images/search.png',
				type        => 'search',
				url         => feedFromPromise(\&_loadSearchTimeFree),
				passthrough => [ $areaId, $stations ],
			};
			return \@items;
		}
	);
}

1;
