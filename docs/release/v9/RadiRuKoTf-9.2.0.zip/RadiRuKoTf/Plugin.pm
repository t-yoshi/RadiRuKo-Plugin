# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoTf::Plugin;

use v5.20;
use warnings;
use base qw(Slim::Plugin::OPMLBased);
use Slim::Player::ProtocolHandlers;
use Slim::Utils::Log;

use constant RADIRUKO_REQUIRED_VERSION => 9.2;

sub getDisplayName {'PLUGIN_RADIRUKO_TIMEFREE_NAME'}

sub initPlugin {
	my $class = shift;

	my $log = logger('plugin.radiruko');

	$log->info('RadiRuKo-TimeFree-Plugin v', $class->_pluginDataFor('version'));

	require Plugins::RadiRuKo::Utils;
	Plugins::RadiRuKo::Utils->VERSION(RADIRUKO_REQUIRED_VERSION);

	require Plugins::RadiRuKoTf::Feed;
	require Plugins::RadiRuKoTf::ProtocolHandler;
	require Plugins::RadiRuKo::RadikoMeta;

	$class->SUPER::initPlugin(
		tag    => 'RadiRuKoTf',
		menu   => 'radios',
		weight => 1.03,
		feed   => Plugins::RadiRuKo::Utils::feedFromPromise(\&Plugins::RadiRuKoTf::Feed::feedPromise),
	);

	Slim::Player::ProtocolHandlers->registerHandler(radikotf => q(Plugins::RadiRuKoTf::ProtocolHandler));
}

sub playerMenu {'RADIO'}

1;
