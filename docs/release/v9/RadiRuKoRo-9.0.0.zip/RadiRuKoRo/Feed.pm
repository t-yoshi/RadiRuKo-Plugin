# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoRo::Feed;
use utf8;
use strict;
use URI::Escape qw(uri_escape_utf8);
use Slim::Utils::Log;
use Plugins::RadiRuKo::Utils qw(
    AsyncHttp prettyTitle strWidth trimWidth
    parseDateTime feedFromPromise
);
use Tie::Cache::LRU;
use Data::Dumper;
use Promises::Tiny qw(resolved);

my $log = logger('plugin.radiruko');

sub _progTitle {
    my ($file, $headline, $progName) = @_;
    my $t = $headline or ($file->{aa_vinfo});

    if ($file->{file_title} && $headline ne $file->{file_title}) {
        $t .= ' ' . $file->{file_title};
    }

    $t =~ s/\s*番組を聴く$//;
    $t .= ' ' . $file->{file_title_sub} if defined $file->{file_title_sub};
    $t = prettyTitle($t, -1);

    my $w  = strWidth($t);
    my $re = sprintf('^\\s*%s\\s*', quotemeta($progName));
    $re =~ s/\\ /.?/;

    #$log->debug("$w: $t");
    if ($w > 160) {
        $t =~ s/$re//;
    } elsif ($w > 140) {
        $t =~ s/$re(?!選)//;
    }
    #$log->debug("$w: $re");
    #$log->debug("$w: $t");
    return trimWidth($t, 200);
}

sub _audioUrl ($@) {
    my $u = shift;
    my $f;
    while (my ($k, $v) = splice(@_, 0, 2)) {
        $f .= sprintf('%s=%s;', $k, uri_escape_utf8($v)) if $v =~ /\S/;
    }
    return "$u#$f?--";
}

sub _detailItems {
    my ($client, $args, $detailJsUrl, $progIcon) = @_;

    return AsyncHttp()->get($detailJsUrl)->then(
        sub {
            my $json     = shift;
            my $client   = shift;
            my $progIcon = shift;

            my $icon = $json->{main}{thumbnail_p} ||
                $json->{main}{thumbnail_c}        ||
                $progIcon                         ||
                'html/images/radio.png';
            my $progName = prettyTitle($json->{main}{program_name});

            #TODO: 番組開始順に並び替える
            my @detail_list =    #sort { $a->{headline_id} - $b->{headline_id} }
                @{ $json->{main}{detail_list} };

            my @items;
            for (@detail_list) {
                my $headline = $_->{headline};
                my $nFiles   = @{ $_->{file_list} };

                for (@{ $_->{file_list} }) {
                    my $u = $_->{file_name};
                    next unless $u;

                    $u =~ s/^https:/radiruod:/;
                    my $duration = '';

                    #STARTDATE_ENDDATE (番組の長さが不明な場合は9999年?)
                    if ($_->{aa_vinfo4} =~ /^(20.+)_(20.+)$/) {
                        $duration = parseDateTime($2) - parseDateTime($1);
                    }

                    my $line1 = _progTitle($_, $headline, $progName);
                    my $title = $line1;
                    $title .= sprintf(' [%s]', $_->{onair_date});
                    my $item = {
                        title => $title,
                        line1 => $line1,
                        line2 => $_->{onair_date},
                        icon  => $icon,
                        url   => _audioUrl(
                            $u,
                            duration => $duration,
                            title    => $line1,
                            icon     => $icon,
                            album    => $progName || $_->{official_url} || $_->{share_url},
                            artist   => prettyTitle($_->{file_title_sub}),
                        ),
                        type => 'audio',
                    };

                    push @items, $item;
                }
            }
            return \@items;
        }
    );
}

sub _sort_by_kana {
    return sort { $a->{program_name_kana} cmp $b->{program_name_kana} } @_;
}

sub _dataListItems {
    my $data_list = shift;
    my @items;
    my $now = time();

    for (_sort_by_kana(@$data_list)) {
        next if (!$_->{detail_json} || parseDateTime($_->{open_time}) > $now);

        my $line1 = prettyTitle($_->{program_name} . ' ' . $_->{corner_name});
        my $line2 = $_->{onair_date} if $_->{onair_date};
        my $title = $line2 ? "$line1 [$line2]" : $line1;

        my $item = {
            title       => $title,
            line1       => $line1,
            line2       => $line2,
            icon        => $_->{thumbnail_p},
            url         => feedFromPromise(\&_detailItems),
            passthrough => [ $_->{detail_json}, $_->{thumbnail_p} ],
        };
        push @items, $item;
    }

    return \@items;
}

tie my %sessionCache, 'Tie::Cache::LRU', 10;

sub feedPromise() {
    my ($client, $args, @passthrough) = @_;

    #らじるのメニューは頻繁に更新されるので
    # メニューをたどっているときに更新されると
    # ナビゲーションがおかしくなる
    my $item_id = $args->{params}{item_id} || $args->{params}{index};
    my ($cacheKey) = $item_id =~ /^(\w+)\./;
    if ($cacheKey && $sessionCache{_}) {
        $log->debug("Using cached items for [$cacheKey]");
        $sessionCache{$cacheKey} ||= $sessionCache{_};
        return resolved($sessionCache{$cacheKey});
    }

    my $u = 'https://www.nhk.or.jp/radioondemand/json/index_v3/index_genre.json';
    return AsyncHttp()->get($u)->then(
        sub {
            my $json      = shift;
            my @data_list = @{ $json->{genre_list} };
            my @items;

            for (@{ $json->{genre_list} }) {
                my $item = {
                    title => $_->{genre},
                    icon  => 'html/images/radio.png',
                    items => _dataListItems($_->{data_list}),
                };
                push @items, $item;
            }

            if (0) {
                #テスト用
                use List::Util;
                @items = List::Util::shuffle @items;
            }

            $sessionCache{_} = \@items;
            return \@items;
        },
    );

}

1;
