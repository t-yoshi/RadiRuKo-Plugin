# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadikoAuth;

use v5.20;
use warnings;
use utf8;
use Carp::Assert;
use Digest::MD5 qw(md5_hex);
use MIME::Base64;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Data::Dumper;

use Plugins::RadiRuKo::Utils qw(
  AsyncHttp isEnabledAreaFree
);
use Promises2 qw(deferred resolved rejected);

use Exporter 'import';
our @EXPORT_OK = qw(UA cookie_rdk_uid cookie_radiko_session);

use constant AUTH_KEY => 'bcd151073c03b352e1ef2fd66c32209da9ca0afa';
use constant UA       => 'Mozilla/5.0 like Gecko';

my $app_prefs = preferences('plugin.radiruko');
my $log       = Slim::Utils::Log::logger('plugin.radiruko');

use Slim::Networking::Async::HTTP;
my $jar = Slim::Networking::Async::HTTP::cookie_jar();

use constant CACHE_TTL => 600;

#キャッシュ  (authToken, areaId)
my $cache;
my $cache_expire;

sub _clear_cache() {
	$cache        = undef;
	$cache_expire = 0;
}

_clear_cache();

#
# 非同期でradiko認証を行う。
# 成功した場合、結果を10分間キャッシュする。
# options
#   mode:
#     'cache' 期限切れでもキャッシュを返す
#     'force' キャッシュを破棄
# 成功時:
#   resolved(authToken, areaId)
#
sub execute {
	my $class = shift;

	assert(@_ % 2 == 0);

	my %options = (
		mode => '',
		@_,
	);

	if ($options{mode} eq 'cache' && defined $cache) {
		return $cache;
	}

	my $now = time();

	if ($options{mode} eq 'force' || $now > $cache_expire) {
		_clear_cache();
	}

	if (defined $cache) {
		return $cache;
	}

	$cache_expire = $now + CACHE_TTL;
	$cache        = $class->checkLogin()->chain(\&_auth1, \&_auth2)->catch(
		sub {
			_clear_cache();
			return rejected(@_);
		}
	);
	return $cache;
}

my @defaultRequestHeaders = (
	'User-Agent' => UA,
	'pragma'     => 'no-cache',
	'Referer'    => 'https://radiko.jp/',
);

sub checkLogin() {
	my $class = shift;

	my $u = 'https://radiko.jp/ap/member/webapi/v2/member/login/check';
	return AsyncHttp()->get($u, @defaultRequestHeaders)->then(
		sub {
			my ($js) = @_;
			if (ref $js eq 'HASH' && $js->{status} == 200) {
				my $mt = $js->{member_type}{name};
				$log->debug('Login check: ', cookie_radiko_session(), ' ', $mt);
				return $mt;
			}
			return rejected('Login check failed: ' . $u);
		},
		sub {
			my ($err) = @_;
			if ($err =~ /^400\b/) {
				$log->debug('You are not logged in: ', cookie_radiko_session());
				return '(未ログイン)';
			}
			return rejected(@_);
		}
	);
}

my @radikoRequestHeaders = (
	'X-Radiko-App'         => 'pc_html5',
	'X-Radiko-App-Version' => '0.0.1',
	'X-Radiko-User'        => 'dummy_user',
	'X-Radiko-Device'      => 'pc',
);

sub _auth1 {
	$log->debug("auth1: Start");

	return AsyncHttp()->get(
		'https://radiko.jp/v2/api/auth1',
		@defaultRequestHeaders,
		@radikoRequestHeaders,
	)->then(
		sub {
			my ($payload, $http) = @_;
			my $headers = $http->headers;
			$log->debug("auth1: OK");

			return map { $headers->header($_); } qw(x-radiko-authtoken x-radiko-keyoffset x-radiko-keylength);
		}
	);
}

sub _auth2 {
	my ($authToken, $keyoffset, $keylength) = @_;

	$log->debug("auth2: Start");

	my $partKey = do {
		my $buf = substr(AUTH_KEY, $keyoffset, $keylength);
		MIME::Base64::encode_base64($buf, '');
	};

	return AsyncHttp()->get(
		'https://radiko.jp/v2/api/auth2',
		@defaultRequestHeaders,
		@radikoRequestHeaders,
		'X-Radiko-Authtoken'  => $authToken,
		'X-Radiko-Partialkey' => $partKey
	)->then(
		sub {
			my ($payload) = @_;
			$log->debug("auth2: OK");

			if ($payload =~ /(JP\d+)/) {
				my $areaId = $1;
				return ($authToken, $areaId);
			}
			return rejected('auth2 failed: Bad areaId');
		}
	);
}

use constant {
	RDK_UID_KEY           => 'rdk_uid',
	RADIKO_SESSION_KEY    => 'radiko_session',
	DEFAULT_COOKIE_EXPIRE => 365 * 24 * 60 * 60,
};

sub _radiko_set_cookie {
	my ($key, $value) = @_;
	$jar->set_cookie(
		undef, $key, $value,
		'/',   'radiko.jp',
		undef, undef, undef,
		DEFAULT_COOKIE_EXPIRE,
	);
	$jar->save();
}

sub cookie_rdk_uid () {
	my $rdk_uid = $jar->get_cookies('radiko.jp', RDK_UID_KEY);
	if (!$rdk_uid) {
		$rdk_uid = md5_hex(time());
		_radiko_set_cookie(RDK_UID_KEY, $rdk_uid);
	}
	return $rdk_uid;
}

cookie_rdk_uid();

sub cookie_radiko_session {
	if (@_ == 0) {
		return $jar->get_cookies('radiko.jp', RADIKO_SESSION_KEY);
	}

	assert(@_ == 1 && $_[0] =~ /^([\da-f]{40}|)$/);

	_radiko_set_cookie(RADIKO_SESSION_KEY, $_[0]);
	$log->debug('radiko_session has been changed: ', $_[0]);

	# 変更時にキャッシュをクリアする
	_clear_cache();
}

1;
