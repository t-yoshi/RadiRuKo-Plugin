# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruHandler;
#
# RADIRU URL protocol handler
#
#  radiru://Station[-Area]
#
#  Station:
#    AM, FM
#  Area:
#    Sendai, Tokyo, Nagoya, Osaka
#
#  See: http://www.nhk.or.jp/radio/config/config_web.xml
#
use v5.20;
use warnings;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Timers;
use Data::Dumper;

use Plugins::RadiRuKo::RadiruConfig;
use Plugins::RadiRuKo::Utils qw(RE_RADIRU_URL);

use Promises2 qw(rejected);

my $log       = logger('plugin.radiruko');
my $app_prefs = preferences('plugin.radiruko');

use base qw(Plugins::RadiRuKo::BaseFFMpegHandler);

sub new {
	my $class = shift;
	my ($args) = @_;

	my $song       = $args->{song};
	my $stream_url = $song->pluginData('stream_url') // return;

	return $class->SUPER::new(
		$args, $stream_url,
	);
}

sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $client = $song->master();
	my $url    = $song->track()->url;

	my ($channel, $area) = $url =~ RE_RADIRU_URL or return do {
		my $error = "Invalid URL: $url";
		$log->error($error);
		$errorCb->($error);
	};
	$area ||= 'tokyo';

	Plugins::RadiRuKo::RadiruConfig->load()->then(
		sub {
			my ($config) = @_;
			my $data = $config->find_by_area(area => $area) || return rejected("area: '$area' not found.");

			return $data->get({ AM => 'r1hls', FM => 'fmhls' }->{$channel});
		}
	)->done(
		sub {
			$song->pluginData({ stream_url => $_[0] });
			$successCb->();
		},
		sub {
			$log->error($_[0]);
			$errorCb->($_[0]);
		}
	);
}

sub getFormatForURL {'aac'}

1;
