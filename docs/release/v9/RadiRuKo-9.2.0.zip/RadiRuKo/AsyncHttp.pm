# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::AsyncHttp;

use v5.20;
use warnings;
use Carp::Assert               qw(assert);
use JSON::XS::VersionOneAndTwo qw(from_json);
use List::Util                 qw(min);
use Scalar::Util               qw(looks_like_number);
use Tie::RegexpHash;
use XML::Simple;
use Slim::Networking::SimpleAsyncHTTP;
use Slim::Utils::Log;
use Promises2 qw(deferred resolved rejected);
use Data::Dumper;

my $log = logger('plugin.radiruko');

tie my %defaultParsers, 'Tie::RegexpHash';

#
# AsyncHttp(cache => 1, expires => 60) or AsyncHttp(cache => '3 days, no-revalidate')
#  ->parser(func)
#  ->get(url, header => value, ...)
#

sub _canonicalize_expires {
	my $s = shift;
	return $1         if $s =~ /^(\d+)(\s*sec(onds?)?)?$/;
	return $1 * 60    if $s =~ /^(\d+)\s*min(s|utes?)?/;
	return $1 * 3600  if $s =~ /^(\d+)\s*hours?/;
	return $1 * 86400 if $s =~ /^(\d+)\s*days?/;

	$log->error("Invalid expire: $s");
	return 10 * 60;
}

sub new {
	my $class = shift;
	assert(@_ % 2 == 0);
	my %params = @_;

	my $norevalidate = 0;    #Max-Ageなど無視

	if (defined $params{expires}) {
		$params{expires} = _canonicalize_expires($params{expires});
	} elsif ($params{cache} && $params{cache} ne '1') {
		$params{expires} = _canonicalize_expires($params{cache});
		$norevalidate    = $params{cache} =~ /\bno-?revalidate\b/;
		$params{cache}   = 1;
	}

	#最大10日間キャッシュ可能とする
	my $override_cache_expires = looks_like_number($params{expires}) && $params{expires} > 86400;
	if ($override_cache_expires) {
		$params{expires} = min($params{expires}, 864000);
	}

	my $deferred = deferred();

	my $shttp = Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my ($http) = @_;
			#SimpleAsyncHTTPの最大キャッシュ時間は1日だが
			# 少なすぎるので拡張する
			if ($params{cache} &&
				($override_cache_expires || $norevalidate) &&
				!$http->cachedResponse)
			{
				$log->debug(
					sprintf(
						'Override cache expires(%s) or no-revalidate(%s) : %s',
						$params{expires}, $norevalidate, $http->url
					)
				);
				$http->cacheResponse($params{expires}, $norevalidate, $params{client});
			}
			$deferred->resolve($http->content, $http);
		},
		sub {
			my ($http, $err, $res) = @_;

			## $log->debug(Dumper $res);
			$http->code($res->code);
			$http->mess($res->message);
			# $http->headers($res->headers);

			$deferred->reject($err, $http);
		},
		\%params,
	);

	return bless {
		deferred => $deferred,
		http     => $shttp,
		parser   => undef,
	}, $class;
}

sub parser {
	my ($self, $parser) = @_;
	assert(!defined $parser || ref $parser eq 'CODE');

	$self->{parser} = $parser;
	return $self;
}

sub json {
	my $self = shift;
	return $self->parser($defaultParsers{'application/json'});
}

sub xml {
	my $self = shift;
	return $self->parser($defaultParsers{'application/xml'});
}

$defaultParsers{qr{^(application|text)/xml\b}i} = sub {
	my ($payload, $http) = @_;
	my %params = (
		ForceArray    => 0,
		KeyAttr       => [],
		SuppressEmpty => '',
	);
	return XMLin($payload, %params);
};

$defaultParsers{qr{^(application|text)/json\b}i} = sub {
	my ($payload, $http) = @_;
	return from_json($payload);
};

sub _parse {
	my $self = shift;

	return $self->{deferred}->then(
		sub {
			my ($payload, $http) = @_;
			my $ct = $http->headers->content_type;
			my $pr = $self->{parser} // $defaultParsers{$ct};
			if (defined $pr) {
				$payload = eval { $pr->($payload, $http) };
				return rejected($@, $http) if $@;
			}
			return resolved($payload, $http);
		}
	);
}

sub get {
	my $self = shift;
	$self->{http}->get(@_);
	return $self->_parse();
}

sub post {
	my $self = shift;
	$self->{http}->post(@_);
	return $self->_parse();
}

sub put {
	my $self = shift;
	$self->{http}->put(@_);
	return $self->_parse();
}

sub head {
	my $self = shift;
	$self->{http}->head(@_);
	return $self->_parse();
}

1;
