# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruMeta;

use v5.20;
use warnings;
use utf8;
use Carp::Assert;
use List::Util qw(first);
use Slim::Utils::DateTime;
use Slim::Utils::Log;
use Plugins::RadiRuKo::Utils qw(
  AsyncHttp formatTitle RE_RADIRU_URL
  parseDateTime lstring
);
use Promises2 qw(collect resolved rejected);
use Plugins::RadiRuKo::MetadataHandler;
use Plugins::RadiRuKo::RadiruConfig;
use Data::Dumper;

my $log = logger('plugin.radiruko');

# URL:
#  radiru://Station[-Area]
#
#  Station:
#    AM, FM
#  Area:
#    Sendai, Tokyo, Nagoya, Osaka, ...
#

sub _DEBUG() { 1 && $log->is_debug; }

sub _fetchMetadata {
	my ($handler, $client, $url) = @_;

	my ($channel, $area) = $url =~ RE_RADIRU_URL;
	$area ||= 'tokyo';

	return Plugins::RadiRuKo::RadiruConfig->load()->then(
		sub {
			my ($config) = @_;
			$log->debug(Dumper $config) if _DEBUG;

			my $data = $config->find_by_area(area => $area);
			return defined $data ? $data : rejected("'$area' is not found");
		}
	)->then(
		sub {
			my ($data) = @_;

			my $chName = lstring(
				"PLUGIN_RADIRUKO_NHK_${channel}",
				JA => $data->areajp,
				EN => ucfirst($data->area),
			);

			return collect(
				resolved($chName),
				AsyncHttp()->get($data->url_program_noa)
			);
		}
	)->then(
		sub {
			my ($chName) = @{ $_[0] };
			my ($js)     = @{ $_[1] };

			assert(ref $js eq 'HASH');

			my $ch  = $js->{ { AM => 'r1', FM => 'r3' }->{$channel} };
			my $now = time();

			$log->debug(Dumper $ch) if _DEBUG;

			#放送中 or 次番組(放送休止中のとき)
			my $prog = first { $now < parseDateTime($_->{endDate}) } @{ $ch->{publication} // [] };
			return +{} unless defined $prog;

			my $meta = _build_metadata($chName, $prog, $now);
			$meta->{cover} //= "plugins/RadiRuKo/html/images/NHK_$channel.png";
			return $meta;
		}
	);
}

sub _build_metadata {
	my ($chName, $prog, $now) = @_;

	my $start = parseDateTime($prog->{startDate});
	my $end   = parseDateTime($prog->{endDate});

	my ($title, $expires);

	if ($now >= $start) {
		#放送中
		$title = $chName . ' - ' . $prog->{name};
		#番組終了時に更新させる
		$expires = $end;
	} else {
		#放送休止中
		$title = sprintf(
			'%s [%s～]%s',
			$chName,
			Slim::Utils::DateTime::timeF($start, '%k:%M', 0),
			$prog->{name}
		);
		#放送開始時に更新させる
		$expires = $start;
	}

	my @actList     = map { $_->{name} } @{ $prog->{misc}{actList} };
	my $description = $prog->{description};
	my @musicList   = map { $_->{name} } @{ $prog->{misc}{musicList} };

	return {
		title  => formatTitle($title),
		artist => formatTitle([@actList]),
		album  => formatTitle([ $description, @musicList ]),
		cover  => $prog->{about}{partOfSeries}{logo}{medium}{url} //
		  $prog->{about}{partOfSeries}{logo}{main}{url},
		expires => $expires,
	};
}

Plugins::RadiRuKo::MetadataHandler->registerAsyncMetaProvider(
	match => RE_RADIRU_URL,
	func  => \&_fetchMetadata,
);

1;
