# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadikoFeed;

use v5.20;
use warnings;
use utf8;
use Carp::Assert qw(assert);
use Digest::MD5  qw(md5_hex);
use List::Util   qw(first);
use POSIX        qw(strftime);
use Time::HiRes q(time);
use URI;
use URI::QueryParam;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Promises2 qw(rejected);
use Data::Dumper;
use Plugins::RadiRuKo::Utils qw(
  AsyncHttp isEnabledAreaFree
  jptime parseDateTime jpShortDateTimeF
);
use Plugins::RadiRuKo::RadikoAuth;

use Exporter 'import';
our @EXPORT_OK = qw(
  loadProgramXml loadAreaFreeStationXml
  loadAreaFreeStationXml loadTimeFreeStationXml
  loadStationXml loadNowProgramXml searchWordJson
  PROGRAM_DAY_OFFSET
);

our $VERSION = 9.0;

my $log       = logger('plugin.radiruko');
my $app_prefs = preferences('plugin.radiruko');

#朝5時更新
use constant PROGRAM_DAY_OFFSET => 5 * 60 * 60;

#
# 番組表のXMLを取得する。
#  stationId:
#  [time]: 過去の番組表(エポック時間)
#
# resolve: ($xml, 今または指定時刻の<prog>)
#
sub loadProgramXml {
	my ($stationId, $time) = @_;

	my $now = time();
	$time //= $now;

	assert($stationId);
	assert($time > 0);

	my $date = strftime('%Y%m%d', jptime($time - PROGRAM_DAY_OFFSET));

	my $u = "https://radiko.jp/v3/program/station/date/$date/$stationId.xml";    #FMJ

	my $expires = $time == $now ? '2 hour' : '8 days';

	return AsyncHttp(cache => $expires)->get($u)->then(
		sub {
			my ($xml) = @_;
			my $station = $xml->{stations}{station};

			#いま放送中/指定時刻の<prog>
			my $prog = _findProg($station, $time);

			return ($xml, $prog);
		}
	);
}

#
# 現在の番組表のXMLを取得する。
# areaId
#
# resolve: ({ stationId => 今の<prog>, ... })
#
sub loadNowProgramXml {
	my ($areaId) = @_;

	$areaId ||= 'ALL';

	my $u   = "https://radiko.jp/v3/program/now/$areaId.xml";
	my $now = time();

	return AsyncHttp(cache => '1 hour')->get($u)->then(
		sub {
			my ($xml) = @_;
			return +{ map { ($_->{id} => _findProg($_, $now)) } @{ $xml->{stations}{station} } };
		}
	);
}

#いま放送中/指定時刻の<prog>
sub _findProg {
	my ($station, $time) = @_;

	return first {    #
		$time >= parseDateTime($_->{ft}) && parseDateTime($_->{to}) > $time
	} @{ $station->{progs}{prog} };
}

sub _filter_nhk_station {
	return $_[0] if $app_prefs->get('enable_radiko_nhk');
	return [ grep { $_->{name} !~ /^NHK/ } @{ $_[0] } ];
}

#
# エリアフリー対応局を返す
# resolve: ([<station>, ..])
#
sub loadAreaFreeStationXml() {
	return AsyncHttp(cache => '1 day')->get('https://radiko.jp/v3/station/region/full.xml')->then(
		sub {
			my ($xml) = @_;
			my $stations = [ map { @{ $_->{station} } } @{ $xml->{stations} } ];
			$stations = _filter_nhk_station($stations);
			return [ grep { $_->{areafree} != 0 } @$stations ];
		}
	);
}

#
# タイムフリー対応局を返す
# resolve: ([<station>, ..], '')
#
sub loadTimeFreeStationXml() {
	my $p = isEnabledAreaFree() ? loadAreaFreeStationXml() : loadStationXml();
	return $p->then(
		sub {
			my $stations = [ grep { $_->{timefree} != 0 } @{ $_[0] } ];
			return ($stations, '');
		}
	);
}

#
# ローカルエリアの局を返す
# resolve: ([<station>, ..], areaId)
#
sub loadStationXml() {
	return Plugins::RadiRuKo::RadikoAuth->execute(mode => 'cache')->then(
		sub {
			my (undef, $areaId) = @_;
			my $u = "https://radiko.jp/v3/station/list/${areaId}.xml";
			return AsyncHttp(cache => '1 day')->get($u);
		}
	)->then(
		sub {
			my $stations = $_[0]->{station};
			$stations = _filter_nhk_station($stations);
			return ($stations, $_[0]->{area_id});
		}
	);
}

sub searchWordJson {
	my ($areaId, $query, $page, $rowLimit) = @_;

	$page     ||= 0;
	$rowLimit ||= 50;

	assert($areaId eq '' || $areaId =~ /^JP\d\d?$/);
	assert($page >= 0);
	assert($rowLimit > 0);

	return rejected('empty query string.') if $query eq '';

	my $regionId = isEnabledAreaFree() ? 'all' : '';
	my $uid      = Plugins::RadiRuKo::RadikoAuth::cookie_rdk_uid();

	utf8::encode($query) if utf8::is_utf8($query);

	my $u = URI->new('https://radiko.jp/v3/api/program/search');
	$u->query_form(
		key         => $query,
		filter      => 'past',  start_day => '',
		end_day     => '',      uid       => $uid,
		area_id     => $areaId, region_id => $regionId,
		cul_area_id => $areaId, page_idx  => $page,
		app_id      => 'pc',    row_limit => $rowLimit,
	);

	return AsyncHttp()->get($u);
}

my $lsid = md5_hex(time());

sub _eqv { !($_[0] xor $_[1]) }

sub loadPlaylist {
	my ($stationId, $isAreaFree, $isTimeFree) = @_;

	assert($stationId);

	return AsyncHttp()->get("https://radiko.jp/v3/station/stream/pc_html5/${stationId}.xml")->then(
		sub {
			my ($xml) = @_;
			$log->debug(Dumper $xml) if $log->is_debug;

			for (@{ $xml->{url} }) {
				my $u = $_->{playlist_create_url} // '';
				if ($u =~ /^https?:/ &&
					_eqv($_->{areafree}, $isAreaFree) &&
					_eqv($_->{timefree}, $isTimeFree))
				{
					$u = URI->new($u);
					$u->query_form(
						station_id => $stationId,
						# バッファ時間 5 - 300秒 (通常15秒)
						l    => $isTimeFree ? 30 : 15,
						lsid => $lsid,
						type => 'c',
					);
					return $u;
				}
			}
			return rejected("${stationId}'s playlist is not found.");
		}
	);
}

1;
