# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruConfig;

use v5.20;
use warnings;
use utf8;
use Carp::Assert;
use List::Util qw(first);
use URI;
use Slim::Utils::Log;
use Plugins::RadiRuKo::Utils qw(AsyncHttp);
use Data::Dumper;

use constant CONFIG_URL => 'https://www.nhk.or.jp/radio/config/config_web.xml';

my $log = logger('plugin.radiruko');

sub load {
	my $class = shift;

	return AsyncHttp(cache => 1)->get(CONFIG_URL)->then(sub { $class->_new($_[0]) });
}

{

	package Plugins::RadiRuKo::RadiruConfig::Data;

	use base qw(Class::Accessor::Fast);

	__PACKAGE__->mk_ro_accessors(
		qw(
		  areajp area apikey areakey
		  r1hls r2hls fmhls
		  url_program_noa
		)
	);

}

sub _new {
	my $class = shift;
	my ($config) = @_;

	assert(ref $config eq 'HASH');

	my @data = map {
		Plugins::RadiRuKo::RadiruConfig::Data->new({
				%$_,
				url_program_noa => _build_url(
					$config->{url_program_noa}, area => $_->{areakey},
				),
			}
		);
	} @{ $config->{stream_url}{data} };

	return bless \@data, $class;
}

#全体を返す。
sub all() {
	my $self = shift;
	return @$self;
}

#
# find_by_area(areajp => '東京'), find_by_area(area => 'Tokyo')
#
sub find_by_area {
	my $self = shift;

	assert(@_ == 2);
	my ($key, $val) = @_;

	assert($key =~ /^area(|jp|key)$/, "Invalid key: $key");

	return first { lc $_->get($key) eq lc $val } $self->all;
}

sub _build_url {
	my ($url, %params) = @_;

	while (my ($k, $v) = each(%params)) {
		$url =~ s/\{$k\}/$v/g;
	}

	return URI->new_abs($url, CONFIG_URL)->as_string;
}

1;
