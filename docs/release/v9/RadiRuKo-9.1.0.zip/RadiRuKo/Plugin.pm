# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKo::Plugin;

use v5.20;
use warnings;

use base qw(Slim::Plugin::OPMLBased);
use Slim::Utils::Log;
use Slim::Utils::Misc();
use Slim::Utils::OSDetect;
use Slim::Utils::Prefs;
use Slim::Utils::Timers;
use Plugins::RadiRuKo::SimulMeta;

BEGIN {
	use Slim::Networking::Async::HTTP;

	Slim::Networking::Async::HTTP::hasSSL() || die "Require IO::Socket::SSL\n";
}

use Plugins::RadiRuKo::Utils 9.1 qw(
  feedFromPromise
);
use Plugins::RadiRuKo::FFMpegHandler;
use Plugins::RadiRuKo::Feed;
use Plugins::RadiRuKo::FmppClient;
use Plugins::RadiRuKo::FmppDecodeHandler;
use Plugins::RadiRuKo::RadikoHandler;
use Plugins::RadiRuKo::RadikoMeta;
use Plugins::RadiRuKo::RadiruConfig;
use Plugins::RadiRuKo::RadiruHandler;
use Plugins::RadiRuKo::RadiruMeta;
use Plugins::RadiRuKo::Settings;

my $app_prefs = preferences('plugin.radiruko');
# create log categogy before loading other modules
my $log = Slim::Utils::Log->addLogCategory({
		category     => 'plugin.radiruko',
		defaultLevel => 'INFO',
		description  => getDisplayName(),
	}
);

sub getDisplayName {'PLUGIN_RADIRUKO_NAME'}

sub initPlugin {
	my $class = shift;

	$log->info('RadiRuKo-Plugin v' . $class->_pluginDataFor('version'));

	$class->SUPER::initPlugin(
		tag    => 'RadiRuKo',
		menu   => 'radios',
		weight => 1.01,
		feed   => feedFromPromise(\&Plugins::RadiRuKo::Feed::feedPromise),
	);

	Slim::Player::ProtocolHandlers->registerHandler(ffmpegpcm => q(Plugins::RadiRuKo::FFMpegHandler));
	Slim::Player::ProtocolHandlers->registerHandler(ffmpegaac => q(Plugins::RadiRuKo::FFMpegHandler));

	Slim::Player::ProtocolHandlers->registerHandler(radiko => q(Plugins::RadiRuKo::RadikoHandler));
	Slim::Player::ProtocolHandlers->registerHandler(radiru => q(Plugins::RadiRuKo::RadiruHandler));

	my $wsHandler =
	  #q(Plugins::RadiRuKo::FmppClient) #soxデコード
	  q(Plugins::RadiRuKo::FmppDecodeHandler)    #ffmpegデコード
	  ;
	Slim::Player::ProtocolHandlers->registerHandler(fmpp => $wsHandler);
	Slim::Player::ProtocolHandlers->registerHandler(jcba => $wsHandler);

	Plugins::RadiRuKo::Settings->new();

	if ($log->is_debug) {
		require Promises2;
		Promises2->rejected('This is a test for unhandled reject.');
	}
}

sub playerMenu {'RADIO'}

1;
