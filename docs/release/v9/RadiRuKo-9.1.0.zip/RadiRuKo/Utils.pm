# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::Utils;

use v5.20;
use warnings;
use Carp::Assert qw(assert);
use Date::Parse;
use HTML::Entities qw(decode_entities);
use POSIX          qw(strftime);
use Scalar::Util   qw(blessed);
use Time::HiRes    qw(time);
use Time::Local;
use Time::Zone;
use Slim::Music::Info;
use Slim::Utils::Cache;
use Slim::Utils::Log;
use Slim::Utils::Misc();
use Slim::Utils::Prefs;
use Slim::Utils::Strings  qw(string);
use Text::VisualWidth::PP qw(vwidth vtrim);
use Plugins::RadiRuKo::AsyncHttp;
use Data::Dumper;

our $VERSION = 9.1;

use Exporter 'import';

our @EXPORT_OK = qw(
  RE_RADIRU_URL
  RE_RADIKO_URL
  RE_RADIKO_TF_URL

  AsyncHttp formatTitle

  strWidth trimWidth
  jptime parseDateTime jpShortDateTimeF
  isEnabledAreaFree

  localized localizedString
  feedFromPromise
);

use constant {
	#(radikoId) p=プレミアム
	RE_RADIKO_URL => qr'^radikop?://([A-Z\d]+[\-_]?[A-Z\d]+)',

	#(radikoId, startTime, endTime)
	RE_RADIKO_TF_URL => qr'^radikotf://([A-Z\d]+[\-_]?[A-Z\d]+)/(\d{14})-(\d{14})',

	#(channel, area)
	RE_RADIRU_URL => qr'^radiru://(R1|R2|FM)(?:-([A-Z][a-z]+))?$',
};

my $log = logger('plugin.radiruko');

sub AsyncHttp { Plugins::RadiRuKo::AsyncHttp->new(@_) }

sub strWidth {
	local $Text::VisualWidth::PP::EastAsian = 1;
	return vwidth($_[0]);
}

#
# 文字列を後略する。
#
sub trimWidth {
	my $s        = shift;
	my $maxWidth = shift || 200;    #半角換算の文字幅

	return '' if (!defined $s || $s eq '');

	my $origLen = length($s);
	$s = vtrim($s, $maxWidth);
	$s .= "..." if (length($s) + 3 < $origLen);
	return $s;
}

sub formatTitle {
	my $s = shift;
	assert(@_ % 2 == 0);
	my %params = (
		maxWidth  => 200,     #半角換算の文字幅
		stripHtml => undef,
		@_,
	);

	return '' if (!defined $s || $s eq '');

	if (ref $s eq 'ARRAY') {
		#配列なら結合する
		$s = join(' ', grep { defined $_ } @$s);
	}

	$params{stripHtml} //= $s =~ m{</?[a-z]\w*>}i;
	if ($params{stripHtml}) {
		# HTMLタグを除去する。
		$s =~ s/<[^>]+>/ /g;
		#$s = HTML::TreeBuilder->new_from_content($s)->as_trimmed_text;
		$s = decode_entities($s);
	}

	#空白から}まで半角にする。
	$s =~ tr/\x{ff00}-\x{ff5d}/\x{0020}-\x{007d}/;

	$s =~ s/\s+/ /g;
	$s =~ s/^\s+//;
	$s =~ s/\s+$//;

	$s = trimWidth($s, $params{maxWidth});

	return $s;
}

sub jptime {
	my $t = shift || time();
	return gmtime($t + tz_offset('JST'));
}

#
# 日時の文字列をエポック秒に変換する
#   ex. '2004-04-01T12:00+09:00' -> 1080788400
#
sub parseDateTime {
	my $s = shift || return 0;

	#radiko形式 '20160910151500' -> '20160910T151500'
	$s =~ s/^(20\d{6})(\d{4,}.*)$/$1T$2/;

	my @tm = strptime($s, 'JST');
	return timegm(@tm) - $tm[6] if scalar @tm;
}

# ex '8/31 12:34'
sub jpShortDateTimeF {
	my @tm = jptime(shift);

	my $serverPrefs = preferences('server');
	my $dateFormat  = $serverPrefs->get('shortdateFormat');
	my $timeFormat  = $serverPrefs->get('timeFormat');
	$dateFormat =~ s=\W*%[yY][^%]*==;                #年は省略
	$dateFormat =~ s=(?<!\|)%m([\.\-/]%d)=|%m$1=;    #月の0を除く 08 -> 8
													 #$log->info("$dateFormat $timeFormat");

	my $date = strftime("$dateFormat $timeFormat", @tm);
	$date =~ s/\|0*//g;                              #see DateTime.pm
	return Slim::Utils::Unicode::utf8decode_locale($date);
}

sub isEnabledAreaFree() {
	return !!Slim::Utils::PluginManager->isEnabled('Plugins::RadiRuKoPr::Plugin');
}

# localized(JA=>$ja, EN=>$en) -> $ja | $en
sub localized {
	my $hash = ref($_[0]) eq 'HASH' ? $_[0] : {@_};
	my $lang = Slim::Utils::Strings::getLanguage();
	my $a    = $hash->{$lang} // $hash->{EN} // $hash->{''} // [];
	#$log->debug(Dumper $hash, $lang, $a);
	return ref($a) eq 'ARRAY' ? @$a : ($a,) if wantarray;
	return $a;
}

# localizedString($token, JA=>[...], EN=>[...])
#
sub localizedString {
	my $token = shift;
	return string($token) if @_ == 0;
	return string($token, localized(@_));
}

sub _copyMenuItems {
	return [ map { +{%$_} } @{ $_[0] } ];
}

sub feedFromPromise {
	my $promise = shift;
	assert(ref($promise) =~ /^(Promise|CODE)/);

	return sub {
		my ($client, $callback, $args, @passthrough) = @_;
		assert(ref $callback eq 'CODE');

		my $p = ref $promise eq 'CODE' ? $promise->($client, $args, @passthrough) : $promise;

		$p->done(
			sub {
				my $items = shift;

				#hashにinsertLinkなどが勝手に追加されてしまうので
				#deep copyは必要
				if (ref $items eq 'HASH') {
					$items->{items} = _copyMenuItems $items->{items};
				} elsif (ref $items eq 'ARRAY') {
					$items = _copyMenuItems $items;
				} else {
					$log->logdie('items need as HASH or ARRAY.');
				}
				$callback->($items);
			},
			sub {
				my $error = shift;

				$log->error("Feed error: $error");

				$callback->(
					[ {
							title => "$error",
							items => [],
						}
					]
				);
			}
		);

		return;
	};
}

1;
