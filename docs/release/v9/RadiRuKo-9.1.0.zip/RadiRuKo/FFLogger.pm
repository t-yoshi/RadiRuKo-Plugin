# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::FFLogger;

use v5.20;
use warnings;
use Carp::Assert;
use File::Temp qw(tempfile);
use FileHandle;
use List::Util qw(first);
use Time::HiRes q(time);
use Slim::Utils::Log;
use Slim::Utils::Misc();
use File::Monitor;
use Data::Dumper;

my $log = Slim::Utils::Log->addLogCategory({
		category     => 'plugin.radiruko.ffmpeg',
		defaultLevel => 'ERROR',
		description  => 'PLUGIN_RADIRUKO_FFMPEG',
	}
);

use constant INTERVAL => 5;

my $monitor = File::Monitor->new();

sub new {
	my $class = shift;

	my $logDir = Slim::Utils::Misc::getTempDir();
	my (undef, $f) = tempfile('fflog-XXXXXX', DIR => $logDir, SUFFIX => '.log', OPEN => 0);

	my $self = bless {
		ffLogfile  => $f,
		isWatching => 0,
	}, $class;

	$self->_start();

	return $self;
}

sub fflog_options {
	my $self = shift;
	return qw(-nostats -loglevel level);
}

sub _start {
	my $self = shift;
	return if ($self->{isWatching});
	$self->{isWatching} = 1;

	$log->debug('watch: ' . $self->{ffLogfile});
	$monitor->watch($self->{ffLogfile});

	my $class = ref $self;
	Slim::Utils::Timers::killTimers($class, \&_do_watchdog);
	$class->_do_watchdog();
}

sub _remove_logfile {
	my $self = shift;
	unlink($self->{ffLogfile}) or $log->error($!);
}

sub stop {
	my $self = shift;
	return unless ($self->{isWatching});
	$self->{isWatching} = 0;

	$log->debug('unwatch: ' . $self->{ffLogfile});
	$monitor->unwatch($self->{ffLogfile});

	#Windowsではプロセス終了までラグがある
	my $n = main::ISWINDOWS ? 10 : 0;
	Slim::Utils::Timers::setTimer($self, time() + $n, \&_remove_logfile);
}

sub stopAfter {
	my $self  = shift;
	my $delay = shift;
	assert($delay > 0);
	Slim::Utils::Timers::setTimer($self, time() + $delay, \&stop);
}

sub _ffreport_error_level () {
	return 48 if $log->is_debug;
	return 32;
}

#
#環境変数FFREPORTの値
#
sub ffreport_environment_value {
	my $self = shift;
	my $f    = $self->{ffLogfile};
	$f =~ s/([:\\])/\\$1/g;    #escape :\
	$f =~ s/%/%%/g;            #escape %

	my $lv = _ffreport_error_level();

	return "file=$f:level=$lv";
}

sub _parseStreamInfoLines {
	my $lines   = shift;
	my $streams = {
		Metadata => {},
	};

	my $stream_index;
	my $meta_indent;

	for (@$lines) {
		if (/^\s{2,4}(Stream (#0:\d+).* Audio: .+)$/) {
			$stream_index = $2;
			$meta_indent  = undef;
			my $s = $1;
			my $audio_format;
			if ($s =~ m{ Audio:\s+(\w+) *(?:\(([\w-]+)\))?}) {
				$audio_format = $2 ? "$1/$2" : $1;
			}
			my ($sample_rate) = $s =~ m{ (\d{4,}) Hz};
			my ($bitrate_kbs) = $s =~ m{ (\d+) kb/s};

			$streams->{$stream_index} = {
				audio_format => $audio_format,
				sample_rate  => $sample_rate,
				bitrate      => $bitrate_kbs ? $bitrate_kbs * 1000 : undef,
				Metadata     => {},
			};
		} else {
			if (defined $meta_indent) {
				if (/^\s{$meta_indent}([\w\.]+)\s*:\s+(.+?)\s*$/) {
					my $h = defined $stream_index ? $streams->{$stream_index} : $streams;
					$h->{Metadata}{$1} = $2;
				} else {
					$meta_indent = undef;
				}
			} else {
				#Input #0
				#  Metadata:
				# or
				#  Stream #0:0:
				#    Metadata:
				my $n = defined $stream_index ? '4,6' : '2';
				if (/^(\s{$n})Metadata:/) {
					$meta_indent = length($1) + 2;
				}
			}
		}
	}

	return $streams;
}

sub _parseMappingLines {
	my $lines = shift;
	for (@$lines) {
		if (/Stream (#0:\d+) -> #0:0/) {
			return $1;
		}
	}
}

=pod
ストリーム情報を解析する
{
    'Selected' => '#0:0', #選択されたInput Stream
    'Input'    => {
        'Metadata' => { 'variant_bitrate' => '48676' },
        '#0:0'     => {
            'bitrate'      => 47000,
            'sample_rate'  => '48000',
            'audio_format' => 'aac (HE-AAC)',
            'Metadata'     => {
                'id3v2_priv.com.apple.streaming.transportStreamTimestamp' => '\\x00\\x00\\x00\\x01\\xea]\\x87\\x00',
                'variant_bitrate' => '48676'
            } }
    },
    'Output' => {
        'Metadata' => { 'encoder' => 'Lavf59.27.100' },
        '#0:0'     => {
            'bitrate'      => 47000,
            'sample_rate'  => '48000',
            'audio_format' => 'aac (HE-AAC)',
            'Metadata'     => {
                'id3v2_priv.com.apple.streaming.transportStreamTimestamp' =>
                    '\\x00\\x00\\x00\\x01\\xea]\\x87\\x00',
                'variant_bitrate' => '48676'
            } 
        }
    }
};
=cut

sub parseStreamInfo {
	my $self = shift;

	my %parsers = (
		Input    => [ qr{^Input #0,},       \&_parseStreamInfoLines ],
		Output   => [ qr{^Output #0,},      \&_parseStreamInfoLines ],
		Selected => [ qr{^Stream mapping:}, \&_parseMappingLines ],
	);

	my $fh = FileHandle->new($self->{ffLogfile}, '<:utf8') or do {
		logError("Couldn't open: $self->{ffLogfile}");
		return;
	};

	my %lines   = (_ => []);
	my $maxLine = 1024;
	while (my $line = $fh->getline() and $maxLine-- > 0) {
		#-loglevel levelのとき
		$line =~ s/^\[info\] //;

		if (my $k = first { $line =~ $parsers{$_}->[0] } keys %parsers) {
			$lines{_} = $lines{$k} = [];
		} else {
			push @{ $lines{_} }, $line;
		}
	}

	my $streamInfo = {};
	for my $k (keys %parsers) {
		my $func = $parsers{$k}->[1];
		$streamInfo->{$k} = $func->($lines{$k} // []);
	}

	$log->debug(Dumper $streamInfo) if $log->is_debug;

	return $streamInfo;
}

sub _read_log {
	my $fh = shift;
	my $lv = 'info';

	while (my $line = $fh->getline()) {
		if ($line =~ s/\[(debug|verbose|warning|info|error|fatal)\]\s//) {
			$lv = {
				warning => 'warn',
				verbose => 'debug',
			}->{$1} || $1;
		}
		$log->$lv($line);
	}
}

sub _do_watchdog {
	my $class = shift;

	for my $dt ($monitor->scan()) {
		next if ($dt->size == 0);

		$log->info('fflog has been changed: ' . $dt->name);

		my $fh = FileHandle->new($dt->name, '<:utf8') or do {
			logError('Could not open: ' . $dt->name);
			next;
		};

		if ($dt->is_created) {
			while (my $line = $fh->getline()) {
				last if $line =~ /^Command line:/;
			}
		} else {
			$fh->seek($dt->old_size, 0);
		}

		_read_log($fh);
	}

	if ($monitor->has_monitors) {
		Slim::Utils::Timers::setTimer($class, time() + INTERVAL, __SUB__);
	} else {
		$log->debug('leave watchdog');
	}
}

1;
