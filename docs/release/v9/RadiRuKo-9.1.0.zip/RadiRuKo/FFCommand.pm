# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::FFCommand;

use v5.20;
use warnings;
use Carp::Assert;
use Slim::Utils::Log;
use Slim::Utils::Misc();

my $log = logger('plugin.radiruko');

sub new {
	my $class = shift;
	my $input = shift;

	assert($input);

	my $ffmpeg = _find_ffmpeg() || return;
	return bless {
		_ffmpeg         => $ffmpeg,
		_input_options  => [qw/-hide_banner -nostdin/],
		_input          => $input,
		_output_options => [],
		_output         => 'pipe:',
	}, $class;
}

sub _find_ffmpeg {
	my $path = Slim::Utils::Misc::findbin('ffmpeg_bin') ||
	  Slim::Utils::Misc::findbin('ffmpeg7') ||
	  Slim::Utils::Misc::findbin('ffmpeg');

	$log->fatal('Please install ffmpeg') unless $path;

	return $path;
}

sub with_input_options {
	my $self = shift;
	push @{ $self->{_input_options} }, @_;
	return $self;
}

sub with_output_options {
	my $self = shift;
	push @{ $self->{_output_options} }, @_;
	return $self;
}

#コマンド引数をエスケープする
sub _escapeCommands {
	my @cmds = @_;
	for (@cmds) {
		s/([\$\"\`])/\\$1/g;
		unless (/^[\w\+\-\/\.]+$/) {
			$_ = '"' . $_ . '"';
		}
	}
	return join(' ', @cmds);
}

sub build {
	my $self = shift;

	my @command = (
		$self->{_ffmpeg},
		@{ $self->{_input_options} },
		'-i', $self->{_input},
		@{ $self->{_output_options} },
		$self->{_output},
	);

	return _escapeCommands(@command);
}

1;
