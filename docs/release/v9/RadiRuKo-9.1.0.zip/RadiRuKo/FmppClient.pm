package Plugins::RadiRuKo::FmppClient;

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

use v5.20;
use warnings;
use base qw(
  Plugins::RadiRuKo::BaseWebSocketHandler
  Plugins::RadiRuKo::MetadataHandler
);

use JSON::XS::VersionOneAndTwo;
use Slim::Music::Info;
use Slim::Utils::Log;
use Promises2 qw(rejected);
use Plugins::RadiRuKo::FFMpegHandler;
use Plugins::RadiRuKo::SimulMeta;
use Plugins::RadiRuKo::Utils qw(AsyncHttp);
use Data::Dumper;

my $log = logger('plugin.radiruko');

my %configs = (
	fmpp => [
		'https://fmplapla.com',
		'https://fmplapla.com/api/select_stream?station=%s&burst=5'
	],
	jcba => [
		'https://www.jcbasimul.com',
		'https://api.radimo.smen.biz/api/v1/select_stream?station=%s&channel=0&quality=high&burst=5'
	],
);

sub _stationConfig {
	$_[0] =~ m{^([a-z]+)://([a-z\d\-]+)\b};
	my $c = $configs{$1} // return;
	return {
		protocol => $1,
		id       => $2,
		origin   => $c->[0],
		jsUrl    => sprintf($c->[1], $2),
	};
}

#JCBA/FMPP Client
sub new {
	my $class = shift;
	my $args  = shift;

	$log->debug('url=' . $args->{url});

	my $song = $args->{song};

	my $self = $class->SUPER::new(
		$song->pluginData('fmppLocation'),
		$args,
	) or return;

	$self->ws_printf('%s', $song->pluginData('fmppToken'));
	return $self;
}

sub wsTryHandshake {
	my ($self, $sock, $hs, $timeout) = @_;

	my $config = ${*$self}{song}->pluginData('fmppConfig');
	$hs->req->{origin}      = $config->{origin};
	$hs->req->{subprotocol} = 'listener.fmplapla.com';

	return $self->SUPER::wsTryHandshake($sock, $hs, $timeout);
}

sub ws_printf {
	my $self = shift;
	my $fmt  = shift;
	my $buf  = sprintf($fmt, @_);
	$log->debug('send: ' . $buf);
	$self->ws_write(masked => 1, buffer => $buf);
}

sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $client = $song->master();
	my $url    = $song->track()->url;

	my $config = _stationConfig($url);
	my $promise;
	if (defined $config) {
		$promise = AsyncHttp()->post(
			$config->{jsUrl},
			'User-Agent' => 'Mozilla/5.0',
			'Origin'     => $config->{origin},
			'',    #empty post data
		);
	} else {
		$promise = rejected("Invalid URL: $url");
	}
	$promise->then(
		sub {
			my $js = shift;
			$log->debug(Dumper($js));

			if ($js->{code} != 200) {
				return rejected("code is " . $js->{code});
			}

			$song->pluginData(fmppToken    => $js->{token});
			$song->pluginData(fmppLocation => $js->{location});
			$song->pluginData(fmppConfig   => $config);
		}
	)->done(
		sub {
			$successCb->();
		},
		sub {
			$log->error($_[0]);
			$errorCb->($_[0]);
		}
	);
}

sub isRemote        {1}
sub contentType     {'ops'}
sub getFormatForURL {'ops'}

1;
