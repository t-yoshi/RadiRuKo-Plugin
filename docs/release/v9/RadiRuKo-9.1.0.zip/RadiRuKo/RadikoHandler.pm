# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadikoHandler;

# RADIKO URL protocol handler

use v5.20;
use warnings;
use base       qw(Plugins::RadiRuKo::BaseFFMpegHandler);
use List::Util qw(first);
use Slim::Utils::Log;
use Promises2 qw(collect rejected);
use Plugins::RadiRuKo::RadikoAuth;
use Plugins::RadiRuKo::RadikoMeta;
use Plugins::RadiRuKo::Utils qw(RE_RADIKO_URL AsyncHttp);
use Data::Dumper;

my $log = logger('plugin.radiruko');

sub new {
	my $class = shift;
	my $args  = shift;
	my $song  = $args->{song};
	my $u     = $song->pluginData('radikoPlaylist');
	my $opt   = $song->pluginData('ffOptions');

	return $class->SUPER::new($args, $u, @$opt);
}

sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $client = $song->master();
	my $url    = $song->track()->url;

	unless ($url =~ RE_RADIKO_URL) {
		$errorCb->('Invalid URL: ' . $url);
		return;
	}

	$song->isLive(1);

	my $stId        = $1;
	my $hasAreaFree = $url =~ /^radikop:/ ? 1 : 0;

	collect(
		Plugins::RadiRuKo::RadikoAuth->execute(url => $url)->then(
			sub {
				my ($token, $area) = @_;
				$log->debug("Authtoken=$token, AreaId=$area") if $log->is_debug;
				$song->pluginData(
					ffOptions => [
						-headers => "X-Radiko-AuthToken: $token\cM\cJ",
					]
				);
			}
		),
		AsyncHttp()->get("https://radiko.jp/v2/station/stream_smh_multi/$stId.xml")->then(
			sub {
				my $xml = shift;
				$log->debug(Dumper $xml) if $log->is_debug;
				for (@{ $xml->{url} }) {
					my $u = $_->{playlist_create_url};
					if ($_->{areafree} == $hasAreaFree && $u) {
						$song->pluginData(radikoPlaylist => $u);
						return;
					}
				}
				return rejected("${stId}'s playlist not found.");
			}
		),
	)->done($successCb, $errorCb);
}

sub getFormatForURL {'aac'}

1;
