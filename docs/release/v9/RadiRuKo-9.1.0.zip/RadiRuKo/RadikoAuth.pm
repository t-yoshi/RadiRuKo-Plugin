# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadikoAuth;

use v5.20;
use warnings;
use Carp::Assert;
use Digest::MD5 qw(md5_hex);
use MIME::Base64;
use Slim::Utils::Log;
use Slim::Utils::Prefs;

use Plugins::RadiRuKo::Utils qw(
  AsyncHttp isEnabledAreaFree
);
use Promises2 qw(resolved rejected);

use Exporter 'import';
our @EXPORT_OK = qw(UA cookie_rdk_uid cookie_radiko_session);

use constant AUTH_KEY => 'bcd151073c03b352e1ef2fd66c32209da9ca0afa';
use constant UA       => 'Mozilla/5.0 like Gecko';

my $app_prefs = preferences('plugin.radiruko');
my $log       = Slim::Utils::Log::logger('plugin.radiruko');

use Slim::Networking::Async::HTTP;
my $jar = Slim::Networking::Async::HTTP::cookie_jar();

sub _defaultRequestHeaders {
	return (
		'User-Agent'           => UA,
		'pragma'               => 'no-cache',
		'Referer'              => 'https://radiko.jp/',
		'X-Radiko-App'         => 'pc_html5',
		'X-Radiko-App-Version' => '0.0.1',
		'X-Radiko-User'        => 'dummy_user',
		'X-Radiko-Device'      => 'pc',
	);
}

#キャッシュ  [authToken, areaId, expires]
my @cache = (undef, undef, 0);

sub _radiko_set_cookie {
	my ($key, $value) = @_;
	$jar->set_cookie(
		undef, $key, $value,
		'/',   'radiko.jp',
		undef, undef, undef,
		10 * 365 * 24 * 60 * 60,
	);
	$jar->save();
}

#radiko_session変更時にキャッシュをクリアする
$app_prefs->setChange(
	sub {
		my $val = $_[1];
		$log->debug("radiko_session has been changed: $val");
		_radiko_set_cookie('radiko_session', $val);
		@cache = ();
	},
	'cookie_radiko_session'
);

#
# 非同期でradiko認証を行う。
# 成功した場合、結果を10分間キャッシュする。
# options
#   mode:
#     'cache' 期限切れでもキャッシュを返す
#     'force' キャッシュを破棄
# 成功時:
#   (authToken, areaId)
#
sub execute {
	my $class = shift;

	assert(@_ % 2 == 0);

	my %options = (
		mode => '',
		@_,
	);

	if ($options{mode} eq 'cache' && $cache[0]) {
		return resolved(@cache);
	}

	my $now = time();

	if ($options{mode} ne 'force' && $cache[2] > $now) {
		return resolved(@cache);
	}

	return _auth1()->then(\&_auth2);
}

sub _auth1() {
	$log->debug("auth1: Start");

	return AsyncHttp()->handler(
		sub {
			my $http    = shift;
			my $headers = $http->headers;
			$log->debug("auth1: OK");

			map { $headers->header($_); } qw(x-radiko-authtoken x-radiko-keyoffset x-radiko-keylength);
		}
	)->get(
		'https://radiko.jp/v2/api/auth1',
		_defaultRequestHeaders()
	);
}

sub _auth2 {
	my ($authToken, $keyoffset, $keylength) = @_;

	$log->debug("auth2: Start");

	my $partKey = do {
		my $buf = substr(AUTH_KEY, $keyoffset, $keylength);
		MIME::Base64::encode_base64($buf, '');
	};
	my $url = 'https://radiko.jp/v2/api/auth2';

	my $radiko_session = cookie_radiko_session();
	if (isEnabledAreaFree()) {
		$url .= "?radiko_session=$radiko_session";
	}

	return AsyncHttp()->get(
		$url,
		_defaultRequestHeaders(),
		'X-Radiko-Authtoken'  => $authToken,
		'X-Radiko-Partialkey' => $partKey
	)->then(
		sub {
			my $content = shift;
			$log->debug("auth2: OK");

			if ($content =~ /(JP\d+)/) {
				my $areaId = $1;

				# 成功した場合10分間Cacheする。
				@cache = ($authToken, $areaId, time() + 600);

				return resolved(@cache);
			}
			return rejected('fail auth2: Bad areaId');
		}
	);
}

#HTTP::Cookiesが古い場合、
# get_cookiesが実装されていない
#
sub _get_cookies {
	my $self = shift;
	my $url  = shift;
	$url = "https://$url" unless $url =~ m,^[a-zA-Z][a-zA-Z0-9.+\-]*:,;
	require HTTP::Request;
	my $req     = HTTP::Request->new(GET => $url);
	my $cookies = $req->{_http_cookies} = {};
	$self->add_cookie_header($req);
	if (@_) {
		return map ({ $cookies->{$_} } @_) if wantarray;
		return $cookies->{ $_[0] };
	}
	return $cookies;
}

sub cookie_rdk_uid () {
	my $rdk_uid = _get_cookies($jar, 'radiko.jp', 'rdk_uid');
	return $rdk_uid if $rdk_uid;
	$rdk_uid = md5_hex(time());
	_radiko_set_cookie('rdk_uid', $rdk_uid);
	return $rdk_uid;
}

sub cookie_radiko_session {
	return $app_prefs->cookie_radiko_session(@_) // '';
}

1;
