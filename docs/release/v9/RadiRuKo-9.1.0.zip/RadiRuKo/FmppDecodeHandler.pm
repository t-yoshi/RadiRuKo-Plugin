# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::FmppDecodeHandler;

use v5.20;
use warnings;
use base qw(
  Plugins::RadiRuKo::BaseFFMpegHandler
  Plugins::RadiRuKo::MetadataHandler
);

use Slim::Control::Request;
use Slim::Utils::Log;
use Plugins::RadiRuKo::FFMpegHandler;
use Plugins::RadiRuKo::FmppClient;
use Data::Dumper;

my $log = logger('plugin.radiruko');

sub new {
	my $class = shift;
	my $args  = shift;

	my $source = Plugins::RadiRuKo::FmppClient->new($args) or return;
	return $class->SUPER::new($args, $source);
}

sub getNextTrack {
	my $class = shift;
	return Plugins::RadiRuKo::FmppClient->getNextTrack(@_);
}

sub canHandleTranscode {0}

sub getFormatForURL {'wav'}
sub canDirectStream {0}
sub isRemote        {1}
sub isAudioURL      {1}

1;
