# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::BaseFFMpegHandler;

use v5.20;
use warnings;
use base qw(
  Slim::Player::Pipeline
  Plugins::RadiRuKo::MetadataHandler
);
use Carp::Assert;
use Scalar::Util qw(blessed looks_like_number);
use Slim::Music::Info;
use Slim::Utils::Log;
use Slim::Utils::Misc();
use Slim::Utils::Prefs;
use Plugins::RadiRuKo::FFCommand;
use Plugins::RadiRuKo::FFLogger;
use Data::Dumper;

my $log          = logger('plugin.radiruko');
my $server_prefs = preferences('server');
my $app_prefs    = preferences('plugin.radiruko');

# args:
#  ffurl
#  ffoptions

sub new {
	my $class     = shift;
	my $args      = shift;
	my $ffurl     = shift;
	my @ffoptions = @_;

	assert(defined $ffurl, 'ffurl is required');

	my $ffsource;
	if (blessed $ffurl && $ffurl->can('sysread')) {
		$ffsource = $ffurl;
		$ffurl    = 'pipe:';
	} else {
		$ffurl =~ s/#.*$//;
	}

	my $ffcmd = Plugins::RadiRuKo::FFCommand->new($ffurl) // return;

	#メタデータ・フラグメントURI
	my $metafrag = $class->parseMetadataFragment($args->{url});

	my $format = 'wav';
	if ($class->can('getFormatForURL')) {
		$format = $class->getFormatForURL($args->{url});
	}
	assert($format =~ /^(aac|wav)$/);

	if ($log->is_debug) {
		local $Data::Dumper::Indent = 0;
		local $Data::Dumper::Terse  = 1;
		$log->debug("ffurl: $ffurl, format=$format, flags=" . Dumper($metafrag));
	}

	my $fflogger = Plugins::RadiRuKo::FFLogger->new();
	$ffcmd->with_input_options($fflogger->fflog_options);

	my $song  = $args->{song};            ## Slim::Player::Song
	my $track = $song->currentTrack();    ## Slim::Schema::RemoteTrack

	if ($ffurl =~ /^https?:/) {
		$class->_set_http_options($ffurl, $ffcmd, $song->isLive);
	}

	my $timeout = ($server_prefs->remotestreamtimeout() || 15) * 1_000_000;    #us

	if ($ffurl =~ /^rtsp:/) {
		#see: libavformat/rtsp.c
		$ffcmd->with_input_options(-rtsp_transport => 'tcp', -timeout => $timeout);
	} else {
		$ffcmd->with_input_options(-rw_timeout => $timeout);
	}

	$ffcmd->with_input_options(
		#等速
		-readrate => 1, -readrate_initial_burst => 15,
		@ffoptions,
	);

	if (defined $metafrag->{ffmap} && $metafrag->{ffmap} =~ /(\d)/) {
		$ffcmd->with_output_options(-map => "0:a:$1");
	}

	if ($format eq 'aac') {
		$ffcmd->with_output_options(qw/-c:a copy -f adts/);
	} else {
		$ffcmd->with_output_options(qw/-ar 48k -ac 2 -f s16le/);
		$song->bitrate(48_000 * 16 * 2);
		$track->samplerate(48_000);
		$track->samplesize(16);
		$track->channels(2);
	}

	my $self = do {
		my $cmd = $ffcmd->build();
		$log->info($cmd);

		local $ENV{FFREPORT} = $fflogger->ffreport_environment_value();
		$log->debug('FFREPORT=' . $ENV{FFREPORT});

		$class->SUPER::new($ffsource, $cmd, 0);
	};

	unless (defined $self) {
		$fflogger->stop();
		return;
	}

	${*$self}{url}          = $args->{url};
	${*$self}{client}       = $args->{client};
	${*$self}{transcoder}   = $args->{transcoder};
	${*$self}{song}         = $song;
	${*$self}{metafrag}     = $metafrag;
	${*$self}{_contentType} = $format;
	${*$self}{_fflogger}    = $fflogger;

	$track->content_type($format);

	return $self;
}

sub _set_http_options {
	my ($class, $ffurl, $ffcmd, $isLive) = @_;

	$ffcmd->with_input_options(-user_agent => 'Mozilla/5.0');

	#HLS
	if ($ffurl =~ /\.m3u8\b/) {
		$ffcmd->with_input_options(
			#Rangeヘッダを付加しない
			-http_seekable => 0,
			#セグメントを再読み込みする
			-seg_max_retry => 2,
		);

		#Liveでのバッファ時間
		my $start_index = {
			#normal => -3,
			long    => -6,
			maximum => -0,
		}->{ $app_prefs->hls_buffering_time() // '' };
		if ($isLive && defined $start_index) {
			$ffcmd->with_input_options(-live_start_index => $start_index);
		}
	}
}

sub _doParseStreamInfo {
	my $self  = shift;
	my $info  = ${*$self}{_fflogger}->parseStreamInfo() // return;
	my $input = $info->{Input}{ $info->{Selected} }     // {};

	my ($bitrate, $isVbr);
	if ($input->{Metadata}{variant_bitrate}) {
		$bitrate = $input->{Metadata}{variant_bitrate};
		$isVbr   = 1;
	} elsif ($input->{bitrate}) {
		$bitrate = $input->{bitrate};
		$isVbr   = $input->{Metadata}{IsVBR} // 0;
	}

	my $url = ${*$self}{url};
	if (looks_like_number($bitrate) && $bitrate > 0) {
		Slim::Music::Info::setBitrate($url, $bitrate, $isVbr);
	}
	$self->setMetaAudioFormat(${*$self}{client}, $url, $input->{audio_format});
}

sub sysread {
	my $self = shift;
	my $r    = $self->SUPER::sysread(@_);
	if (defined $r && $r > 0) {
		$self->_doParseStreamInfo() if (!${*$self}{_readBytes});
		${*$self}{_readBytes} += $r;
	}
	return $r;
}

sub close {
	my $self = shift;
	$self->SUPER::close();
	${*$self}{_fflogger}->stopAfter(10);
}

sub DESTROY {
	my $self = shift;
	$self->close();
	$self->SUPER::DESTROY();
}

sub contentType {
	my $self = shift;
	return ${*$self}{_contentType};
}

# Avoid scanning
sub scanUrl {
	my ($class, $url, $args) = @_;
	$args->{cb}->($args->{song}->currentTrack());
}

sub canDirectStream {0}

sub isRemote {1}

sub isAudioURL {1}

1;
