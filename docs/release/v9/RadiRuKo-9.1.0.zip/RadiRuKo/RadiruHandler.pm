# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruHandler;
#
# RADIRU URL protocol handler
#
#  radiru://Station[-Area]
#
#  Station:
#    R1, R2, FM
#  Area:
#    Sendai, Tokyo, Nagoya, Osaka
#
#  See: http://www.nhk.or.jp/radio/config/config_web.xml
#
use v5.20;
use warnings;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Timers;
use Data::Dumper;

use Plugins::RadiRuKo::RadiruConfig;
use Plugins::RadiRuKo::Utils qw(RE_RADIRU_URL);

use Promises2 qw(rejected);

my $log       = logger('plugin.radiruko');
my $app_prefs = preferences('plugin.radiruko');

use base qw(Plugins::RadiRuKo::BaseFFMpegHandler);

sub new {
	my $class = shift;
	my $args  = shift;

	my $song       = $args->{song};
	my $stream_url = $song->pluginData('stream_url') // return;

	return $class->SUPER::new(
		$args, $stream_url,
	);
}

sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $client = $song->master();
	my $url    = $song->track()->url;

	my ($channel, $area) = $url =~ RE_RADIRU_URL or return do {
		my $error = "Invalid URL: $url";
		$log->error($error);
		$errorCb->($error);
	};
	$area ||= 'tokyo';

	$song->isLive(1);

	Plugins::RadiRuKo::RadiruConfig->load()->then(
		sub {
			my $config = shift;
			my $data   = $config->data(area => $area) || return rejected("area: '$area' not found.");
			return $data->{ lc($channel) . 'hls' };
		}
	)->done(
		sub {
			$song->pluginData({ stream_url => shift });
			$successCb->();
		},
		sub {
			$log->error($_[0]);
			$errorCb->($_[0]);
		}
	);
}

sub getFormatForURL {'aac'}

1;
