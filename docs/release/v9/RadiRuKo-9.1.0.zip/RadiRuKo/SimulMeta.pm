# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::SimulMeta;

use v5.20;
use warnings;
use utf8;
use Carp::Assert;
use List::Util qw(first);
use Time::HiRes q(time);
use Slim::Utils::Log;
use Plugins::RadiRuKo::MetadataHandler;
use Plugins::RadiRuKo::Utils qw(AsyncHttp parseDateTime formatTitle);
use Data::Dumper;

my $log = logger('plugin.radiruko');

sub _DEBUG { 0 && $log->is_debug; }

use constant {
	RE_LISTEN_RADIO => qr{\.smartstream\.ne\.jp/(\d{5})/},
	RE_JCBA         => qr{^jcba://(\w+)/},
	RE_FMPP         => qr{^fmpp://(\w+)/},
};

sub _loadListenRadioMeta {
	my ($handler, $client, $url) = @_;
	#$log->debug($url);
	my ($id) = $url =~ RE_LISTEN_RADIO;
	assert($url && $id);

	my $meta = $handler->defaultMetadata($client, $url);

	return AsyncHttp()->post(
		'https://listenradio.jp/Home/NowPlayingMusic',
		'Content-Type' => 'application/x-www-form-urlencoded',
		"id=$id"
	)->then(
		sub {
			my $js = shift;

			$log->debug(Dumper($js)) if $log->is_debug;

			if ($js->{Status} =~ /^[23]$/) {
				$meta->{title} .= ' - ' . formatTitle($js->{Title});
				if ($js->{Limit} > 0) {
					$meta->{expires} = int(time() + $js->{Limit} / 1000 + 1);
				}
			}
			return $meta;
		}
	);
}

sub _loadJcbaMeta {
	my ($handler, $client, $url) = @_;
	#$log->debug($url);
	my ($id) = $url =~ RE_JCBA;
	assert($url && $id);

	my $meta = $handler->defaultMetadata($client, $url);

	return AsyncHttp()->get(
		"https://www.jcbasimul.com/api/timetable/current/$id",
	)->then(
		sub {
			my $js = shift;

			$log->debug(Dumper($js, $meta)) if $log->is_debug;

			if ($js->{current}{title}) {
				$meta->{title} .= ' - ' . formatTitle($js->{current}{title});
				$meta->{artist} = formatTitle($js->{current}{performer});
				my $end = parseDateTime($js->{current}{air_end});
				if ($end > 0) {
					$meta->{expires} = $end;
				}
			}
			return $meta;
		}
	);
}

sub _loadFmppMeta {
	my ($handler, $client, $url) = @_;

	my ($id) = $url =~ RE_FMPP;
	assert($url && $id);

	my $meta = $handler->defaultMetadata($client, $url);

	return AsyncHttp(cache => '1 day, no-revalidate')->get(
		'https://api.fmplapla.com/api/v1/mobile/updates',
		'User-Agent' => 'okhttp'
	)->then(
		sub {
			my $js  = shift;
			my $now = time();

			my $timetable = first { $_->{type} eq 'timetable' && $_->{station} eq $id } @{ $js->{updates} };
			$timetable //= {};
			my $data = first { $now >= $_->{start} && $now < $_->{end} } @{ $timetable->{data} // [] };

			$log->debug(Dumper($data, $meta)) if $log->is_debug;

			if ($data && $data->{title}) {
				$meta->{title} .= ' - ' . formatTitle($data->{title});
				$meta->{artist}  = formatTitle($data->{performer});
				$meta->{album}   = formatTitle($data->{sub_title});
				$meta->{expires} = $data->{end};
			}

			return $meta;
		}
	);
}

Plugins::RadiRuKo::MetadataHandler->registerAsyncMetaProvider(
	match => RE_LISTEN_RADIO,
	func  => \&_loadListenRadioMeta,
);

Plugins::RadiRuKo::MetadataHandler->registerAsyncMetaProvider(
	match => RE_JCBA,
	func  => \&_loadJcbaMeta,
);

Plugins::RadiRuKo::MetadataHandler->registerAsyncMetaProvider(
	match => RE_FMPP,
	func  => \&_loadFmppMeta,
);

1;
