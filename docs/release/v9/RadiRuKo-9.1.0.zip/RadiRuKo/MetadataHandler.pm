# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::MetadataHandler;

use v5.20;
use warnings;
use Carp::Assert;
use JSON::XS::VersionOneAndTwo qw(from_json to_json);
use MIME::Base64               qw(encode_base64url decode_base64url);    #5.14
use Scalar::Util               qw(blessed);
use Tie::Cache::LRU;
use Tie::RegexpHash;
use Time::HiRes q(time);
use Slim::Control::Request;
use Slim::Music::Info;
use Slim::Utils::Log;
use Slim::Utils::Strings qw(string);
use Slim::Utils::Timers;
use Data::Dumper;

my $log = logger('plugin.radiruko');

my $providers = Tie::RegexpHash->new;

#
# メタデータを返す。
# Note: Touchは10分毎に呼び出してくる。
#      制御アプリは数秒毎に呼び出すこともある。
#
#	{
#          url     => 'ffmpegaac:http://...',
#          title   => 'Track Title',
#          artist  => 'Artist Name',
#          album   => 'Album Name',
#          cover   => 'http://...',
#          bitrate => 128,
#          type    => 'Internet Radio',
#
#          #オプション: 有効期限
#		   expires => time()+180,
#   }
#

sub getMetadataFor {
	my ($class, $client, $url) = @_;

	if ($client->isStopped() || !$providers->match_exists($url)) {
		return $class->defaultMetadata($client, $url);
	}

	my $meta = $client->pluginData('ffMeta');
	if (!defined $meta || $meta->{url} ne $url) {
		$meta = $class->defaultMetadata($client, $url);
		$client->pluginData(ffMeta => $meta);
	}

	#取得中or期限内
	if ($meta->{_loading} || $meta->{expires} > time()) {
		$meta->{type}    = _meta_audio_type($url);
		$meta->{bitrate} = _meta_audio_bitrate($url);
		return $meta;
	}

	$meta->{_loading} = 1;

	my $promise = $providers->match($url)->($class, $client, $url);
	assert(blessed $promise && $promise->can('then'));

	_cachePromisedMetadata(
		$client, $promise,
		$class->defaultMetadata($client, $url)
	);

	return $meta;
}

sub registerAsyncMetaProvider {
	my ($class, %params) = @_;

	assert(ref $params{match} eq 'Regexp', 'match is not a regular expression');
	assert(ref $params{func} eq 'CODE',    'func is not a code reference');

	if ($log->is_debug) {
		require Slim::Utils::PerlRunTime;
		my $name = Slim::Utils::PerlRunTime::realNameForCodeRef($params{func});
		$log->debug("Registered new metadata provider for $params{match}: $name");
	}

	$providers->add($params{match}, $params{func});

	return 1;
}

#
# メタデータ・フラグメントURI
#
# http://www.simulradio.jp/asx/XXX.asx#metadata=eyJhbG...&_=-
#
# metadata -> json -> base64url
#
# NOTE:
#  拡張子やcuesheetの開始/終了時間だと誤認させないように"&_=-"で終端させる
#

sub encodeMetadataFragment {
	my ($class, $meta) = @_;
	assert(ref $meta eq 'HASH');

	my $js = to_json($meta);
	return '#metadata=' . encode_base64url($js);
}

# def encode_metadata_fragment(meta: dict) -> str:
#     if not isinstance(meta, dict):
#         raise TypeError("Input 'meta' must be a dictionary.")
#     js = json.dumps(meta, ensure_ascii=False)
#     b64u = base64.urlsafe_b64encode(js.encode('utf-8')).decode('ascii')
#     return f'#metadata={b64u}'

#
# メディア・フラグメントURI
# http://www.simulradio.jp/asx/XXX.asx#simulradio=1;title=タイトル;icon=http://icon-url/;homepage=http://station-homepage/;--
# DEPRECATED:
#
sub _parseMediaFragment {
	my ($class, $url) = @_;

	if ($url =~ /#(.*)$/) {
		my $frag = "$1;";
		utf8::decode($frag);
		return +{ $frag =~ /([a-z]+)=(.*?)[;&](?=[a-z]+=|\W*$)/g };
	}
	return +{};
}

sub parseMetadataFragment {
	my ($class, $url) = @_;

	if ($url =~ /#metadata=([\w-]+)/) {
		my $b    = decode_base64url($1);
		my $meta = eval { from_json($b) };
		return $meta if (!$@ && ref $meta eq 'HASH');

		$log->warn("Failed to parse JSON string: $@");
	}
	#return +{};
	# 廃止予定
	return $class->_parseMediaFragment($url);
}

tie my %metaAudioFormat, 'Tie::Cache::LRU', 16;

sub _meta_audio_type {
	my $url = shift;

	my $type = string('RADIO');

	if ($url =~ /^([a-z]+):/) {
		my $token = uc($1);
		$type = string($token) if Slim::Utils::Strings::stringExists($token);
	} elsif ($url =~ /#simulradio=1/) {
		$type = string('PLUGIN_RADIRUKO_SIMULRADIO');
	}

	$type = $metaAudioFormat{$url} . "($type)" if $metaAudioFormat{$url};
	return $type;
}

sub _meta_audio_bitrate {
	my ($url) = @_;
	my $bitrate = Slim::Music::Info::getBitrate($url);
	if (defined $bitrate && $bitrate > 0) {
		return int($bitrate / 1000) . string('KBPS');
	}
	return 'n/a';
}

sub defaultMetadata {
	my ($class, $client, $url) = @_;
	assert($url =~ m{://});

	my $meta = {
		url     => $url,
		title   => Slim::Music::Info::title($url) || $url,
		album   => ' ',
		artist  => ' ',
		icon    => 'html/images/radio.png',
		type    => _meta_audio_type($url),
		bitrate => _meta_audio_bitrate($url),
		expires => 0,
	};

	my $frags = $class->parseMetadataFragment($url);
	if (defined $frags->{title}) {
		return {
			%$meta,
			%$frags,
		};
	}
	return $meta;
}

sub _cachePromisedMetadata {
	my ($client, $promise, $defaultMeta) = @_;

	$promise->then(
		sub {
			$log->debug('New meta: ' . Dumper $_[0]) if $log->is_debug;
			return $_[0];
		},
		sub {
			$log->error($_[0]);
			return +{};
		}
	)->done(
		sub {
			my $newMeta = {
				%$defaultMeta,
				%{ $_[0] },
			};

			$client->pluginData(ffMeta => $newMeta);

			_notifyNewMetadata($client);

			my $now = time();
			$newMeta->{expires} ||= $now + 600;
			if ($newMeta->{expires} < $now + 30) {
				$newMeta->{expires} = $now + 30;
			}
			_scheduleNotifyNewMetadata($client, $newMeta->{expires});
		}
	);
}

sub _scheduleNotifyNewMetadata {
	my $client  = shift;
	my $expires = shift;

	assert($expires >= 0);
	$log->debug('Set meta expires: ' . localtime($expires)) if $log->is_debug;

	Slim::Utils::Timers::killTimers($client, \&_notifyNewMetadata);
	Slim::Utils::Timers::setTimer($client, $expires, \&_notifyNewMetadata);
}

sub _notifyNewMetadata {
	my $client = shift;

	Slim::Control::Request::notifyFromArray($client, ['newmetadata']);
}

sub setMetaAudioFormat {
	my ($classOrSelf, $client, $url, $format) = @_;

	$metaAudioFormat{$url} = $format;

	my $now = time();
	#WebUIの更新
	$client->currentPlaylistUpdateTime($now);
	Slim::Utils::Timers::setTimer($client, $now, \&_notifyNewMetadata);
}

1;
