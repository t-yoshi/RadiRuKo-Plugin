package Plugins::RadiRuKo::BaseWebSocketHandler;

use v5.20;
use warnings;

use base q(IO::String);
use Carp::Assert;
use IO::Socket::INET;
use IO::Socket::SSL qw/SSL_VERIFY_NONE/;
use List::Util      qw(min);
use POSIX           qw(floor);
use Scalar::Util    qw(blessed);
use Time::HiRes q(time);
use Slim::Music::Info;
use Slim::Networking::IO::Select;
use Slim::Networking::Select;
use Slim::Utils::Errno;
use Slim::Utils::Log;
use Slim::Utils::Network;
use Slim::Utils::Prefs;
use Slim::Utils::Timers;
use Protocol::WebSocket::Frame;
use Protocol::WebSocket::Handshake::Client;
use Protocol::WebSocket::URL;
use Data::Dumper;

my $log          = logger('plugin.radiruko');
my $server_prefs = preferences('server');

use constant _BUFFER_SIZE => 16384;

sub new {
	my $class  = shift;
	my $ws_url = shift;
	my $args   = shift;

	unless (blessed $ws_url && $ws_url->isa('Protocol::WebSocket::URL')) {
		unless ($ws_url =~ m|^wss?://|) {
			$log->error('Invalid Websocket Url: ' . $ws_url);
			return;
		}
		$ws_url = Protocol::WebSocket::URL->new->parse($ws_url);
	}
	$log->debug('ws_url=' . $ws_url->to_string);

	my $timeout = $args->{timeout} || $server_prefs->remotestreamtimeout;

	my @sockOpt = (
		PeerAddr => $ws_url->{host},
		PeerPort => $ws_url->{port},
		Timeout  => $timeout,
	);

	my ($sock, $ferr);
	if ($ws_url->{secure}) {
		$sock = IO::Socket::SSL->new(
			@sockOpt,
			SSL_verify_mode => SSL_VERIFY_NONE,
		);
		$ferr = \&IO::Socket::SSL::errstr;
	} else {
		$sock = IO::Socket::INET->new(@sockOpt);
		$ferr = sub {$IO::Socket::errstr};
	}

	unless (defined $sock) {
		$log->error(sprintf('Failed to connect to %s (%s)', $ws_url->{host}, $ferr->()));
		return;
	}

	${*$sock}{_sel} = IO::Select->new($sock);
	unless (defined Slim::Utils::Network::blocking($sock, 0)) {
		logError('Could not set to non-blocking mode.');
		$sock->close();
		return;
	}

	my $self = $class->SUPER::new();
	${*$self}{url}    = $args->{url};
	${*$self}{client} = $args->{client};
	${*$self}{song}   = $args->{song};
	${*$self}{ws_url} = $ws_url;

	my $hs = Protocol::WebSocket::Handshake::Client->new(url => $ws_url);

	$self->wsTryHandshake($sock, $hs, $timeout) || do {
		$sock->close();
		return;
	};

	${*$self}{_ws_sock}  = $sock;
	${*$self}{_ws_frame} = _wsBuildFrame();

	$self->_startObservingBitrate();

	return $self;
}

sub _read_each_byte {
	my ($sock, $rbuf, $rerr) = @_;

	while (1) {
		my $r = $sock->sysread($$rbuf, 1, length($$rbuf));
		if (!defined($r)) {
			return;
		}
		if ($r > 0 && $$rbuf =~ /\x0D\x0A\x0D\x0A\z/) {
			return 1;
		}
		if ($r == 0) {
			$$rerr = 'unexpected eof.';
			return;
		}
		if (length($$rbuf) > _BUFFER_SIZE) {
			$$rerr = 'response is too large.';
			return;
		}
	}
}

sub _read_response {
	my ($sock, $timeout) = @_;
	my $expire = time() + $timeout;
	my $buf;
	my $err;
	while (!defined $err) {
		if (${*$sock}{_sel}->can_read(1.)) {
			return $buf if _read_each_byte($sock, \$buf, \$err);
		}
		if ($! && !($!{EINTR} || $!{EWOULDBLOCK})) {
			$err = $!;
		} elsif (time() > $expire) {
			$err = "timeout. [$timeout sec]";
		}
	}
	$log->error($err);
	return;
}

sub wsTryHandshake {
	my ($self, $sock, $hs, $timeout) = @_;

	my $req = $hs->to_string;
	$log->debug("Request: $req");
	Slim::Networking::Select::writeNoBlock($sock, \$req);

	my $res = _read_response($sock, $timeout);
	$log->debug("Response: $res");

	unless ($res && $hs->parse($res)) {
		$log->error('Switching protocol is failed: ' . $hs->error);
		return 0;
	}

	return 1;
}

sub _wsBuildFrame {
	return Protocol::WebSocket::Frame->new(version => undef, @_);
}

sub _startObservingBitrate {
	my $self     = shift;
	my $INTERVAL = 5;
	Slim::Utils::Timers::setTimer($self, time + $INTERVAL, \&_doObserveBitrate, $INTERVAL, 0);
}

sub _doObserveBitrate {
	my $self           = shift;
	my $interval       = shift;
	my $prevTotalBytes = shift;

	assert($interval > 0);

	return unless $self->opened;

	my $bps = floor(8. * (${*$self}{_ws_audio_total_bytes} - $prevTotalBytes) / $interval);
	my $now = time();

	Slim::Music::Info::setBitrate(${*$self}{url}, $bps, 1);
	#WebUIの更新
	${*$self}{client}->currentPlaylistUpdateTime($now);

	$log->debug("bitrate: $bps");

	# 徐々に更新頻度を減らす
	$interval = min(120, $interval * 1.5);

	Slim::Utils::Timers::setTimer(
		$self,     $interval + $now, __SUB__,
		$interval, ${*$self}{_ws_audio_total_bytes},
	);
}

sub _wsReadPacket {
	my $self = shift;
	my $sock = ${*$self}{_ws_sock};

	return 0 unless $sock->opened;

	my $r = $sock->sysread(my $buf, _BUFFER_SIZE);
	if (defined $r && $r > 0) {
		${*$self}{_ws_frame}->append($buf);
	}
	return $r;
}

sub _wsFillBuffer {
	my $self = shift;

	$self->truncate(0);

	my $frame = ${*$self}{_ws_frame};
	while (my $b = $frame->next_bytes) {
		if ($frame->is_close) {
			$log->debug('close packet received.');
			${*$self}{_ws_sock}->close();
		} elsif ($frame->is_pong) {
			$log->debug('pong packet received: ' . $b);
		} elsif ($frame->is_ping) {
			$log->debug('ping packet received: ' . $b);
			$self->ws_write(type => 'pong', masked => 1, buffer => $b);
		} else {
			$self->syswrite($b);
			${*$self}{_ws_audio_total_bytes} += length($b);
		}
	}

	my $n = $self->pos;
	$self->seek(0, 0);
	return $n;
}

sub sysread {
	my $self = shift;

	return 0 unless $self->opened;

	my $eof = $self->eof;
	my $r   = $self->_wsReadPacket();
	return $r if ($eof && !$r);

	if ($eof) {
		$r = $self->_wsFillBuffer();
		if ($r == 0) {
			$! = EINTR;
			return;
		}
	}

	return $self->SUPER::sysread(@_);
}

sub ws_write {
	my $self = shift;

	my $sock = ${*$self}{_ws_sock};
	return unless $sock->opened;

	my $frame =
	  @_ == 1
	  ? _wsBuildFrame(masked => 1, buffer => shift)
	  : _wsBuildFrame(@_);
	my $buf = $frame->to_bytes();
	Slim::Networking::Select::writeNoBlock($sock, \$buf);
}

sub isRemote {1}

sub close {
	my $self = shift;

	Slim::Utils::Timers::killTimers($self, \&_doObserveBitrate);

	$self->ws_write(type => 'close');

	my $sock = ${*$self}{_ws_sock};
	${*$sock}{_sel}->remove($sock);
	$sock->close();
}

1;
