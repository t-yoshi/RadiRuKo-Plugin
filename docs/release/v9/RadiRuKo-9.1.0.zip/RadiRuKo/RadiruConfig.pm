# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruConfig;

use v5.20;
use warnings;
use utf8;
use Carp::Assert;
use List::Util qw(first);
use URI;
use Slim::Utils::Log;
use Plugins::RadiRuKo::Utils qw(AsyncHttp);
use Data::Dumper;

use constant CONFIG_URL => 'https://www.nhk.or.jp/radio/config/config_web.xml';

my $log = logger('plugin.radiruko');

sub load {
	my $class = shift;

	return AsyncHttp(cache => 1)->get(CONFIG_URL)->then(sub { $class->new($_[0]) });
}

sub new {
	my $class = shift;
	my $xml   = shift;

	my $data = $xml->{stream_url}->{data};

	for (@$data) {
		$_->{url_program_noa} = _subUrl($xml->{url_program_noa}, $_);
	}

	return bless($data, $class);
}

#
# data() 全体を返す
# data(areajp => '東京'), data(area => 'Tokyo')
#
sub data {
	my $self = shift;
	return @$self if @_ == 0;

	my $key = shift;
	my $val = shift;

	assert($key =~ /^(areajp|area|areakey)$/, "Invalid key: $key");

	return first { ucfirst $_->{$key} eq ucfirst $val } @$self;
}

sub _subUrl {
	my $url  = shift;
	my $data = shift;
	$url =~ s/\{area\}/$data->{areakey}/;
	return URI->new_abs($url, CONFIG_URL)->as_string;
}

1;
