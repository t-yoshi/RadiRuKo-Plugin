# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadikoMeta;

use v5.20;
use warnings;
use utf8;
use List::Util qw(first);
use POSIX;
use Slim::Utils::Log;
use Plugins::RadiRuKo::Utils qw(
  RE_RADIKO_URL RE_RADIKO_TF_URL
  jptime parseDateTime jpShortDateTimeF
  formatTitle
);
use Promises2 qw(collect resolved rejected);
use Plugins::RadiRuKo::MetadataHandler;
use Plugins::RadiRuKo::RadikoFeed qw(loadProgramXml);
use Data::Dumper;

my $log = logger('plugin.radiruko');

sub _load {
	my $handler = shift;
	my $client  = shift;
	my $url     = shift;

	my $stId;         #TBS
	my $startTime;    #開始時間, undef=現在の番組
	if ($url =~ RE_RADIKO_TF_URL) {
		$stId      = $1;
		$startTime = parseDateTime($2);
	} elsif ($url =~ RE_RADIKO_URL) {
		$stId = $1;
	} else {
		return rejected("RadikoMeta Invalid url: $url");
	}

	collect(
		resolved($client, $url, $stId, $startTime),
		loadProgramXml($stId, $startTime),
	)->then(\&_onParse);
}

sub _onParse {
	my ($client, $url, $stId, $startTime) = @{ $_[0] };
	my ($xml, $prog) = @{ $_[1] };

	unless ($prog) {
		my $d;
		if ($startTime) {
			$d = '(' . jpShortDateTimeF($startTime) . '-)';
		}
		return rejected("RadikoMeta: ${stId}'s program $d is not found.");
	}

	my $stationName = $xml->{stations}{station}{name};
	my $progTitle   = $prog->{title};

	#局名がタイトルに含まれていれば追加する必要はない
	if (index($progTitle, $stationName) == -1) {
		$progTitle = "$stationName - $progTitle";
	}
	my $title = formatTitle($progTitle);

	my $expires;
	if ($startTime) {
		#タイムフリー用
		$title .= ' (' . jpShortDateTimeF($startTime) . '～)';
		$expires = 2**32;
	} else {
		$expires = parseDateTime($prog->{to});
	}

	return {
		title   => $title,
		album   => formatTitle([ $prog->{desc}, $prog->{info} ], stripHtml => 1),
		artist  => formatTitle($prog->{pfm}),
		icon    => 'plugins/RadiRuKo/html/images/icon.png',
		cover   => $prog->{img} // "https://radiko.jp/station/logo/$stId/logo_large.png",
		expires => $expires,
	};
}

Plugins::RadiRuKo::MetadataHandler->registerAsyncMetaProvider(
	match => RE_RADIKO_URL,
	func  => \&_load,
);

Plugins::RadiRuKo::MetadataHandler->registerAsyncMetaProvider(
	match => RE_RADIKO_TF_URL,
	func  => \&_load,
);

1;
