# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::BaseFFSeekableHandler;

use v5.20;
use warnings;
use base qw(Plugins::RadiRuKo::BaseFFMpegHandler);

use Carp::Assert;
use List::Util   qw(min max);
use POSIX        qw(floor);
use Scalar::Util qw(looks_like_number);
use Time::HiRes q(time);
use Slim::Utils::Cache;
use Slim::Utils::DateTime;
use Slim::Utils::Log;
use Slim::Utils::Misc();
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(string);
use Slim::Utils::Timers;
use Data::Dumper;

my $cache = Slim::Utils::Cache->new('radiruko');
my $log   = logger('plugin.radiruko');

use constant PLYABACK_POS_RETENTION_DAYS => '5 days';

sub new {
	my $class     = shift;
	my $args      = shift;
	my $ffurl     = shift;
	my @ffoptions = @_;
	my $song      = $args->{song};

	my $offset = ($song->seekdata() // {})->{timeOffset} // 0;

	if ($offset > 0) {
		_savePlaybackPosition($song);
	} else {
		my $key = _cache_key($args->{client}, $args->{url});
		$offset = $cache->get($key) // 0;
		$log->debug("Restored playback position $offset secs [$key]") if $offset;
	}

	if ($offset > 0) {
		#ffmpeg-seek
		push @ffoptions, -ss => "+$offset";
		$song->startOffset($offset);
	}

	my $metafrag = $class->parseMetadataFragment($args->{url});
	if (looks_like_number($metafrag->{duration}) && $metafrag->{duration} > 0) {
		$song->duration($metafrag->{duration});
	}

	_updatePlaybackPosition($args->{client}, $args->{url});

	return $class->SUPER::new($args, $ffurl, @ffoptions);
}

sub canDoAction {
	my ($class, $client, $url, $action) = @_;
	my $song = $client->playingSong();
	if ($action eq 'rew') {
		_removePlaybackPosition($song) if $song;
	} elsif ($action eq 'stop') {
		#_savePlaybackPosition($song) if $song;
	}
	return 1;
}

sub canSeek {
	my ($class, $client, $song) = @_;
	return 1;
}

sub getSeekData {
	my ($class, $client, $song, $newtime) = @_;
	return { timeOffset => floor($newtime), };
}

sub _cache_key {
	my $client = shift;
	my $url    = shift;
	$url =~ s/#.*$//;
	my $mac = $client->macaddress || 'null';
	return "ffplayback,$mac,$url";
}

sub _updatePlaybackPosition {
	my $client = shift;
	my $url    = shift;
	my $song   = $client->playingSong() || return;
	return if ($song->currentTrack->url ne $url || $client->isStopped);

	_savePlaybackPosition($song);
	Slim::Utils::Timers::setTimer($client, time + 15, __SUB__, $url);
}

sub _savePlaybackPosition {
	my $song = shift;

	my $elapsed = floor($song->master->controller->playingSongElapsed);

	if ($song->duration >= 600 && $elapsed > 30 && $elapsed < ($song->duration * 0.90)) {
		my $key = _cache_key($song->master, $song->currentTrack->url);
		$cache->set($key, $elapsed, PLYABACK_POS_RETENTION_DAYS);
		$log->debug("Save playback position $elapsed secs [$key]");
	} else {
		_removePlaybackPosition($song);
	}
}

sub _removePlaybackPosition {
	my $song = shift;
	my $key  = _cache_key($song->master, $song->currentTrack->url);

	if (defined $cache->get($key)) {
		$log->debug("Remove playback position [$key]");
		$cache->remove($key);
	}
}
1;
