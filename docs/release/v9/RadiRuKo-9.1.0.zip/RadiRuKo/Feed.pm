package Plugins::RadiRuKo::Feed;
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
use v5.20;
use warnings;
use utf8;
use List::Util qw(first);

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Plugins::RadiRuKo::Utils qw(
  localized localizedString formatTitle
);
use Promises2 qw(collect resolved rejected);
use Plugins::RadiRuKo::RadikoAuth;
use Plugins::RadiRuKo::RadikoMeta;
use Plugins::RadiRuKo::RadiruConfig;
use Data::Dumper;
use Plugins::RadiRuKo::RadikoFeed qw(
  loadStationXml
);

my $log       = logger('plugin.radiruko');
my $app_prefs = preferences('plugin.radiruko');

sub _radiruAreaItems {
	my $data      = shift;    #各エリアのdata
	my $audioUrls = shift;    #

	my $area    = ucfirst($data->{area});
	my $areajp  = $data->{areajp};
	my $areakey = $data->{areakey};

	my @items;

	my $progkey = 0;
	for my $ch (qw(R1 R2 FM)) {
		$progkey++;
		my $audioUrl = $data->{ lc($ch) . 'hls' };
		#R2は共通なのでダブらないように
		next if (first { $_ eq $audioUrl } @$audioUrls);
		push @$audioUrls, $audioUrl;

		push @items, {
			title => localizedString(
				"PLUGIN_RADIRUKO_NHK_$ch",
				JA => $areajp, EN => $area
			),
			url    => "radiru://$ch-$area",
			icon   => "plugins/RadiRuKo/html/images/NHK_$ch.png",
			type   => 'audio',
			_order => "$progkey.$areakey",
		};
	}
	return @items;
}

sub _radiruItems() {
	return Plugins::RadiRuKo::RadiruConfig->load()->then(
		sub {
			my $config    = shift;
			my $audioUrls = [];

			my $mainArea = $app_prefs->get('radiru_area') || 'tokyo';

			#メイン局はR1,R2,FMの順
			my @items = _radiruAreaItems($config->data(area => $mainArea), $audioUrls);

			my @areas = map { $_->{area} } $config->data();

			my @locals;
			for my $area (grep { $_ ne $mainArea } @areas) {
				my $data = $config->data(area => $area);
				push @locals, _radiruAreaItems($data, $audioUrls);
			}

			#ローカル局はR1,FMの順に並べる
			@locals = sort { $a->{_order} <=> $b->{_order} } @locals;

			push @items, +{
				title => localizedString('PLUGIN_RADIRUKO_NHK_LOCAL_STATIONS'),
				icon  => 'html/images/radio.png',
				items => \@locals,
			};

			return \@items;
		},
		sub {
			#config load failed
			$log->error($_[0]);
			return [];
		}
	);
}

sub _radikoItems() {
	return loadStationXml()->then(
		sub {
			my @stations = @{ $_[0] };
			my $areaId   = $_[1];

			my $title = localizedString("PLUGIN_RADIRUKO_RADIKO_AREA_$areaId");

			#radikoでのNHKを表示するか
			unless ($app_prefs->get('enable_radiko_nhk')) {
				@stations = grep { $_->{name} !~ /^NHK/ } @stations;
			}

			my @items;
			for (@stations) {
				my $name = localized(JA => $_->{name}, EN => $_->{ascii_name});
				$name .= '[via radiko]' if $_->{name} =~ /^NHK/;
				push @items, +{
					title => formatTitle($name),
					url   => 'radiko://' . $_->{id},
					icon  => $_->{logo}[0]->{content},
					type  => 'audio',
				};
			}

			return {
				title => $title,
				items => \@items,
			};
		},
		sub {
			+{
				title => localizedString('PLUGIN_RADIRUKO_RADIKO_AREA_UNKNOWN'),
				items => [],
			};
		}
	);
}

sub _simulRadioItems() {
	resolved(
		[ {
				title => localizedString('PLUGIN_RADIRUKO_COMMUNITY_STATIONS'),
				icon  => "html/images/radio.png",
				url   => 'https://t-yoshi.github.io/RadiRuKo-Plugin/feed/simulradio-9.1.opml',
				type  => 'link',
			}
		]
	);
}

#1-9,0のリモコン数字ボタン
sub _setTextKey {
	my $items = shift;
	my $key   = 0;
	for (@$items) {
		if ($_->{type} eq 'audio') {
			last if ++$key > 10;
			$_->{textkey} = substr($key, -1);
		}
	}
}

sub feedPromise {
	return collect(
		_radikoItems,
		_radiruItems,
		_simulRadioItems,
	)->then(
		sub {
			my $mergedFeed = {
				title => localizedString('PLUGIN_RADIRUKO_NAME'),
				items => [],
			};
			for (@_) {
				my $feed = $_->[0];
				#$log->debug(Dumper $feed);
				if (ref $feed eq 'HASH') {
					$mergedFeed->{title} .= $feed->{title};
					push @{ $mergedFeed->{items} }, @{ $feed->{items} };
				} else {
					push @{ $mergedFeed->{items} }, @$feed;
				}
			}
			return $mergedFeed;
		}
	);
}

1;
