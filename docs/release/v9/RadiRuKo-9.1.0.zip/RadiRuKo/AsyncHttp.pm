# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::AsyncHttp;

use v5.20;
use warnings;
use Carp::Assert               qw(assert);
use JSON::XS::VersionOneAndTwo qw(from_json);
use List::Util                 qw(min);
use Scalar::Util               qw(looks_like_number);
use Tie::RegexpHash;
use XML::Simple;
use Slim::Networking::SimpleAsyncHTTP;
use Slim::Utils::Log;
use Promises2 qw(deferred);
use Data::Dumper;

my $log = logger('plugin.radiruko');

tie my %defaultHandlers, 'Tie::RegexpHash';

#
# AsyncHttp(cache => 1, expires => 60) or AsyncHttp(cache => '3 days, no-revalidate')
#  ->handler(func)
#  ->get(url, header => value, ...)
#

sub _canonicalize_expires {
	my $s = shift;
	return $1         if $s =~ /^(\d+)(\s*sec(onds?)?)?$/;
	return $1 * 60    if $s =~ /^(\d+)\s*min(s|utes?)?/;
	return $1 * 3600  if $s =~ /^(\d+)\s*hours?/;
	return $1 * 86400 if $s =~ /^(\d+)\s*days?/;

	$log->error("Invalid expire: $s");
	return 10 * 60;
}

sub new {
	my $class = shift;
	assert(@_ % 2 == 0);
	my %params = @_;

	my $norevalidate = 0;    #Max-Ageなど無視

	if (defined $params{expires}) {
		$params{expires} = _canonicalize_expires($params{expires});
	} elsif ($params{cache} && $params{cache} ne '1') {
		$params{expires} = _canonicalize_expires($params{cache});
		$norevalidate    = $params{cache} =~ /\bno-?revalidate\b/;
		$params{cache}   = 1;
	}

	#最大10日間キャッシュ可能とする
	my $override_cache_expires = looks_like_number($params{expires}) && $params{expires} > 86400;
	if ($override_cache_expires) {
		$params{expires} = min($params{expires}, 864000);
	}

	my $deferred = deferred();

	my $shttp = Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my ($http) = @_;
			#SimpleAsyncHTTPの最大キャッシュ時間は1日だが
			# 少なすぎるので拡張する
			if ($params{cache} &&
				($override_cache_expires || $norevalidate) &&
				!$http->cachedResponse)
			{
				$log->debug(
					sprintf(
						'Override cache expires(%s) or no-revalidate(%s) : %s',
						$params{expires}, $norevalidate, $http->url
					)
				);
				$http->cacheResponse($params{expires}, $norevalidate, $params{client});
			}
			$deferred->resolve($http);
		},
		sub {
			my ($http, $err) = @_;
			$deferred->reject($err . ': ' . $http->url, $http);
		},
		\%params,
	);

	return bless {
		deferred => $deferred,
		http     => $shttp,
		handler  => undef,
	}, $class;
}

sub handler {
	my $self    = shift;
	my $handler = shift;

	assert(ref $handler eq 'CODE');
	$self->{handler} = $handler;

	return $self;
}

sub json {
	my $self = shift;
	return $self->handler($defaultHandlers{'application/json'});
}

sub xml {
	my $self = shift;
	return $self->handler($defaultHandlers{'application/xml'});
}

$defaultHandlers{qr{^(application|text)/xml\b}i} = sub {
	my $http   = shift;
	my %params = (
		ForceArray    => 0,
		KeyAttr       => [],
		SuppressEmpty => '',
	);
	return XMLin($http->contentRef, %params);
};

$defaultHandlers{qr{^(application|text)/json\b}i} = sub {
	my $http = shift;
	return from_json($http->content);
};

sub _parse {
	my $self = shift;
	return $self->{deferred}->then(
		sub {
			my $http = shift;

			return $self->{handler}->($http) if defined $self->{handler};

			my $ct      = $http->headers->content_type;
			my $handler = $defaultHandlers{$ct} // sub {
				return $_[0]->content;
			};
			return $handler->($http);
		}
	);
}

sub get {
	my $self = shift;
	$self->{http}->get(@_);
	return $self->_parse();
}

sub post {
	my $self = shift;
	$self->{http}->post(@_);
	return $self->_parse();
}

sub put {
	my $self = shift;
	$self->{http}->put(@_);
	return $self->_parse();
}

sub head {
	my $self = shift;
	$self->{http}->head(@_);
	return $self->_parse();
}

1;
