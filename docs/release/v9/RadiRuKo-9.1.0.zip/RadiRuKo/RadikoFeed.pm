# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadikoFeed;

use v5.20;
use warnings;
use utf8;
use Carp::Assert qw(assert);
use List::Util   qw(first);
use POSIX        qw(strftime);
use Time::HiRes q(time);
use URI;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Promises2 qw(rejected);
use Data::Dumper;
use Plugins::RadiRuKo::Utils qw(
  AsyncHttp isEnabledAreaFree
  jptime parseDateTime jpShortDateTimeF
);
use Plugins::RadiRuKo::RadikoAuth;

use Exporter 'import';
our @EXPORT_OK = qw(
  loadProgramXml loadAreaFreeStationXml
  loadAreaFreeStationXml loadTimeFreeStationXml
  loadStationXml loadNowProgramXml searchWordJson
);

our $VERSION = 9.0;

my $log       = logger('plugin.radiruko');
my $app_prefs = preferences('plugin.radiruko');

#
# 番組表のXMLを取得する。
#  stationId:
#  [time]: 過去の番組表(エポック時間)
#
# resolve: ($xml, 今または指定時刻の<prog>)
#
sub loadProgramXml {
	my $stationId = shift;
	my $now       = time();
	my $time      = shift || $now;

	assert($stationId);
	assert($time > 0);

	#朝５時更新
	my $date = strftime('%Y%m%d', jptime($time - 5 * 60 * 60));

	my $u = "https://radiko.jp/v3/program/station/date/$date/$stationId.xml";    #FMJ

	my $expires = $time == $now ? '2 hour' : '8 days';

	return AsyncHttp(cache => $expires)->get($u)->then(
		sub {
			my $xml     = shift;
			my $station = $xml->{stations}{station};

			#いま放送中/指定時刻の<prog>
			my $prog = _findProg($station, $time);

			return ($xml, $prog);
		}
	);
}

#
# 現在の番組表のXMLを取得する。
# areaId
#
# resolve: ({ stationId => 今の<prog>, ... })
#
sub loadNowProgramXml {
	my $areaId = shift || 'ALL';
	my $u      = "https://radiko.jp/v3/program/now/$areaId.xml";
	my $now    = time();

	return AsyncHttp(cache => '1 hour')->get($u)->then(
		sub {
			my $xml = shift;
			return +{ map { ($_->{id} => _findProg($_, $now)) } @{ $xml->{stations}{station} } };
		}
	);
}

#いま放送中/指定時刻の<prog>
sub _findProg {
	my $station = shift;
	my $time    = shift;
	return first {    #
		$time >= parseDateTime($_->{ft}) && parseDateTime($_->{to}) > $time
	} @{ $station->{progs}{prog} };
}

sub _filter_nhk_station {
	return $_[0] if $app_prefs->get('enable_radiko_nhk');
	return [ grep { $_->{name} !~ /^NHK/ } @{ $_[0] } ];
}

#
# エリアフリー対応局を返す
# resolve: ([<station>, ..])
#
sub loadAreaFreeStationXml() {
	return AsyncHttp(cache => '1 day')->get('https://radiko.jp/v3/station/region/full.xml')->then(
		sub {
			my $xml      = shift;
			my $stations = [ map { @{ $_->{station} } } @{ $xml->{stations} } ];
			$stations = _filter_nhk_station($stations);
			return [ grep { $_->{areafree} != 0 } @$stations ];
		}
	);
}

#
# タイムフリー対応局を返す
# resolve: ([<station>, ..], '')
#
sub loadTimeFreeStationXml() {
	my $p = isEnabledAreaFree() ? loadAreaFreeStationXml() : loadStationXml();
	return $p->then(
		sub {
			my $stations = [ grep { $_->{timefree} != 0 } @{ $_[0] } ];
			return ($stations, '');
		}
	);
}

#
# ローカルエリアの局を返す
# resolve: ([<station>, ..], areaId)
#
sub loadStationXml() {
	return Plugins::RadiRuKo::RadikoAuth->execute(mode => 'cache')->then(
		sub {
			my (undef, $areaId) = @_;
			my $u = "https://radiko.jp/v3/station/list/${areaId}.xml";
			return AsyncHttp(cache => '1 day')->get($u);
		}
	)->then(
		sub {
			my $stations = $_[0]->{station};
			$stations = _filter_nhk_station($stations);
			return ($stations, $_[0]->{area_id});
		}
	);
}

sub searchWordJson {
	my $areaId   = shift;
	my $query    = shift;
	my $page     = shift || 0;
	my $rowLimit = shift || 50;

	assert($areaId eq '' || $areaId =~ /^JP\d\d?$/);
	assert($page >= 0);
	assert($rowLimit > 0);

	return rejected('empty query string.') if $query eq '';

	my $regionId = isEnabledAreaFree() ? 'all' : '';
	my $uid      = Plugins::RadiRuKo::RadikoAuth::cookie_rdk_uid();

	utf8::encode($query) if utf8::is_utf8($query);

	my $u = URI->new('https://radiko.jp/v3/api/program/search');
	$u->query_form(
		key         => $query,
		filter      => 'past',  start_day => '',
		end_day     => '',      uid       => $uid,
		area_id     => $areaId, region_id => $regionId,
		cul_area_id => $areaId, page_idx  => $page,
		app_id      => 'pc',    row_limit => $rowLimit,
	);

	return AsyncHttp()->get($u);
}

1;
