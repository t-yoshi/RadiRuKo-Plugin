# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadiruMeta;

use v5.20;
use warnings;
use utf8;
use List::Util qw(first);
use POSIX;
use Slim::Utils::DateTime;
use Slim::Utils::Log;
use Plugins::RadiRuKo::Utils qw(
  AsyncHttp formatTitle RE_RADIRU_URL
  parseDateTime localizedString
);
use Promises2 qw(collect resolved rejected);
use Plugins::RadiRuKo::MetadataHandler;
use Plugins::RadiRuKo::RadiruConfig;
use Data::Dumper;

my $log = logger('plugin.radiruko');

# URL:
#  radiru://Station[-Area]
#
#  Station:
#    R1, R2, FM
#  Area:
#    Sendai, Tokyo, Nagoya, Osaka, ...
#

sub _DEBUG { 0 && $log->is_debug; }

sub _load {
	my $handler = shift;
	my $client  = shift;
	my $url     = shift;

	my ($channel, $area) = $url =~ RE_RADIRU_URL;
	$area ||= 'tokyo';

	return Plugins::RadiRuKo::RadiruConfig->load()->then(
		sub {
			my $config = shift;
			$log->debug(Dumper $config) if _DEBUG;

			my $data   = $config->data(area => $area) // return rejected("area: '$area' not found.\n");
			my $chName = localizedString(
				"PLUGIN_RADIRUKO_NHK_${channel}",
				JA => $data->{areajp},
				EN => ucfirst($data->{area}),
			);

			return collect(
				resolved($client, $url, $channel, $chName),
				AsyncHttp()->get($data->{url_program_noa}),
			);
		}
	)->then(\&_onJson);
}

sub _onJson {
	my ($client, $url, $channel, $chName) = @{ $_[0] };
	my ($js) = @{ $_[1] };

	my $ch       = { R1 => 'r1', R2 => 'r2', FM => 'r3' }->{$channel};
	my @programs = map { $js->{$ch}{$_} } qw/previous present following/;
	my $now      = time();

	$log->debug(Dumper \@programs) if _DEBUG;

	#放送中 or 次番組(放送休止中のとき)
	my $prog = first { $now < parseDateTime($_->{endDate}) } @programs
	  or return;

	my $logo = $prog->{about}{partOfSeries}{logo}{midium}{url} //
	  $prog->{about}{partOfSeries}{logo}{main}{url} // "plugins/RadiRuKo/html/images/NHK_$channel.png";

	my $startDate = parseDateTime($prog->{startDate});
	my $endDate   = parseDateTime($prog->{endDate});

	my ($title, $expires);
	if ($now >= $startDate) {
		#放送中
		$title = $chName . ' - ' . $prog->{name};
		#番組終了時に更新させる
		$expires = $endDate;
	} else {
		#放送休止中
		$title = sprintf(
			'%s [%s～]%s',
			$chName,
			Slim::Utils::DateTime::timeF($startDate, '%k:%M', 0),
			$prog->{name}
		);
		#放送開始時に更新させる
		$expires = $startDate;
	}

	my @actList     = map { $_->{name} } @{ $prog->{misc}{actList} };
	my $description = $prog->{description};
	my @musicList   = map { $_->{name} } @{ $prog->{misc}{musicList} };

	return {
		title   => formatTitle($title),
		artist  => formatTitle([@actList]),
		album   => formatTitle([ $description, @musicList ]),
		cover   => $logo,
		expires => $expires,
	};
}

Plugins::RadiRuKo::MetadataHandler->registerAsyncMetaProvider(
	match => RE_RADIRU_URL,
	func  => \&_load,
);

1;
