# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoRo::Plugin;

use v5.20;
use warnings;
use Slim::Formats::RemoteMetadata;
use Slim::Utils::Log;

use base qw(Slim::Plugin::OPMLBased);

use Plugins::RadiRuKo::Utils 9.1 qw(
  feedFromPromise
);

sub getDisplayName {'PLUGIN_RADIRUKO_RADIRU_ONDEMAND_NAME'}

sub initPlugin {
	my $class = shift;

	my $log = logger('plugin.radiruko');
	$log->info('RadiRuKo-OnDemand-Plugin v' . $class->_pluginDataFor('version'));

	require Plugins::RadiRuKoRo::Feed;
	require Plugins::RadiRuKoRo::ProtocolHandler;

	$class->SUPER::initPlugin(
		tag    => 'RadiRuKoRo',
		menu   => 'radios',
		weight => 1.03,
		feed   => feedFromPromise(\&Plugins::RadiRuKoRo::Feed::feedPromise),
	);

	Slim::Player::ProtocolHandlers->registerHandler(radiruod => q(Plugins::RadiRuKoRo::ProtocolHandler));
}

sub playerMenu {'RADIO'}

1;
