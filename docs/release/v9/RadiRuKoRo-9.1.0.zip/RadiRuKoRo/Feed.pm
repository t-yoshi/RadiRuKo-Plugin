# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoRo::Feed;
use v5.20;
use warnings;
use utf8;
use Carp::Assert qw(assert);
use Tie::IxHash;
use URI::Escape qw(uri_escape_utf8);
use URI;
use Slim::Utils::DateTime;
use Slim::Utils::Log;
use Plugins::RadiRuKo::Utils qw(
  AsyncHttp formatTitle strWidth trimWidth
  parseDateTime feedFromPromise
);
use Promises2 qw(resolved);
use Plugins::RadiRuKoRo::ProtocolHandler;
use Data::Dumper;

my $log = logger('plugin.radiruko');

sub _audioUrl {
	my $url = shift;

	assert(@_ % 2 == 0);

	my $meta = {};
	tie %$meta, 'Tie::IxHash', @_;
	my $frag = Plugins::RadiRuKoRo::ProtocolHandler->encodeMetadataFragment($meta);
	return "$url$frag&_=-";
}

#キャッシュの意義:
# らじるのメニューは頻繁に更新されるので、メニューを
# たどっているときに更新されるとナビゲーションがおかしくなる

sub _CACHE_TIME() {'3 day, no-revalidate'}

sub _session {
	my $client = shift;
	unless (defined $client) {
		$log->warn('client is not connected yet.');
		return;
	}
	return $client->master->pluginData('RadiRuKoRo-Session', @_);
}

sub _new_session {
	my $client = shift;
	my $s      = Slim::Utils::DateTime::timeF(0, '%m%d%H%M', 0);
	_session($client, $s);
	$log->debug('Session start: ' . $s);
}

sub _buildUrl {
	my $client = shift;
	my $base   = shift;
	assert(@_ % 2 == 0);

	my $u = URI->new($base);

	for (@_) {
		utf8::encode($_) if utf8::is_utf8($_);
	}
	$u->query_form(@_);

	my $s = _session($client);
	$u->fragment('_=' . $s) if $s;

	return $u->as_string();
}

sub _seriesItems {
	my ($client, $args, $site_id, $corner_site_id) = @_;

	my @q;
	push @q, site_id => $site_id;
	if (defined $corner_site_id and $corner_site_id ne '') {
		push @q, corner_site_id => $corner_site_id;
	}

	my $jsUrl = _buildUrl(
		$client,
		'https://www.nhk.or.jp/radio-api/app/v1/web/ondemand/series',
		@q
	);

	$log->debug("[$jsUrl]");
	my $now = time();

	return AsyncHttp(cache => _CACHE_TIME)->get($jsUrl)->then(
		sub {
			my $json   = shift;
			my $client = shift;

			my $progName = formatTitle([ $json->{title}, $json->{corner_name} ]);
			my $image    = $json->{thumbnail_url} // 'html/images/radio.png';

			my @items;

			for (@{ $json->{corners} or [] }) {
				my $line1 = formatTitle([ $_->{title},      $_->{corner_name} ]);
				my $line2 = formatTitle([ $_->{onair_date}, $_->{corner_name} ]);
				my $title = sprintf('%s [%s]', $line1, $_->{onair_date});

				my $item = {
					title       => $title,
					line1       => $line1,
					line2       => $line2,
					icon        => $image,
					url         => feedFromPromise(\&_seriesItems),
					passthrough => [ $_->{series_site_id}, $_->{corner_site_id} ],
				};
				push @items, $item;
			}

			for (@{ $json->{episodes} or [] }) {
				my $u = $_->{stream_url};
				next unless $u;

				$u =~ s/^https:/radiruod:/;
				my $duration = '';

				#2024-06-03T21:30:00+09:00_2024-06-03T21:45:00+09:00
				if ($_->{aa_contents_id} =~ /^.+;(20.+?)_(20.+?)$/) {
					$duration = parseDateTime($2) - parseDateTime($1);
				}

				my $line1 = formatTitle([ $_->{program_title}, $_->{series_description} ]);
				my $line2 = formatTitle([ $_->{onair_date},    $_->{program_sub_title} ]);
				my $title = sprintf('%s [%s]', $line1, $_->{onair_date});
				my $item  = {
					title => $title,
					line1 => $line1,
					line2 => $line2,
					icon  => $image,
					url   => _audioUrl(
						$u,
						title    => $line1,
						artist   => formatTitle($_->{program_sub_title}),
						album    => $progName // $_->{series_url} // $_->{share_text_url},
						cover    => $image,
						duration => $duration,
					),
					type => 'audio',
				};
				push @items, $item;
			}
			return \@items;
		}
	);
}

#未放送か
sub _isUnaired {
	my $now = time();

	#2024年4月1日 -> 2024-04-01T00:00+09:00
	my ($y, $m, $d) = $_[0] =~ /(20\d\d)年(0?[1-9]|1[012])月(0?[1-9]|[12]\d|3[01])日/ or do {
		$log->warn('parse error: ' . $_[0]) if $_[0];
		return 0;
	};
	my $t = sprintf(
		'%d-%02d-%02dT00:00+09:00',
		$y, $m, $d
	);
	#$log->debug("$_[0] -> $t");
	return parseDateTime($t) > $now;
}

sub _cbGenreOrSearch {
	my $json   = shift;
	my $client = shift;

	my @items;
	my @series = grep { $_->{series_site_id} } @{ $json->{series} or [] };

	for (@series) {
		my $line1 = formatTitle([ $_->{title}, $_->{corner_name} ]);
		my $line2 = $_->{onair_date} // '';
		my $title = $line2 ? "$line1 [$line2]" : $line1;

		my $item = {
			title       => $title,
			line1       => $line1,
			line2       => $line2,
			icon        => $_->{thumbnail_url} // 'html/images/radio.png',
			url         => feedFromPromise(\&_seriesItems),
			passthrough => [ $_->{series_site_id}, $_->{corner_site_id} ],
			_order      => 0,
		};

		if (_isUnaired($_->{onair_date})) {
			$item->{line1}  = '*' . $item->{line1};
			$item->{title}  = '*' . $item->{title};
			$item->{_order} = 1;
		}

		push @items, $item;
	}

	@items = sort {
		$a->{_order} <=> $b->{_order}
		# or $a->{title} cmp $b->{title}
	} @items;

	return \@items;
}

sub _genreItems {
	my ($client, $args, $genre) = @_;

	my $u = _buildUrl(
		$client,
		'https://www.nhk.or.jp/radio-api/app/v1/web/ondemand/series',
		genre => $genre
	);

	$log->debug("[$u]");
	return AsyncHttp(cache => _CACHE_TIME)->get($u)->then(\&_cbGenreOrSearch);
}

sub _searchItems {
	my ($client, $args) = @_;

	my $u = _buildUrl(
		$client, 'https://www.nhk.or.jp/radio-api/app/v1/web/ondemand/series/search',
		keyword => $args->{search}
	);

	$log->debug("[$u]");
	return AsyncHttp(cache => 1)->get($u)->then(\&_cbGenreOrSearch);
}

sub _d_params {
	my $params = shift;
	my $s;
	for my $k (keys %{$params}) {
		my $v = $params->{$k};
		$s .= "$k=$v, " unless ref $v;
	}
	$log->debug($s) if $s;
}

sub feedPromise() {
	my ($client, $args, @passthrough) = @_;

	_d_params($args->{params});
	my $item_id = $args->{params}{item_id} //    # アプリ・Web
	  $args->{params}{index} // '';              # Touch
	my $ses = _session($client);
	if ($item_id !~ /\./ || !defined $ses) {
		#トップorジャンルページに戻った時に新セッション
		_new_session($client);
	}
	#playなどの操作以外なら新セッション
	#_new_session($client) unless (defined $args->{params}{_method});

	my $u = _buildUrl($client, 'https://www.nhk.or.jp/radio-api/app/v1/web/ondemand/series/genres');

	return AsyncHttp(cache => 1)->get($u)->then(
		sub {
			my $json = shift;
			my @items;

			for (@{ $json->{genres} }) {
				my $item = {
					title       => $_->{name},
					icon        => 'html/images/radio.png',
					url         => feedFromPromise(\&_genreItems),
					passthrough => [ $_->{genre} ],
				};
				push @items, $item;
			}

			push @items, +{
				title       => Slim::Utils::Strings::string('SEARCHFOR'),
				icon        => 'html/images/search.png',
				type        => 'search',
				url         => feedFromPromise(\&_searchItems),
				passthrough => [],
			};

			if (0) {
				#テスト用
				require List::Util;
				@items = List::Util::shuffle @items;
			}

			return \@items;
		},
	);

}

1;
