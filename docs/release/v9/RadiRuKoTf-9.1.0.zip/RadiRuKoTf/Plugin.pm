# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoTf::Plugin;

use v5.20;
use warnings;
use base qw(Slim::Plugin::OPMLBased);
use Slim::Utils::Log;

use Plugins::RadiRuKo::Utils 9.1 qw(
  feedFromPromise
);

sub getDisplayName {'PLUGIN_RADIRUKO_TIMEFREE_NAME'}

sub initPlugin {
	my $class = shift;

	my $log = logger('plugin.radiruko');

	$log->info('RadiRuKo-TimeFree-Plugin v' . $class->_pluginDataFor('version'));

	require Plugins::RadiRuKoTf::Feed;
	require Plugins::RadiRuKoTf::ProtocolHandler;
	require Plugins::RadiRuKo::RadikoMeta;

	$class->SUPER::initPlugin(
		tag    => 'RadiRuKoTf',
		menu   => 'radios',
		weight => 1.04,
		feed   => feedFromPromise(\&Plugins::RadiRuKoTf::Feed::feedPromise),
	);

	Slim::Player::ProtocolHandlers->registerHandler(radikotf => q(Plugins::RadiRuKoTf::ProtocolHandler));
}

sub playerMenu {'RADIO'}

1;
