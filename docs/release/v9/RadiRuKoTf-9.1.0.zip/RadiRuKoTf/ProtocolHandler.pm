# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoTf::ProtocolHandler;
use v5.20;
use warnings;
use utf8;
use base q(Plugins::RadiRuKo::BaseFFSeekableHandler);
use POSIX qw(strftime);
use Slim::Utils::Log;
use Plugins::RadiRuKo::RadikoAuth;
use Plugins::RadiRuKoTf::Feed;
use Plugins::RadiRuKo::Utils qw(
  parseDateTime jptime jpShortDateTimeF
  RE_RADIKO_TF_URL
);

my $log = logger('plugin.radiruko');

sub new {
	my $class  = shift;
	my $args   = shift;
	my $client = $args->{client};
	my $song   = $args->{song};

	my $u   = $song->pluginData('radikoPlaylist');
	my $opt = $song->pluginData('ffOptions');

	return $class->SUPER::new($args, $u, @$opt);
}

sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $url = $song->track()->url;

	my ($stId, $ft, $to) = $url =~ RE_RADIKO_TF_URL
	  or return $errorCb->("Invalid URL: $url");

	$song->duration(parseDateTime($to) - parseDateTime($ft));

	Plugins::RadiRuKo::RadikoAuth->execute(url => $url)->then(
		sub {
			my ($token, $areaId) = @_;
			$song->pluginData(
				ffOptions => [
					#ffmpeg binary option
					-post_data => unpack('H*', "flash=1\cM\cJ"),
					-headers   => "X-Radiko-AuthToken: $token\cM\cJ",
				]
			);
			$song->pluginData(radikoPlaylist => _m3u8Url($stId, $ft, $to));
		}
	)->done($successCb, $errorCb);
}

sub _m3u8Url {
	my ($stId, $ft, $to) = @_;
	return "https://radiko.jp/v2/api/ts/playlist.m3u8?station_id=${stId}&l=15&ft=${ft}&to=${to}";
}

sub getFormatForURL {'aac'}

1;
