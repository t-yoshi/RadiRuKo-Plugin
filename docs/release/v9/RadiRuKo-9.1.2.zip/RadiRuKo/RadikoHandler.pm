# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::RadikoHandler;

# RADIKO URL protocol handler

use v5.20;
use warnings;
use base qw(Plugins::RadiRuKo::BaseFFMpegHandler);
use Slim::Utils::Log;
use Promises2 qw(collect);
use Plugins::RadiRuKo::RadikoAuth;
use Plugins::RadiRuKo::RadikoMeta;
use Plugins::RadiRuKo::Utils qw(RE_RADIKO_URL);

my $log = logger('plugin.radiruko');

sub new {
	my $class = shift;
	my $args  = shift;
	my $song  = $args->{song};
	my $u     = $song->pluginData('radikoPlaylist');
	my $opt   = $song->pluginData('ffOptions');

	return $class->SUPER::new($args, $u, @$opt);
}

sub getNextTrack {
	my ($class, $song, $successCb, $errorCb) = @_;

	my $client = $song->master();
	my $url    = $song->track()->url;

	unless ($url =~ RE_RADIKO_URL) {
		$errorCb->('Invalid URL: ' . $url);
		return;
	}

	my $stId       = $1;
	my $isAreaFree = $url =~ /^radikop:/;

	$song->isLive(1);

	collect(
		Plugins::RadiRuKo::RadikoAuth->execute(url => $url),
		Plugins::RadiRuKo::RadikoFeed::loadPlaylist($stId, $isAreaFree, 0),
	)->then(
		sub {
			my ($token, $area) = @{ $_[0] };
			my ($m3u8) = @{ $_[1] };
			$log->debug("Authtoken=$token, AreaId=$area, Playlist=$m3u8") if $log->is_debug;

			$song->pluginData(
				ffOptions => [
					-headers => "X-Radiko-AuthToken: $token\cM\cJ",
				]
			);
			$song->pluginData(radikoPlaylist => $m3u8);
		}
	)->done($successCb, $errorCb);
}

sub getFormatForURL {'aac'}

1;
