# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKoPr::Plugin;

use strict;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Strings;
use Data::Dumper;

use base qw(Slim::Plugin::OPMLBased);

use Plugins::RadiRuKo::Utils 9.0 qw(
    feedFromPromise
);

sub getDisplayName {'PLUGIN_RADIRUKO_PREMIUM_NAME'}

sub initPlugin {
    my $class = shift;

    my $app_prefs = preferences('plugin.radiruko');
    my $log       = logger('plugin.radiruko');

    $log->info('RadiRuKo-Premium-Plugin v' . $class->_pluginDataFor('version'));

    Slim::Player::ProtocolHandlers->registerHandler(radikop => q(Plugins::RadiRuKo::RadikoHandler));

    require Plugins::RadiRuKo::RadikoHandler;
    require Plugins::RadiRuKoPr::Settings;
    require Plugins::RadiRuKoPr::Feed;

    $class->SUPER::initPlugin(
        tag    => 'RadiRuKoPr',
        menu   => 'radios',
        weight => 1.02,
        feed   => feedFromPromise(\&Plugins::RadiRuKoPr::Feed::feedPromise),
    );

    Plugins::RadiRuKoPr::Settings->new();
}

sub playerMenu {'RADIO'}

1;
