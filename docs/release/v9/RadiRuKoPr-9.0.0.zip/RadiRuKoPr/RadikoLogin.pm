# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKoPr::RadikoLogin;

use strict;
use Plugins::RadiRuKo::RadikoAuth qw(UA cookie_radiko_session);
use URI::Escape qw(uri_escape);
use JSON::XS::VersionOneAndTwo;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Networking::SimpleAsyncHTTP;
use Slim::Networking::Async::HTTP;
use Plugins::RadiRuKo::Utils;
use Promises::Tiny qw(rejected);

my $app_prefs = preferences('plugin.radiruko');
my $log       = logger('plugin.radiruko');

use constant RE_MAIL_ADDRESS =>
    qr/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

#class-methods
sub login($$$) {
    my ($class, $mail, $pass) = @_;

    return rejected('Invalid mail address.') unless $mail =~ RE_MAIL_ADDRESS;
    return rejected('empty password')        unless $pass;

    $log->debug("login: Start [$mail]");

    return AsyncHttp()->post(
        'https://radiko.jp/v4/api/member/login',
        'User-Agent'   => UA,
        'Content-Type' => 'application/x-www-form-urlencoded',
        sprintf('mail=%s&pass=%s', uri_escape($mail), uri_escape($pass))
    )->then(
        sub {
            my $json = shift;
            $log->debug("login: OK");
            my $radiko_session = $json->{radiko_session};
            if ($radiko_session =~ /^[\da-f]{40}$/) {
                cookie_radiko_session($radiko_session);
                return $radiko_session;
            }
            return rejected('Invalid: radiko_session');
        }
    );
}

sub logout ($) {
    my ($class) = @_;

    $log->debug("logout: Start");

    my $radiko_session = cookie_radiko_session();
    unless ($radiko_session) {
        return rejected('radiko_session is already empty.');
    }

    return AsyncHttp()->post(
        'https://radiko.jp/v4/api/member/logout',
        'User-Agent'   => UA,
        'Content-Type' => 'application/x-www-form-urlencoded',
        "radiko_session=$radiko_session"
    )->then(
        sub {
            my $content = shift;
            $log->debug("logout: OK [$content]");
            cookie_radiko_session('');
            return 'Logout Successful.';
        }
    );
}

1;
