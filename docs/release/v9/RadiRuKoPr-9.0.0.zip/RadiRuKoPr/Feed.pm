# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
package Plugins::RadiRuKoPr::Feed;

use strict;
use Slim::Utils::Log;
use Promises::Tiny qw(rejected collect);
use Data::Dumper;
use Plugins::RadiRuKo::RadikoMeta;
use Plugins::RadiRuKo::Utils qw(
    localized localizedString
);
use Plugins::RadiRuKo::RadikoFeed qw(
    loadAreaFreeStationXml
);
use Plugins::RadiRuKo::RadikoAuth qw(
    cookie_radiko_session
);

my $log = logger('plugin.radiruko');

sub feedPromise () {
    if (!$log->is_debug && !cookie_radiko_session()) {
        return rejected('Please login first.');
    }

    return loadAreaFreeStationXml()->then(
        sub {
            my $stations = shift;

            my @items = map {
                my $name = localized(JA => $_->{name}, EN => $_->{ascii_name});
                +{
                    title => $name,
                    url   => 'radikop://' . $_->{id},
                    icon  => $_->{logo}->[0]->{content},
                    type  => 'audio',
                };
            } @$stations;

            return {
                type  => 'opml',
                title => localizedString('PLUGIN_RADIRUKO_PREMIUM_NAME'),
                items => \@items,
            };
        }
    );
}

1;
