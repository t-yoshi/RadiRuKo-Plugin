package Plugins::RadiRuKo::BaseWebSocketHandler;

use strict;

use base q(IO::Handle);
use Carp::Assert;
use Scalar::Util qw(blessed);
use IO::Socket::SSL qw/SSL_VERIFY_NONE/;
use IO::Socket::INET;
use IO::String;
use POSIX qw(floor);
use Time::HiRes q(time);
use List::Util qw(min);
use Slim::Utils::Log;
use Slim::Utils::Network;
use Slim::Utils::Prefs;
use Slim::Utils::Errno;
use Slim::Utils::Timers;
use Slim::Music::Info;
use Slim::Networking::IO::Select;
use Slim::Networking::Select;
use Protocol::WebSocket::URL;
use Protocol::WebSocket::Frame;
use Protocol::WebSocket::Handshake::Client;
use Data::Dumper;

my $log          = logger('plugin.radiruko');
my $server_prefs = preferences('server');

sub new {
    my $class  = shift;
    my $ws_url = shift;
    my $args   = shift;

    unless (blessed $ws_url && $ws_url->isa('Protocol::WebSocket::URL')) {
        if ($ws_url !~ m|^wss?://|) {
            $log->error('Invalid Websocket Url: ' . $ws_url);
            return;
        }
        $ws_url = Protocol::WebSocket::URL->new->parse($ws_url);
    }
    $log->debug('ws_url=' . $ws_url->to_string);

    my $timeout = $args->{timeout} || $server_prefs->remotestreamtimeout;

    my @sockOpt = (
        PeerAddr => $ws_url->{host},
        PeerPort => $ws_url->{port},
        Timeout  => $timeout,
    );

    my $sock;
    my $err;

    if ($ws_url->{secure}) {
        $sock = IO::Socket::SSL->new(
            @sockOpt,
            SSL_verify_mode => SSL_VERIFY_NONE,
        );
        $err = IO::Socket::SSL::errstr;
    } else {
        $sock = IO::Socket::INET->new(@sockOpt);
        $err  = $IO::Socket::INET::errstr;
    }

    unless (defined $sock) {
        $log->error('Failed open sock: ' . $ws_url->to_string . " $err");
        return;
    }

    ${*$sock}{_sel} = IO::Select->new($sock);
    Slim::Utils::Network::blocking($sock, 0) || do {
        logError('Could not set to non-blocking mode.');
        $sock->close();
        return;
    };

    my $self = $class->SUPER::new();
    ${*$self}{url}    = $args->{url};
    ${*$self}{client} = $args->{client};
    ${*$self}{song}   = $args->{song};
    ${*$self}{ws_url} = $ws_url;

    my $hs = Protocol::WebSocket::Handshake::Client->new(url => $ws_url);

    $self->wsTryHandshake($sock, $hs, $timeout) || do {
        $sock->close();
        return;
    };

    ${*$self}{_ws_sock}   = $sock;
    ${*$self}{_ws_frame}  = _wsBuildFrame();
    ${*$self}{_ws_buffer} = IO::String->new();

    $self->_startObservingBitrate();

    return $self;
}

sub _read_response {
    my ($sock, $timeout) = @_;
    my $res;
    my $err;
    until (defined $err) {
        if (${*$sock}{_sel}->can_read($timeout)) {
            while (1) {
                my $r = $sock->sysread($res, 1, length($res));
                last unless defined $r;
                if ($r == 0) {
                    $err = 'Unexpected EOF.';
                    last;
                }
                return $res if $res =~ /\cM\cJ\cM\cJ$/;
            }
        }
        if ($! && !($!{EINTR} || $!{EWOULDBLOCK})) {
            $err = $!;
        }
    }
    $log->error($err);
    return;
}

sub wsTryHandshake {
    my ($self, $sock, $hs, $timeout) = @_;

    my $req = $hs->to_string;
    $log->debug("Request: $req");
    $sock->syswrite($req);

    my $res = _read_response($sock, $timeout) || return;
    $log->debug("Response: $res");

    unless ($res && $hs->parse($res)) {
        $log->error('Switching protocol is failed: ' . $hs->error);
        return;
    }

    return 1;
}

sub _wsBuildFrame {
    return Protocol::WebSocket::Frame->new(version => undef, @_);
}

{
    no strict 'refs';
    for my $method (qw(opened blocking)) {
        *{ __PACKAGE__ . "::$method" } = sub {
            my $self = shift;
            return ${*$self}{_ws_sock}->$method(@_);
        };
    }
}

sub _startObservingBitrate {
    my $self     = shift;
    my $INTERVAL = 5;
    Slim::Utils::Timers::setTimer($self, time + $INTERVAL, \&_doObserveBitrate, $INTERVAL, 0);
}

sub _doObserveBitrate {
    my $self           = shift;
    my $interval       = shift;
    my $prevTotalBytes = shift;

    assert($interval > 0);

    return unless $self->opened;

    my $bps = floor(8. * (${*$self}{_ws_audio_total_bytes} - $prevTotalBytes) / $interval);
    my $now = time();

    Slim::Music::Info::setBitrate(${*$self}{url}, $bps, 1);
    #WebUIの更新
    ${*$self}{client}->currentPlaylistUpdateTime($now);

    $log->debug("bitrate: $bps");

    # 徐々に更新頻度を減らす
    $interval = min(120, $interval * 1.5);

    Slim::Utils::Timers::setTimer(
        $self, $interval + $now,
        \&_doObserveBitrate,
        $interval,
        ${*$self}{_ws_audio_total_bytes},
    );
}

sub _wsReadPacketAndFillBuffer {
    my $self = shift;

    my $r = ${*$self}{_ws_sock}->sysread(my $raw, 32768);
    return $r unless $r;

    ${*$self}{_ws_frame}->append($raw);

    my $buf = ${*$self}{_ws_buffer};

    $buf->open();

    while (my $b = ${*$self}{_ws_frame}->next_bytes) {
        $buf->syswrite($b);
        ${*$self}{_ws_audio_total_bytes} += length($b);
    }

    my $n = $buf->pos;
    $buf->seek(0, 0);

    if ($n == 0) {
        $! = EINTR;
        return undef;
    }

    return $n;
}

sub sysread {
    my $self = shift;

    return 0 unless $self->opened;

    my $buf = ${*$self}{_ws_buffer};

    if ($buf->eof) {
        my $r = $self->_wsReadPacketAndFillBuffer();
        return $r unless $r;
    }

    return $buf->sysread(@_);
}

sub ws_write {
    my $self = shift;

    return unless $self->opened;

    my $sock = ${*$self}{_ws_sock};
    my $frame =
        @_ == 1
        ? _wsBuildFrame(masked => 1, buffer => shift)
        : _wsBuildFrame(@_);
    my $buf = $frame->to_bytes;

    Slim::Networking::Select::writeNoBlock($sock, \$buf);
    #    $sock->syswrite($frame->to_bytes);
}

sub isRemote {1}

sub close {
    my $self = shift;

    Slim::Utils::Timers::killTimers($self, \&_doObserveBitrate);

    my $sock = ${*$self}{_ws_sock};

    if ($sock->opened && ${*$sock}{_sel}->can_write(0)) {
        $log->debug('send close packet.');
        my $frame = _wsBuildFrame(type => 'close');
        $sock->syswrite($frame->to_bytes);
    }

    ${*$sock}{_sel}->remove($sock);
    $sock->close();
}

1;
