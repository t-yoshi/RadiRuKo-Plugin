
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::Settings;

use strict;
use base qw(Slim::Web::Settings);
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::PluginManager;

use Plugins::RadiRuKo::RadiruConfig;
use Plugins::RadiRuKo::Utils qw(
    localized
);
use Data::Dumper;

my $log       = logger('plugin.radiruko');
my $app_prefs = preferences('plugin.radiruko');

sub name {
    return Slim::Web::HTTP::CSRF->protectName('PLUGIN_RADIRUKO');
}

sub page {
    return Slim::Web::HTTP::CSRF->protectURI('plugins/RadiRuKo/settings/basic.html');
}

sub handler {
    my ($class, $client, $params, $callback, @args) = @_;

    if ($params->{saveSettings}) {
        $app_prefs->set(radiru_area        => $params->{radiru_area});
        $app_prefs->set(enable_radiko_nhk  => $params->{enable_radiko_nhk});
        $app_prefs->set(hls_buffering_time => $params->{hls_buffering_time});
    }

    $params->{prefs}->{enable_radiko_nhk}  = $app_prefs->get('enable_radiko_nhk');
    $params->{prefs}->{radiru_area}        = $app_prefs->get('radiru_area')        || 'tokyo';
    $params->{prefs}->{hls_buffering_time} = $app_prefs->get('hls_buffering_time') || 'normal';

    Plugins::RadiRuKo::RadiruConfig->load()->then(
        sub {
            my $config = shift;

            #[[tokyo => 東京, [osaka=>'大阪'], ...]
            $params->{radiru_all_areas} = [
                map {
                    my $label = localized(JA => $_->{areajp}, EN => ucfirst($_->{area}));
                    [ $_->{area} => $label ]
                } $config->data()
            ];
        }
    )->finally(
        sub {
            $log->debug($_[0]);
            my $body = $class->SUPER::handler($client, $params);
            $callback->($client, $params, $body, @args);
        }
    );

    return;
}

1;
