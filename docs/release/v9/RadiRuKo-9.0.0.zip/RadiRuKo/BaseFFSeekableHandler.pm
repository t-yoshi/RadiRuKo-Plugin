# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
package Plugins::RadiRuKo::BaseFFSeekableHandler;

use base qw(Plugins::RadiRuKo::BaseFFMpegHandler);
use Carp::Assert;
use List::Util qw(min max);
use POSIX qw(floor);
use Time::HiRes q(time);
use Slim::Utils::Misc();
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Data::Dumper;
use Slim::Utils::Cache;
use Slim::Utils::DateTime;
use Slim::Utils::Timers;
use Slim::Utils::Strings qw(string);

my $cache = Slim::Utils::Cache->new('radiruko');
my $log   = logger('plugin.radiruko');

use constant CACHE_RESUME_POSITION => '4 days';

sub new {
    my $class     = shift;
    my $args      = shift;
    my $ffurl     = shift;
    my @ffoptions = @_;
    my $song      = $args->{song};

    #FIX: らじる聞き逃しが22/05/13頃からエラーになる問題
    push @ffoptions, -http_seekable => 0;

    my $offset = ($song->seekdata() || {})->{timeOffset};

    if ($offset > 0) {
        _saveResumePosition($song);
    } else {
        my $key = _cache_key($args->{client}, $args->{url});
        $offset = $cache->get($key);
        $log->debug("Restored resume position $offset secs [$key]") if $offset;
    }

    if ($offset > 0) {
        #ffmpeg-seek
        push @ffoptions, -ss => "+$offset";
        $song->startOffset($offset);
    }

    my $mediafrags = $class->parseMediaFragment($args->{url});
    $song->duration($1) if $mediafrags->{duration} =~ /(\d+)/;

    # 15分以下の番組は-reとせず、一気に読み込む
    if ($song->duration > 0 && $song->duration - $offset <= 900) {
        $song->isLive(1);
    }

    _periodicallySaveResumePosition($args->{client}, $args->{url});

    return $class->SUPER::new($args, $ffurl, @ffoptions);
}

sub canDoAction {
    my ($class, $client, $url, $action) = @_;
    my $song = $client->playingSong();
    if ($action eq 'rew') {
        _removeResumePosition($song) if $song;
    } elsif ($action eq 'stop') {
        #_saveResumePosition($song) if $song;
    }
    return 1;
}

sub canSeek {
    my ($class, $client, $song) = @_;
    return 1;
}

sub getSeekData {
    my ($class, $client, $song, $newtime) = @_;
    return { timeOffset => floor($newtime), };
}

sub _cache_key {
    my $client = shift;
    my $url    = shift;
    $url =~ s/#.*$//;
    my $mac = $client->macaddress || 'null';
    return "ffresume($mac)$url";
}

sub _periodicallySaveResumePosition {
    my $client = shift;
    my $url    = shift;
    my $song   = $client->playingSong() || return;
    return if ($song->currentTrack->url ne $url || $client->isStopped);

    _saveResumePosition($song);
    Slim::Utils::Timers::setTimer($client, time + 15, \&_periodicallySaveResumePosition, $url);
}

sub _saveResumePosition ($) {
    my $song = shift;

    my $elapsed = floor($song->master->controller->playingSongElapsed);

    if ($song->duration >= 600 && $elapsed > 30 && $elapsed < ($song->duration * 0.90)) {
        my $key = _cache_key($song->master, $song->currentTrack->url);
        $cache->set($key, $elapsed, CACHE_RESUME_POSITION);
        $log->debug("Save resume position $elapsed secs [$key]");
    } else {
        _removeResumePosition($song);
    }
}

sub _removeResumePosition ($) {
    my $song = shift;
    my $key  = _cache_key($song->master, $song->currentTrack->url);

    if (defined $cache->get($key)) {
        $log->debug("Remove resume position [$key]");
        $cache->remove($key);
    }
}
1;
